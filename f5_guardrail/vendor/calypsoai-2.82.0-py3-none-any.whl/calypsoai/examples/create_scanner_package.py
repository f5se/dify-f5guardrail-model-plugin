#!/usr/bin/env python3

from datetime import datetime, timezone

from calypsoai import CalypsoAI

cai = CalypsoAI()

scanner_descriptions = [
    "mammals",
    "birds",
    "fish",
]

scanners = [
    cai.scanners.createCustom(name=f"{desc.title()} Scanner", description=desc) for desc in scanner_descriptions
]

scanner_package = cai.scannerPackages.create(name="Animal Scanner Package", scanners=scanners)

print(f"Created scanner package: {scanner_package.model_dump_json(indent=2)}")

cai.scannerPackages.update(
    scanner_package,
    name=f"Animal Scanner Package {datetime.now(timezone.utc).date().isoformat()}",
)

scanner_package = cai.scannerPackages.get(scanner_package)

print(f"Updated scanner package: {scanner_package.model_dump_json(indent=2)}")

cai.scannerPackages.delete(scanner_package, deleteScanners=True)

print("Deleted scanner package")
