from pathlib import Path

from calypsoai import CalypsoAI
from calypsoai import datatypes as dt

cai = CalypsoAI()

response = cai.client.datasets.post(
    dt.BodyPostDatasets(
        file=dt.UploadFile(
            filename="datasets.csv",
            data=(Path(__file__).resolve().parent / "datasets.csv").read_bytes(),
            contentType="text/csv",
        ),
        name="PIN test",
        scannerId="019961fc-3079-70bf-878b-d28d7f806eab",
        scannerVersions=[
            "v_1",
            "v_2",
        ],
    )
)
print(response.model_dump_json(indent=2))
