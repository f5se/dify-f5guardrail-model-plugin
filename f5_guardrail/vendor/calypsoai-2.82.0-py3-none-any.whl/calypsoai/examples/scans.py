#!/usr/bin/env python3

from calypsoai import CalypsoAI
from calypsoai import datatypes as dt
from calypsoai.examples.util import IO, Colour

cai = CalypsoAI()

while data := IO.prompt(Colour.blue("Prompt to scan")):
    scans = cai.scans.scan(
        data,
        override={
            dt.ScanType.BLACKLIST: dt.BlacklistScannerConfig(
                words=["test"],
                redact=dt.RedactConfig(enabled=True),
            ),
        },
        disabled=[dt.ScanType.SECRET],
    ).result.scannerResults

    print(next(scan for scan in scans if scan.data.type == dt.ScanType.BLACKLIST).model_dump_json(indent=2))
