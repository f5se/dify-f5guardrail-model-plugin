#!/usr/bin/env python3

import os

from calypsoai import CalypsoAI

cai = CalypsoAI()

provider = cai.providers.create(
    "gpt-4",
    "openai-chat",
    secrets={
        "apiKey": {"name": "OpenAI API Key", "value": os.environ["OPENAI_KEY"]},
    },
    maxRequestsPerSecond=5,
)
print(f"Created provider {provider.model_dump_json(indent=2)}")
