#!/usr/bin/env python3

import sys

from calypsoai import CalypsoAI
from calypsoai import datatypes as dt
from calypsoai.examples.util import IO, Colour

cai = CalypsoAI()


providers = list(cai.providers.enabled().values())

provider = IO.select(providers, Colour.blue("Select a provider"), lambda p: p.name)

if not provider:
    sys.exit(0)

parent = None

while data := IO.prompt(Colour.blue("Prompt")):
    prompt = cai.prompts.send(data, parent=parent)

    if prompt.result.outcome == dt.PromptOutcome.BLOCKED:
        print(f"{Colour.red('CalypsoAI >')} Response was blocked\n")
        continue

    print(f"{Colour.green(provider.name + ' >')} {prompt.result.response}\n")

    parent = prompt
