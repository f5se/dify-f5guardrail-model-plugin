#!/usr/bin/env python3

import sys

from calypsoai import CalypsoAI
from calypsoai.examples.util import IO, Colour

cai = CalypsoAI()

scanners = list(cai.scanners.iterate())

scanner = IO.select(
    scanners,
    Colour.blue("Select a scanner"),
    lambda p: f"Name: {p.name}, Config: {p.config}, Direction: {p.direction}"
    f"Published: {p.published}, Files: {p.files}, Tags: {p.tags}",
)

if not scanner:
    sys.exit(0)

print(f"Scanner: {scanner}\n")

data = IO.prompt("Write a new description for the scanner")

response = cai.scanners.updateCustom(
    scanner=scanner,
    description=data,
)

updatedScanner = cai.scanners.get(scanner=scanner.id)
print(f"Updated scanner: {updatedScanner}\n")
