#!/usr/bin/env python3

from pathlib import Path

from calypsoai import CalypsoAI

cai = CalypsoAI()

for prompt in cai.prompts.iterate(onlyUser=False):
    print(prompt.input, prompt.result.response)

with Path("prompts.jsonl").open("w", encoding="utf-8") as f:
    for prompt in cai.prompts.iterate(onlyUser=False):
        f.write(prompt.model_dump_json() + "\n")
        f.flush()
