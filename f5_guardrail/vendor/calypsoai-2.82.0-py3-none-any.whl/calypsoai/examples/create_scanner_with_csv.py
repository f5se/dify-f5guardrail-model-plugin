#!/usr/bin/env python3

from calypsoai import CalypsoAI
from calypsoai.examples.util import IO, Colour

cai = CalypsoAI()

prompt = None

name = IO.prompt("Scanner Name")

path = IO.prompt("Path to csv file, including the file name (example.csv is in this folder):")
file_name = IO.prompt("What to name the file:")
column_name = IO.prompt("Name of column to use: (example file conatins 'country' or 'capital'):")

scanner = cai.scanners.createCustomFromCsv(name=name, path=path, column=column_name)

print(f"Created Scanner: {scanner}\n")

scanners = cai.scanners.iterate()
enabled_ids = [scanner.id for scanner in scanners]

while data := IO.prompt(Colour.blue("Prompt to scan")):
    scans = cai.scans.scan(
        data,
        forceEnabled=[scanner.id],
        disabled=enabled_ids,
    ).result.scannerResults

    print(f"Results: {scans}\n")
