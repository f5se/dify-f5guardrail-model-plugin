#!/usr/bin/env python3

import os

from calypsoai import CalypsoAI

cai = CalypsoAI()

provider = cai.providers.create(
    "bedrock-claude",
    template={
        "type": "request",
        "method": "POST",
        "timeout": 20,
        "url": "https://bedrock-runtime.us-east-1.amazonaws.com/model/anthropic.claude-instant-v1/invoke",
        "headers": {"Content-Type": "application/json"},
        "json": '{{ { prompt: Func.reduce((text, p) => "\\n\\nHuman:" + p[0] + "\\n\\nAssistant:" '
        '+ p[1] + text, "", memory) + "\\n\\nHuman:" + prompt + "\\n\\nAssistant:", max_tokens_to_sample: 300 } }}',
        "awsAuth": {
            "accessKey": "{{ accessKey }}",
            "secretKey": "{{ secretKey }}",
            "service": "bedrock",
            "region": "us-east-1",
        },
        "outputs": {
            "statusCode": "{{ responseStatus }}",
            "content": "{{ responseStatus == 200 ? responseJson.completion : responseBody}}",
        },
    },
    secrets={
        "accessKey": {"name": "AWS Access Key ID", "value": os.environ["AWS_ACCESS_KEY_ID"]},
        "secretKey": {"name": "AWS Secret Access Key", "value": os.environ["AWS_SECRET_ACCESS_KEY"]},
    },
)
print(f"Created provider {provider.model_dump_json(indent=2)}")
