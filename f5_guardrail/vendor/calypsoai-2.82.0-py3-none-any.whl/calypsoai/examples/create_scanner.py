#!/usr/bin/env python3

from calypsoai import CalypsoAI
from calypsoai.examples.util import IO, Colour

cai = CalypsoAI()

prompt = None

name = IO.prompt("Scanner Name")

data = IO.prompt("Describe what should be scanned for")
response = cai.scanners.createCustom(
    name=name,
    description=data,
)

print(f"Scanner ID: {response.id}\n")

created_scanner = cai.scanners.get(response.id)

enabled_ids = []
if scanners := cai.projects.getScanners().scanners:
    enabled_ids = [c.id for k, c in scanners.items()]

print(f"Created Scanner: {created_scanner}\n")

while data := IO.prompt(Colour.blue("Prompt to scan")):
    scans = cai.scans.scan(
        data,
        forceEnabled=[created_scanner.id],
        disabled=enabled_ids,
    ).result.scannerResults

    print(f"Results: {scans}\n")
