#!/usr/bin/env python3

from calypsoai import CalypsoAI
from calypsoai.examples.util import IO

cai = CalypsoAI()

history = []

while data := input("You: "):
    prompts = cai.prompts.broadcast(input_=data, parent=history[-1] if history else None)

    for provider, prompt in prompts.items():
        print(f"\nLLM {provider} > {(prompt.result.response or '<Prompt blocked>').strip()}\n")

    if selection := IO.select(list(prompts.keys()), "Select a response"):
        history.append(prompts[selection])
    else:
        break
