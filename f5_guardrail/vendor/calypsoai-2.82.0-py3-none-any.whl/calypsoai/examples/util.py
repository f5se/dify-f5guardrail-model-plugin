from collections.abc import Callable
from enum import Enum
from typing import TypeVar


class Colour(str, Enum):
    white = "\033[1;37m"
    red = "\033[1;31m"
    green = "\033[1;32m"
    blue = "\033[1;34m"
    clear = "\033[0m"

    def __call__(self, string: str) -> str:
        return f"{self.value}{string}{Colour.clear.value}"


Item = TypeVar("Item")


class IO:
    @staticmethod
    def select(items: list[Item], message: str, itemRepr: Callable[[Item], str] = str) -> Item | None:
        prompt = message + "\n" + "\n".join(f"{i} {itemRepr(item)}" for i, item in enumerate(items, start=1)) + "\n> "
        while selection := input(prompt):
            try:
                return items[int(selection) - 1]
            except (ValueError, IndexError):
                continue
        return None

    @staticmethod
    def prompt(message: str, default: str | None = None) -> str:
        if default:
            return input(f"{message} [{default}] > ") or default
        return input(f"{message} > ")
