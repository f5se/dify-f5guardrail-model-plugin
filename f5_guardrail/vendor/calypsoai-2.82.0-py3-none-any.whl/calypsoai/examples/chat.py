#!/usr/bin/env python3

from calypsoai import CalypsoAI
from calypsoai.examples.util import IO

cai = CalypsoAI()

prompt = None

while data := IO.prompt("Prompt"):
    prompt = cai.prompts.send(
        data,
        provider="gpt-4",
        parent=prompt,
    )

    print(f"LLM > {prompt.result.response}\n")
