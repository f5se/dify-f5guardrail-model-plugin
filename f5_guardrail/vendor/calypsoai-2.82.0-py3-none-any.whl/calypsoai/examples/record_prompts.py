#!/usr/bin/env python3

from calypsoai import CalypsoAI

cai = CalypsoAI()

name = "org.preferences.record_prompts"

preferences = cai.organizations.getPreferences()

current_value = bool(
    next((preference.value for preference in preferences if preference.name == name), None),
)

cai.organizations.updatePreferences({name: not current_value})

updated_value = bool(
    next((preference.value for preference in preferences if preference.name == name), None),
)

print(f"Prompt recording turned {'on' if updated_value else 'off'}.")
