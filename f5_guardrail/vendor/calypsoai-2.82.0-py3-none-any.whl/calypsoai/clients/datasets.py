from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class DatasetsRunsDownloadClient(_BaseClient):
    """Client for all requests under '/datasets/runs/{datasetRunId}/download'."""

    def get(
        self,
        datasetRunId: UUID | str,
    ) -> bytes:
        """Send GET request to '/backend/v1/datasets/runs/{datasetRunId}/download'.

        Get

        Args:
            datasetRunId: ID of the dataset run

        Returns:
            Raw binary content of the response body.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path=f"/backend/v1/datasets/runs/{datasetRunId}/download",
            queryParams={},
            responseModel=None,
            responseContentType="text/csv",
        )


class DatasetsRunsClient(_BaseClient):
    """Client for all requests under '/datasets/runs'."""

    download: DatasetsRunsDownloadClient
    "Client for all requests under '/datasets/runs/{datasetRunId}/download'."

    def get(
        self,
        *,
        includeScanners: bool = False,
        includeScannerPackages: bool = False,
        includeUsers: bool = False,
        limit: int = 10,
        includeDatasets: bool = False,
    ) -> dt.GetDatasetRunsResponse:
        """Send GET request to '/backend/v1/datasets/runs'.

        Get

        Args:
            includeScanners: Include guardrails in the response.
            includeScannerPackages: Include guardrail packages in the response.
            includeUsers: Include the users that created the datasets in the response.
            limit: Limits the amount of results.
            includeDatasets: Include datasets in the response

        Returns:
            GetDatasetRunsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/datasets/runs",
            queryParams={
                "includeScanners": includeScanners,
                "includeScannerPackages": includeScannerPackages,
                "includeUsers": includeUsers,
                "limit": limit,
                "includeDatasets": includeDatasets,
            },
            responseModel=dt.GetDatasetRunsResponse,
            responseContentType="application/json",
        )

    def getDatasetRunId(
        self,
        datasetRunId: UUID | str,
        *,
        includeDataset: bool = False,
        includeScanner: bool = False,
        includeScannerPackage: bool = False,
        includeUser: bool = False,
    ) -> dt.GetDatasetRunResponse:
        """Send GET request to '/backend/v1/datasets/runs/{datasetRunId}'.

        Get

        Args:
            datasetRunId: ID of the dataset run
            includeDataset: Include dataset in the response
            includeScanner: Include scanner in the response
            includeScannerPackage: Include guardrail package in the response if one is associated to the
                                   dataset
            includeUser: Include user in the response

        Returns:
            GetDatasetRunResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path=f"/backend/v1/datasets/runs/{datasetRunId}",
            queryParams={
                "includeDataset": includeDataset,
                "includeScanner": includeScanner,
                "includeScannerPackage": includeScannerPackage,
                "includeUser": includeUser,
            },
            responseModel=dt.GetDatasetRunResponse,
            responseContentType="application/json",
        )


class DatasetsClient(_BaseClient):
    """Client for all requests under '/datasets'."""

    runs: DatasetsRunsClient
    "Client for all requests under '/datasets/runs'."

    def get(
        self,
        *,
        includeScanners: bool = False,
        includeScannerPackages: bool = False,
        includeUsers: bool = False,
        limit: int = 10,
        includeRuns: bool = False,
    ) -> dt.GetDatasetsResponse:
        """Send GET request to '/backend/v1/datasets'.

        Get

        Args:
            includeScanners: Include guardrails in the response.
            includeScannerPackages: Include guardrail packages in the response.
            includeUsers: Include the users that created the datasets in the response.
            limit: Limits the amount of results.
            includeRuns: Include dataset runs in the response

        Returns:
            GetDatasetsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/datasets",
            queryParams={
                "includeScanners": includeScanners,
                "includeScannerPackages": includeScannerPackages,
                "includeUsers": includeUsers,
                "limit": limit,
                "includeRuns": includeRuns,
            },
            responseModel=dt.GetDatasetsResponse,
            responseContentType="application/json",
        )

    def post(
        self,
        body: dict,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/datasets'.

        Post

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/datasets",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    def getDatasetId(
        self,
        datasetId: UUID | str,
    ) -> dt.GetDatasetResponse:
        """Send GET request to '/backend/v1/datasets/{datasetId}'.

        Get

        Args:
            datasetId: ID of the dataset

        Returns:
            GetDatasetResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path=f"/backend/v1/datasets/{datasetId}",
            queryParams={},
            responseModel=dt.GetDatasetResponse,
            responseContentType="application/json",
        )
