import contextlib
import inspect
import logging
import os
from http import HTTPStatus
from io import BytesIO
from typing import TYPE_CHECKING, TypeVar, cast, get_type_hints
from urllib.parse import urljoin, urlparse, urlunparse
from zipfile import ZipFile

import orjson
from pydantic import BaseModel, TypeAdapter
from requests_toolbelt.multipart.encoder import MultipartEncoder
from typing_extensions import Self

if TYPE_CHECKING:
    from aiohttp import ClientSession
    from requests import Session

else:
    try:
        from aiohttp import ClientSession
    except ImportError:
        ClientSession = None

    try:
        from requests import Session
    except ImportError:
        Session = None

R = TypeVar("R")

logger = logging.getLogger("calypsoai")


class RequestError(Exception):
    """Exception raised for non-success responses from the CalyspoaAI API."""

    def __init__(
        self,
        *,
        method: str,
        url: str,
        statusCode: int,
        text: str,
        json_: str | dict | list | float | bool | None,
        message: str | None = None,
    ) -> None:
        """Create a new error from request details.

        :param method: HTTP method used for the request
        :param url: Url of the request.
        :param statusCode: Response status code.
        :param text: Response body in text form.
        :param json: Response body in JSON if valid.
        """
        self.method = method.upper()
        self.url = url
        self.statusCode = statusCode
        self.text = text
        self.json = json_
        self.message = message or self.text

    def __str__(self) -> str:
        message = self.message + "\n" if self.message else ""
        if self.message:
            message = self.message
        elif self.json is not None:
            message = orjson.dumps(self.json, option=orjson.OPT_INDENT_2).decode()
        else:
            message = self.text
        return f"'{self.method} {self.url}' responded with status {self.statusCode}\n{message}"

    def __repr__(self) -> str:
        return f"RequestError<{self.method} {self.url}: {self.statusCode}>"


_empty = object()


class _RequestProxy:
    def __init__(
        self,
        *,
        url: str | None,
        token: str | None,
        headers: dict | None = None,
        isAsync: bool = False,
        verify_tls: bool = True,
    ) -> None:
        self._url = url
        self._token = token
        self._headers = headers
        self._isAsync = isAsync
        self._session = None
        self._verify_tls = verify_tls

    def _prepareSession(self, *, isAsync: bool) -> ClientSession | Session:
        session = (ClientSession() if ClientSession else None) if isAsync else Session() if Session else None

        if not session:
            msg = "CalypsoAIAsyncClient client needs aiohttp" if isAsync else "CalypsoAIClient needs requests"
            raise ImportError(msg)

        if not self._url:
            url = os.environ.get("CALYPSOAI_URL")
            if not url:
                url = "https://calypsoai.app"
            parsed = urlparse(url)
            if not parsed.scheme:
                scheme = "http" if parsed.hostname in {"localhost", "127.0.0.1"} else "https"
                logger.debug("Assuming scheme %s for host %s", scheme, url)
                url = urlunparse(parsed._replace(scheme=scheme))
            self._url = url

        if token := self._token or os.environ.get("CALYPSOAI_TOKEN"):
            logger.debug("Using token authentication")
            session.headers["Authorization"] = f"Bearer {token}"
        else:
            logger.debug("No token provided, requests will be unauthenticated")

        if self._headers:
            session.headers.update(self._headers)

        return session

    def start(self) -> None:
        if not self._session:
            self._session = self._prepareSession(isAsync=self._isAsync)

    def stop(self) -> None:
        if self._session:
            return self._session.close()
        return None

    def request(
        self,
        *,
        method: str,
        path: str,
        queryParams: dict,
        responseModel: type[R] | None,
        body: dict | BaseModel | None = _empty,
        contentType: str | None = None,
        responseContentType: str,
    ) -> R:
        if not self._session:
            self._session = self._prepareSession(isAsync=self._isAsync)

        method, url, queryParamsIter, rawBody, contentType = self._prepareRequest(
            method,
            path,
            queryParams,
            body,
            contentType,
        )

        response = cast("Session", self._session).request(
            method=method,
            url=url,
            params=queryParamsIter,
            data=rawBody,
            verify=self._verify_tls,
            headers={"Content-Type": contentType},
        )

        return self._processResponse(
            method=method,
            url=url,
            rawResponse=response.content,
            statusCode=response.status_code,
            responseModel=responseModel,
            responseContentType=responseContentType,
        )

    async def asyncRequest(
        self,
        *,
        method: str,
        path: str,
        queryParams: dict,
        responseModel: type[R] | None,
        body: dict | BaseModel | None = _empty,
        contentType: str | None = None,
        responseContentType: str,
    ) -> R:
        if not self._session:
            self._session = self._prepareSession(isAsync=self._isAsync)

        method, url, queryParams, rawBody, contentType = self._prepareRequest(
            method,
            path,
            queryParams,
            body,
            contentType,
        )

        async with cast("ClientSession", self._session).request(
            method=method,
            url=url,
            params=queryParams,
            headers={"Content-Type": contentType},
            data=rawBody,
            ssl=self._verify_tls,
        ) as response:
            return self._processResponse(
                method=method,
                url=url,
                rawResponse=await response.content.read(),
                statusCode=response.status,
                responseModel=responseModel,
                responseContentType=responseContentType,
            )

    def _prepareRequest(
        self,
        method: str,
        path: str,
        queryParams: dict,
        body: BaseModel | dict,
        contentType: str | None,
    ) -> tuple[str, str, list, bytes, str]:
        if isinstance(body, BaseModel):
            body = body.model_dump(exclude_none=True, mode="json", by_alias=True)

        method = method.upper()
        url = urljoin(self._url, path)

        if contentType == "multipart/form-data":
            fields = []

            for key, value in body.items():
                if isinstance(value, list):
                    fields.extend((key, v) for v in value)
                elif isinstance(value, dict) and "data" in value:
                    fields.append((key, (value.get("filename", "file"), value["data"], value.get("contentType"))))
                else:
                    fields.append((key, value))

            encoder = MultipartEncoder(fields)
            rawBody = encoder.to_string()
            contentType = encoder.content_type

        else:
            rawBody = orjson.dumps(body) if body is not _empty else None
            contentType = "application/json"

        logger.debug(
            "Request %s %s with\n Query Params: %s\nBody: %s",
            method.upper(),
            path,
            queryParams,
            rawBody,
        )
        paramsIter = [
            (name, val)
            for name, value in queryParams.items()
            for val in (value if isinstance(value, list) else [value])
        ]

        return (
            method,
            url,
            paramsIter,
            rawBody,
            contentType,
        )

    def _processResponse(
        self,
        *,
        method: str,
        url: str,
        rawResponse: bytes,
        statusCode: int,
        responseModel: type[R] | None,
        responseContentType: str,
    ) -> R:
        if statusCode >= HTTPStatus.BAD_REQUEST:
            message = resJson = None
            with contextlib.suppress(Exception):
                resJson = orjson.loads(rawResponse)

            if isinstance(resJson, dict) and "message" in resJson:
                message = resJson["message"]

            raise RequestError(
                method=method,
                url=url,
                statusCode=statusCode,
                text=rawResponse.decode(),
                json_=resJson,
                message=message,
            )
        match responseContentType:
            case "application/json":
                responseJson = orjson.loads(rawResponse)
                return (
                    TypeAdapter(responseModel).validate_python(responseJson, strict=False)
                    if responseModel
                    else responseJson
                )
            case "application/zip":
                buf = BytesIO(rawResponse)
                return ZipFile(buf)
            case "application/octet-stream":
                return rawResponse
            case _:
                msg = f"Can't parse content type {responseContentType!r}"
                raise NotImplementedError(msg)


class _BaseClient:
    def __init__(self, requestProxy: _RequestProxy) -> None:
        self._requestProxy = requestProxy

    # Hide from type checking so bad property names raise type errors during linting.
    if not TYPE_CHECKING:

        def __getattr__(self, name: str) -> object:
            clientClass = None
            for cls in self.__class__.__mro__[:-1]:
                annotations = get_type_hints(cls)
                if clientClass := annotations.get(name):
                    break

            msg = None
            if not clientClass:
                msg = f"Attribute not found {name}"
            if not inspect.isclass(clientClass) or not issubclass(
                clientClass,
                _BaseClient,
            ):
                msg = f"Attribute is not a sub-client {name}"

            if msg:
                raise AttributeError(msg)
            client = clientClass(self._requestProxy)
            setattr(self, name, client)
            return client


class BaseCalypsoAIClient(_BaseClient):  # noqa: D101
    def __init__(
        self,
        url: str | None = None,
        token: str | None = None,
        headers: dict | None = None,
        *,
        verify_tls: bool = True,
    ) -> None:
        requestProxy = _RequestProxy(
            url=url,
            token=token,
            headers=headers,
            isAsync=False,
            verify_tls=verify_tls,
        )
        super().__init__(requestProxy)

        if not url:
            url = os.environ.get("CALYPSOAI_URL")
            if not url:
                url = "https://calypsoai.app"
            parsed = urlparse(url)
            if not parsed.scheme:
                scheme = "http" if parsed.hostname in {"localhost", "127.0.0.1"} else "https"
                logger.debug("Assuming scheme %s for host %s", scheme, url)
                url = urlunparse(parsed._replace(scheme=scheme))

    def start(self) -> None:
        """Initialize this client."""
        self._requestProxy.start()

    def stop(self) -> None:
        """Stop this client and close all connections."""
        self._requestProxy.stop()

    def __enter__(self: Self) -> Self:
        self.start()
        return self

    def __exit__(self, *_) -> None:  # noqa: ANN002
        self.stop()


class BaseCalypsoAIAsyncClient(_BaseClient):  # noqa: D101
    def __init__(
        self,
        url: str | None = None,
        token: str | None = None,
        headers: dict | None = None,
        *,
        verify_tls: bool = True,
    ) -> None:
        requestProxy = _RequestProxy(
            url=url,
            token=token,
            headers=headers,
            isAsync=True,
            verify_tls=verify_tls,
        )
        super().__init__(requestProxy)

    async def start(self) -> None:
        """Initialize this client."""
        self._requestProxy.start()

    async def stop(self) -> None:
        """Stop this client and close all connections."""
        await self._requestProxy.stop()

    async def __aenter__(self: Self) -> Self:
        await self.start()
        return self

    async def __aexit__(self, *_) -> None:  # noqa: ANN002
        await self.stop()


__all__ = [
    "BaseCalypsoAIAsyncClient",
    "BaseCalypsoAIClient",
    "RequestError",
    "_BaseClient",
    "_RequestProxy",
]
