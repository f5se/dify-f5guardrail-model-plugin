from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class ProjectClient(_BaseClient):
    """Client for all requests under '/project'."""

    def get(
        self,
        *,
        chatbotId: UUID | str | None = None,
    ) -> dt.GetGlobalProjectResponse:
        """Send GET request to '/backend/v1/project'.

        Get default project.

        Retrieves the default project for the specified group or chatbot, or the global settings if neither is provided.

        Args:
            chatbotId: ID of chatbot to get the project for.

        Returns:
            GetGlobalProjectResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/project",
            queryParams={
                "chatbotId": chatbotId,
            },
            responseModel=dt.GetGlobalProjectResponse,
            responseContentType="application/json",
        )
