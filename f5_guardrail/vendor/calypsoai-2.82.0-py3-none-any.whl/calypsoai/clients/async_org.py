from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class OrgPreferencesAsyncClient(_BaseClient):
    """Async client for all requests under '/org/preferences'."""

    async def get(
        self,
    ) -> dt.GetOrganizationPreferencesResponse:
        """Send GET request to '/backend/v1/org/preferences'.

        Get org preferences.

        Retrieves all organization preferences.

        Returns:
            GetOrganizationPreferencesResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/org/preferences",
            queryParams={},
            responseModel=dt.GetOrganizationPreferencesResponse,
            responseContentType="application/json",
        )

    async def patch(
        self,
        body: dt.PatchOrganizationPreferencesBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/org/preferences'.

        Update org preferences.

        Modifies the organization preferences.

        Args:
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path="/backend/v1/org/preferences",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class OrgAsyncClient(_BaseClient):
    """Async client for all requests under '/org'."""

    preferences: OrgPreferencesAsyncClient
    "Async client for all requests under '/org/preferences'."

    async def get(
        self,
    ) -> dt.GetOrgResponse:
        """Send GET request to '/backend/v1/org'.

        Get organization.

        Retrieves the organization details.

        Returns:
            GetOrgResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/org",
            queryParams={},
            responseModel=dt.GetOrgResponse,
            responseContentType="application/json",
        )

    async def patch(
        self,
        body: dt.PatchOrgBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/org'.

        Update organization.

        Modifies the organization's name, application URL, and enables multi-factor authentication.

        Args:
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path="/backend/v1/org",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dt.PostOrgBody | dict,
    ) -> dt.PostOrgResponse:
        """Send POST request to '/backend/v1/org'.

        Create organization.

        Creates a new organization with the given name.

        Args:
            body: Body of the request

        Returns:
            PostOrgResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/org",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostOrgResponse,
            responseContentType="application/json",
        )
