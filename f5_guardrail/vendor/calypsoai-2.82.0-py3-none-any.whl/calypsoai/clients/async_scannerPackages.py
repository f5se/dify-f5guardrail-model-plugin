from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class ScannerPackagesAccessAsyncClient(_BaseClient):
    """Async client for all requests under '/scanner-packages/{scannerPackageId}/access'."""

    async def patch(
        self,
        scannerPackageId: UUID | str,
        body: dt.PatchScannerPackageAccessBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/scanner-packages/{scannerPackageId}/access'.

        Update scanner package availability.

        Updates the availability of a guardrail package across projects.

        Args:
            scannerPackageId: ID of the scanner package
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/scanner-packages/{scannerPackageId}/access",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class ScannerPackagesAsyncClient(_BaseClient):
    """Async client for all requests under '/scanner-packages'."""

    access: ScannerPackagesAccessAsyncClient
    "Async client for all requests under '/scanner-packages/{scannerPackageId}/access'."

    async def get(
        self,
        *,
        cursor: str | None = None,
        search: str | None = None,
        limit: int = 10,
        ascending: bool = False,
        published: bool | None = None,
        direction: dt.ScannerDirection | str | None = None,
        source: list[dt.ScannerSourceType | str] | None = None,
        type_: list[dt.ScanType | str] | None = None,
        packaged: bool | None = None,
        sortBy: dt.ScannerSearchSortBy | str = "created_at",
        active: bool | None = None,
        groupId: UUID | str | None = None,
        endpoint: UUID | str | None = None,
        enabledForProject: UUID | str | None = None,
        tags: list[str] | None = None,
        addedToProjectId: UUID | str | None = None,
        accessibleToProjectId: UUID | str | None = None,
        packageId: UUID | str | list[UUID | str] | None = None,
        mode: list[dt.ScanMode | str] | None = None,
    ) -> dt.GetScannerPackagesResponse:
        """Send GET request to '/backend/v1/scanner-packages'.

        Get guardrail packages.

        Retrieves a list of guardrail packages that match the given criteria,
        with the option to adjust the limit for more results.

        Args:
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            search: Only return results that match the given text.
            limit: Limits the amount of results.
            ascending: Whether results should be sorted in ascending order.
            published: Get guardrails that match the given published state.
            direction: Get results that scan in the given direction.
            source: Get results that were created from the given source.
            type_: Get results that are of the given scan type.
            packaged: Get results that are packaged or not.
            sortBy: Sort results by the given parameter.
            active: Get results that are active/inactive. Only has an effect if addedToProjectId or
                    availableToProjectId is provided.
            groupId: Get results created for the given group.
            endpoint: Get results match the chosen active state for the given endpoint.
            enabledForProject: Get results match the chosen active state for the given project.
            tags: Get results with the given tags.
            addedToProjectId: Get guardrails added to project.
            accessibleToProjectId: Get guardrails accessible to project.
            packageId: Get guardrails that belong to the specified packages.
            mode: Get guardrails that are set to given mode(s) for the chosen project.

        Returns:
            GetScannerPackagesResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        if packageId is None:
            packageId = []
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/scanner-packages",
            queryParams={
                "cursor": cursor,
                "search": search,
                "limit": limit,
                "ascending": ascending,
                "published": published,
                "direction": direction,
                "source": source,
                "type": type_,
                "packaged": packaged,
                "sortBy": sortBy,
                "active": active,
                "groupId": groupId,
                "endpoint": endpoint,
                "enabledForProject": enabledForProject,
                "tags": tags,
                "addedToProjectId": addedToProjectId,
                "accessibleToProjectId": accessibleToProjectId,
                "packageId": packageId,
                "mode": mode,
            },
            responseModel=dt.GetScannerPackagesResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dt.PostPackageRequest | dict,
    ) -> dt.PostIDResponse:
        """Send POST request to '/backend/v1/scanner-packages'.

        Create guardrail package.

        Creates a new guardrail package.

        Args:
            body: Body of the request

        Returns:
            PostIDResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/scanner-packages",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostIDResponse,
            responseContentType="application/json",
        )

    async def deleteScannerPackageId(
        self,
        scannerPackageId: UUID | str,
        body: dict | dt.DeleteScannerPackageBody | None = None,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/scanner-packages/{scannerPackageId}'.

        Delete guardrail package.

        Deletes a guardrail package by ID. You can optionally delete the guardrails included in the package.

        Args:
            scannerPackageId: ID of the scanner package
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/scanner-packages/{scannerPackageId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def getScannerPackageId(
        self,
        scannerPackageId: UUID | str,
    ) -> dt.GetScannerPackageResponse:
        """Send GET request to '/backend/v1/scanner-packages/{scannerPackageId}'.

        Get guardrail package.

        Retrieves a guardrail package by ID.

        Args:
            scannerPackageId: ID of the scanner package

        Returns:
            GetScannerPackageResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/scanner-packages/{scannerPackageId}",
            queryParams={},
            responseModel=dt.GetScannerPackageResponse,
            responseContentType="application/json",
        )

    async def patchScannerPackageId(
        self,
        scannerPackageId: UUID | str,
        body: dict | dt.PatchScannerPackageBody | dt.UpdateScannerPackageFromSourceBody,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/scanner-packages/{scannerPackageId}'.

        Update guardrail package.

        Updates a guardrail package by ID.

        Args:
            scannerPackageId: ID of the scanner package
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/scanner-packages/{scannerPackageId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
