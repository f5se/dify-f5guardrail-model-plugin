from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class EndpointClient(_BaseClient):
    """Client for all requests under '/endpoint'."""

    def get(
        self,
        *,
        groupId: UUID | str | None = None,
        chatbotId: UUID | str | None = None,
    ) -> dt.GetGlobalEndpointResponse:
        """Send GET request to '/backend/v1/endpoint'.

        Get the default endpoint for the group/chatbot specified or global settings if neither is given.

        Get the default endpoint for the group/chatbot specified or global settings if neither is given.

        Args:
            groupId: ID of group to get the endpoint for.
            chatbotId: ID of chatbot to get the endpoint for.

        Returns:
            GetGlobalEndpointResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/endpoint",
            queryParams={
                "groupId": groupId,
                "chatbotId": chatbotId,
            },
            responseModel=dt.GetGlobalEndpointResponse,
            responseContentType="application/json",
        )
