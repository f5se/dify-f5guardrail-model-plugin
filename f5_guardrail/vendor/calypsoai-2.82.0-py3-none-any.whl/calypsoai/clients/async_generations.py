from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class GenerationsAsyncClient(_BaseClient):
    """Async client for all requests under '/generations'."""

    async def post(
        self,
        body: dt.PostGenerationsBody | dict,
    ) -> dt.PostGenerationResponse:
        """Send POST request to '/backend/v1/generations'.

        Post

        Args:
            body: Body of the request

        Returns:
            PostGenerationResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/generations",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostGenerationResponse,
            responseContentType="application/json",
        )
