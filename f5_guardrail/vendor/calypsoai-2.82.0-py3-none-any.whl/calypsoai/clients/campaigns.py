from datetime import datetime
from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class CampaignsClient(_BaseClient):
    """Client for all requests under '/campaigns'."""

    def get(
        self,
        *,
        cursor: str | None = None,
        ascending: bool = False,
        limit: int = 10,
        vendored: bool = False,
        attackTechnique: list[dt.AttackTechnique | str] | None = None,
        before: datetime | str | None = None,
        after: datetime | str | None = None,
        lastRunBefore: datetime | str | None = None,
        lastRunAfter: datetime | str | None = None,
        sortBy: dt.CampaignSortBy | str = "created_at",
        includeUsers: bool = False,
    ) -> dt.GetCampaignsResponse:
        """Send GET request to '/backend/v1/campaigns'.

        Get campaigns.

        Retrieves a list of campaigns that match the given criteria,
        with the option to adjust the limit for more results.

        Args:
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            ascending: Whether results should be sorted in ascending order.
            limit: Number of results to return.
            vendored: If true, return vendored campaigns created by the system.
            attackTechnique: Filter by campaigns that include an attack of these types
            before: Only return campaigns created before this timestamp.
            after: Only return campaigns created after this timestamp.
            lastRunBefore: Only return campaigns that last ran before this timestamp.
            lastRunAfter: Only return campaigns that last ran after this timestamp.
            sortBy: Sort results by the given parameter.
            includeUsers: Include users

        Returns:
            GetCampaignsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/campaigns",
            queryParams={
                "cursor": cursor,
                "ascending": ascending,
                "limit": limit,
                "vendored": vendored,
                "attackTechnique": attackTechnique,
                "before": before,
                "after": after,
                "lastRunBefore": lastRunBefore,
                "lastRunAfter": lastRunAfter,
                "sortBy": sortBy,
                "includeUsers": includeUsers,
            },
            responseModel=dt.GetCampaignsResponse,
            responseContentType="application/json",
        )

    def post(
        self,
        body: dt.PostCampaignsBody | dict,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/campaigns'.

        Create campaign.

        Creates a new campaign. You can specify the campaign's name, description, and associated attacks.

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/campaigns",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    def deleteCampaignId(
        self,
        campaignId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/campaigns/{campaignId}'.

        Delete a campaign.

        Deletes a campaign.

        Args:
            campaignId: ID of the campaign

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="delete",
            path=f"/backend/v1/campaigns/{campaignId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    def getCampaignId(
        self,
        campaignId: UUID | str,
        *,
        configAt: datetime | str | None = None,
    ) -> dt.GetCampaignResponse:
        """Send GET request to '/backend/v1/campaigns/{campaignId}'.

        Get campaign.

        Retrieves a campaign by its ID.

        Args:
            campaignId: ID of the campaign
            configAt: Get the config at a given point in time.

        Returns:
            GetCampaignResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path=f"/backend/v1/campaigns/{campaignId}",
            queryParams={
                "configAt": configAt,
            },
            responseModel=dt.GetCampaignResponse,
            responseContentType="application/json",
        )

    def patchCampaignId(
        self,
        campaignId: UUID | str,
        body: dt.PatchCampaignBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/campaigns/{campaignId}'.

        Update campaign.

        Updates a campaign. You can modify the campaign's name, description, and associated attacks.

        Args:
            campaignId: ID of the campaign
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="patch",
            path=f"/backend/v1/campaigns/{campaignId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
