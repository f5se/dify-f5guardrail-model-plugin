from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class AgentSessionsAsyncClient(_BaseClient):
    """Async client for all requests under '/agent-sessions'."""

    async def get(
        self,
        *,
        limit: int = 10,
        sortBy: dt.AgentSessionSortBy | str = "updated_at",
        cursor: str | None = None,
        project: UUID | str | None = None,
        ascending: bool = False,
    ) -> dt.GetAgentSessionsResponse:
        """Send GET request to '/backend/v1/agent-sessions'.

        Get

        Args:
            limit: Number of results to return.
            sortBy: Sort results by the given parameter.
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            project: Project to retrieve agent sessions for
            ascending: Whether results should be sorted in ascending order.

        Returns:
            GetAgentSessionsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/agent-sessions",
            queryParams={
                "limit": limit,
                "sortBy": sortBy,
                "cursor": cursor,
                "project": project,
                "ascending": ascending,
            },
            responseModel=dt.GetAgentSessionsResponse,
            responseContentType="application/json",
        )
