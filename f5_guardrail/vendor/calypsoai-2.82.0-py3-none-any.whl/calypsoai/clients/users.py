from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class UsersMeClient(_BaseClient):
    """Client for all requests under '/users/me'."""

    def get(
        self,
    ) -> dt.GetUsersMeResponse:
        """Send GET request to '/backend/v1/users/me'.

        Get authenticated user.

        Retrieves the currently authenticated user's information.

        Returns:
            GetUsersMeResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/users/me",
            queryParams={},
            responseModel=dt.GetUsersMeResponse,
            responseContentType="application/json",
        )


class UsersTokenVerificationClient(_BaseClient):
    """Client for all requests under '/users/token-verification'."""

    def post(
        self,
        body: dt.PostUsersVerificationBody | dict,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/users/token-verification'.

        Set user's password.

        Verifies a user with a token and sets the user's password.

        Args:
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/users/token-verification",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class UsersMultifactorClient(_BaseClient):
    """Client for all requests under '/users/{userId}/multifactor'."""

    def delete(
        self,
        userId: str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/users/{userId}/multifactor'.

        Reset multi-factor authentication.

        Resets multi-factor authentication for a user.

        Args:
            userId: ID of the user

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="delete",
            path=f"/backend/v1/users/{userId}/multifactor",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class UsersRolesClient(_BaseClient):
    """Client for all requests under '/users/{userId}/roles'."""

    def deleteRoleId(
        self,
        userId: str,
        roleId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/users/{userId}/roles/{roleId}'.

        Retract role from user.

        Removes a specified role from a user.

        Args:
            userId: ID of the user
            roleId: ID of the role

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="delete",
            path=f"/backend/v1/users/{userId}/roles/{roleId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    def postRoleId(
        self,
        userId: str,
        roleId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/users/{userId}/roles/{roleId}'.

        Assign role to user.

        Assigns a specified role to a user.

        Args:
            userId: ID of the user
            roleId: ID of the role

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path=f"/backend/v1/users/{userId}/roles/{roleId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class UsersVerificationResendClient(_BaseClient):
    """Client for all requests under '/users/{userId}/verification/resend'."""

    def post(
        self,
        userId: str,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/users/{userId}/verification/resend'.

        Re-sends users verification email.

        Sends the verification email again to the user.

        Args:
            userId: ID of the user

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path=f"/backend/v1/users/{userId}/verification/resend",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class UsersVerificationTokenClient(_BaseClient):
    """Client for all requests under '/users/{userId}/verification/token'."""

    def post(
        self,
        userId: str,
    ) -> dt.PostVerificationTokenResponse:
        """Send POST request to '/backend/v1/users/{userId}/verification/token'.

        Generate verification token.

        Generates a token for a user to verify their account and set their password.

        Args:
            userId: ID of the user

        Returns:
            PostVerificationTokenResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path=f"/backend/v1/users/{userId}/verification/token",
            queryParams={},
            responseModel=dt.PostVerificationTokenResponse,
            responseContentType="application/json",
        )


class UsersVerificationClient(_BaseClient):
    """Client for all requests under '/users/{userId}/verification'."""

    resend: UsersVerificationResendClient
    "Client for all requests under '/users/{userId}/verification/resend'."
    token: UsersVerificationTokenClient
    "Client for all requests under '/users/{userId}/verification/token'."


class UsersClient(_BaseClient):
    """Client for all requests under '/users'."""

    me: UsersMeClient
    "Client for all requests under '/users/me'."
    tokenVerification: UsersTokenVerificationClient
    "Client for all requests under '/users/token-verification'."
    multifactor: UsersMultifactorClient
    "Client for all requests under '/users/{userId}/multifactor'."
    roles: UsersRolesClient
    "Client for all requests under '/users/{userId}/roles'."
    verification: UsersVerificationClient
    "Client for all requests under '/users/{userId}/verification'."

    def get(
        self,
        *,
        search: str | None = None,
        cursor: str | None = None,
        limit: int = 10,
        project: UUID | str | None = None,
        groupId: UUID | str | None = None,
        roleId: UUID | str | None = None,
        includeRoles: bool = False,
    ) -> dt.GetUsersResponse:
        """Send GET request to '/backend/v1/users'.

        Get users.

        Retrieves a list of users matching the given filter criteria,
        with the option to adjust the limit for more results.

        Args:
            search: User's name or email address for filtering results
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            limit: Number of results to return.
            project: If provided, returns only users in that project
            groupId: If provided, returns only users in the specified group.
            roleId: If provided, returns only users assigned to that role
            includeRoles: Include all of the roles from the returned users in the response.

        Returns:
            GetUsersResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/users",
            queryParams={
                "search": search,
                "cursor": cursor,
                "limit": limit,
                "project": project,
                "groupId": groupId,
                "roleId": roleId,
                "includeRoles": includeRoles,
            },
            responseModel=dt.GetUsersResponse,
            responseContentType="application/json",
        )

    def post(
        self,
        body: dt.PostUserBody | dict,
    ) -> dt.PostUserResponse:
        """Send POST request to '/backend/v1/users'.

        Create user.

        Creates a new user.

        Args:
            body: Body of the request

        Returns:
            PostUserResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/users",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostUserResponse,
            responseContentType="application/json",
        )

    def deleteUserId(
        self,
        userId: str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/users/{userId}'.

        Delete user.

        Deletes a user by their ID.

        Args:
            userId: ID of the user

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="delete",
            path=f"/backend/v1/users/{userId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    def getUserId(
        self,
        userId: str,
        *,
        includeRoles: bool = False,
    ) -> dt.GetUserResponse:
        """Send GET request to '/backend/v1/users/{userId}'.

        Get user.

        Retrieves a user by their ID.

        Args:
            userId: ID of the user
            includeRoles: Include the user's roles in the response

        Returns:
            GetUserResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path=f"/backend/v1/users/{userId}",
            queryParams={
                "includeRoles": includeRoles,
            },
            responseModel=dt.GetUserResponse,
            responseContentType="application/json",
        )

    def patchUserId(
        self,
        userId: str,
        body: dt.PatchUserBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/users/{userId}'.

        Update user.

        Updates a user by their ID.

        Only users can change their own name.
        Users created through social account connections (Google, Microsoft) cannot change their names.

        Args:
            userId: ID of the user
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="patch",
            path=f"/backend/v1/users/{userId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
