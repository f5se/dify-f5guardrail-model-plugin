from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class TokensClient(_BaseClient):
    """Client for all requests under '/tokens'."""

    def get(
        self,
        *,
        machine: bool = False,
        groupId: UUID | str | None = None,
        projectId: UUID | str | None = None,
        limit: int = 10,
        cursor: str | None = None,
    ) -> dt.GetTokensResponse:
        """Send GET request to '/backend/v1/tokens'.

        Get API tokens.

        Retrieves a list of tokens matching the given filter criteria,
        with the option to adjust the limit for more results.
        The token values are obfuscated.

        Args:
            machine: If true returns only machine tokens, if false doesn't return machine tokens
            groupId: If set to the Id of a user group and machine=True, returns machine tokens for only that
                     specific user group. Has no effect if machine=False
            projectId: If set to the Id of a user group and machine=True, returns machine tokens for only
                       that specific user group. Has no effect if machine=False
            limit: Limits the amount of returned objects. Max 100, min 1
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response.

        Returns:
            GetTokensResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/tokens",
            queryParams={
                "machine": machine,
                "groupId": groupId,
                "projectId": projectId,
                "limit": limit,
                "cursor": cursor,
            },
            responseModel=dt.GetTokensResponse,
            responseContentType="application/json",
        )

    def post(
        self,
        body: dict | dt.PostTokensBody | dt.PostTokensMachineBody,
    ) -> dt.PostTokensResponse:
        """Send POST request to '/backend/v1/tokens'.

        Create API token.

        Creates an API token.
        Based on the provided body,
        it will either create a machine token for the org or user group, or a personal API token.

        Args:
            body: Body of the request

        Returns:
            PostTokensResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/tokens",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostTokensResponse,
            responseContentType="application/json",
        )

    def deleteTokenId(
        self,
        tokenId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/tokens/{tokenId}'.

        Delete API token.

        Deletes an api token by its ID.

        Args:
            tokenId: ID of the token

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="delete",
            path=f"/backend/v1/tokens/{tokenId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
