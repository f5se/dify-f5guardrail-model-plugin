from datetime import datetime
from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class ScansAsyncClient(_BaseClient):
    """Async client for all requests under '/scans'."""

    async def get(
        self,
        *,
        cursor: str | None = None,
        search: str | None = None,
        limit: int = 10,
        ascending: bool = False,
        before: datetime | str | None = None,
        after: datetime | str | None = None,
        externalMetadata: str | None = None,
        onlyUser: bool = True,
        outcomes: list[dt.PromptOutcome | str] | None = None,
        endpointId: UUID | str | list[UUID | str] | None = None,
        projectId: UUID | str | list[UUID | str] | None = None,
        providerId: UUID | str | list[UUID | str] | None = None,
    ) -> dt.GetScansResponse:
        """Send GET request to '/backend/v1/scans'.

        Get scans.

        Retrieves a list of scan requests that match the given criteria,
        with the option to adjust the limit for more results.

        Args:
            cursor: Pass cursor from response to get next or prev page.
            search: Only return results that match the given text.
            limit: Limits the amount of results.
            ascending: Whether results should be sorted in ascending order.
            before: Only return results from before this timestamp.
            after: Only return results from after this timestamp.
            externalMetadata: Only return results that match the given external metadata (as a stringified
                              json e.g. '{"key": "value"}' would return only
                              prompts with a "key" entry matching "value")
            onlyUser: Only returns prompts belonging to the authenticated user.
            outcomes: Repeated query parameters of outcomes. Filters results by these outcomes.
            endpointId: Only returns prompts sent to specified endpoints.
            projectId: Only returns prompts sent to specified projects.
            providerId: Only returns prompts sent to specified providers.

        Returns:
            GetScansResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        if providerId is None:
            providerId = []
        if projectId is None:
            projectId = []
        if endpointId is None:
            endpointId = []
        if outcomes is None:
            outcomes = []
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/scans",
            queryParams={
                "cursor": cursor,
                "search": search,
                "limit": limit,
                "ascending": ascending,
                "before": before,
                "after": after,
                "externalMetadata": externalMetadata,
                "onlyUser": onlyUser,
                "outcomes": outcomes,
                "endpointId": endpointId,
                "projectId": projectId,
                "providerId": providerId,
            },
            responseModel=dt.GetScansResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dt.PostScansBody | dict,
    ) -> dt.PostScansResponse:
        """Send POST request to '/backend/v1/scans'.

        Scan data.

        Runs guardrails against the provided data,
        with the option to enable/disable specific guardrails and use the given project configuration.

        Args:
            body: Body of the request

        Returns:
            PostScansResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/scans",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostScansResponse,
            responseContentType="application/json",
        )

    async def getScanRequestId(
        self,
        scanRequestId: UUID | str,
    ) -> dt.GetScanResponse:
        """Send GET request to '/backend/v1/scans/{scanRequestId}'.

        Get scan.

        Retrieves a scan request by its ID.

        Args:
            scanRequestId: ID of the scan request

        Returns:
            GetScanResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/scans/{scanRequestId}",
            queryParams={},
            responseModel=dt.GetScanResponse,
            responseContentType="application/json",
        )

    async def patchScanRequestId(
        self,
        scanRequestId: UUID | str,
        body: dt.PatchScanBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/scans/{scanRequestId}'.

        Update scan preservation.

        Updates a scan request by ID, marking it as preserved.

        Args:
            scanRequestId: ID of the scan request
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/scans/{scanRequestId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
