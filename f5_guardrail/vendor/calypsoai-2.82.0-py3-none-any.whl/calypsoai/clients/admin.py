from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class AdminExportClient(_BaseClient):
    """Client for all requests under '/admin/export'."""

    def post(
        self,
    ) -> dt.PostAdminSettingsExportBody:
        """Send POST request to '/backend/v1/admin/export'.

        Create org settings backup.

        Exports all configuration data for the organization to be used for backup or migration purposes.

        Returns:
            PostAdminSettingsExportBody object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/admin/export",
            queryParams={},
            responseModel=dt.PostAdminSettingsExportBody,
            responseContentType="application/json",
        )


class AdminImportClient(_BaseClient):
    """Client for all requests under '/admin/import'."""

    def post(
        self,
        body: dt.PostAdmingSettingsImportBody | dict,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/admin/import'.

        Import org settings.

        Restores organization configuration from a previously created backup.

        Args:
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/admin/import",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class AdminClient(_BaseClient):
    """Client for all requests under '/admin'."""

    export: AdminExportClient
    "Client for all requests under '/admin/export'."
    import_: AdminImportClient
    "Client for all requests under '/admin/import'."
