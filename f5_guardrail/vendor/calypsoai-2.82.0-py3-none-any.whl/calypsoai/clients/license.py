from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class LicenseClient(_BaseClient):
    """Client for all requests under '/license'."""

    def patch(
        self,
        body: dt.PatchLicenseBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/license'.

        Update license.

        Update the license for the system.

        Args:
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="patch",
            path="/backend/v1/license",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
