from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class AdminExportAsyncClient(_BaseClient):
    """Async client for all requests under '/admin/export'."""

    async def post(
        self,
    ) -> dt.PostAdminSettingsExportBody:
        """Send POST request to '/backend/v1/admin/export'.

        Create org settings backup.

        Exports all configuration data for the organization to be used for backup or migration purposes.

        Returns:
            PostAdminSettingsExportBody object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/admin/export",
            queryParams={},
            responseModel=dt.PostAdminSettingsExportBody,
            responseContentType="application/json",
        )


class AdminImportAsyncClient(_BaseClient):
    """Async client for all requests under '/admin/import'."""

    async def post(
        self,
        body: dt.PostAdmingSettingsImportBody | dict,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/admin/import'.

        Import org settings.

        Restores organization configuration from a previously created backup.

        Args:
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/admin/import",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class AdminAsyncClient(_BaseClient):
    """Async client for all requests under '/admin'."""

    export: AdminExportAsyncClient
    "Async client for all requests under '/admin/export'."
    import_: AdminImportAsyncClient
    "Async client for all requests under '/admin/import'."
