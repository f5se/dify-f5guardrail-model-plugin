from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class GroupsUsersAsyncClient(_BaseClient):
    """Async client for all requests under '/groups/{groupId}/users'."""

    async def post(
        self,
        groupId: UUID | str,
        body: dt.PostGroupUsersBody | dict,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/groups/{groupId}/users'.

        Add users to a group.

        Only a group admin can add users to a group.

        Args:
            groupId: ID of the group
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path=f"/backend/v1/groups/{groupId}/users",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def deleteUserId(
        self,
        groupId: UUID | str,
        userId: str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/groups/{groupId}/users/{userId}'.

        Remove a user from a group. Only a group admin can remove a user from a group.

        Remove a user from a group. Only a group admin can remove a user from a group.

        Args:
            groupId: ID of the group
            userId: ID of the user

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/groups/{groupId}/users/{userId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def patchUserId(
        self,
        groupId: UUID | str,
        userId: str,
        body: dt.PatchGroupUserBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/groups/{groupId}/users/{userId}'.

        Update a user's admin status in a group.

        Only group admins can change a users admin status.

        Args:
            groupId: ID of the group
            userId: ID of the user
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/groups/{groupId}/users/{userId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class GroupsAsyncClient(_BaseClient):
    """Async client for all requests under '/groups'."""

    users: GroupsUsersAsyncClient
    "Async client for all requests under '/groups/{groupId}/users'."

    async def get(
        self,
        *,
        search: str | None = None,
        cursor: str | None = None,
        limit: int = 10,
        admin: bool | None = None,
    ) -> dt.GetGroupsResponse:
        """Send GET request to '/backend/v1/groups'.

        Get groups matching the given filter criteria.

        Get groups matching the given filter criteria.

        Args:
            search: Group's name for filtering results.
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            limit: Number of results to return.
            admin: If true and user is a super admin, filters results to only groups the user is admin of

        Returns:
            GetGroupsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/groups",
            queryParams={
                "search": search,
                "cursor": cursor,
                "limit": limit,
                "admin": admin,
            },
            responseModel=dt.GetGroupsResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dt.PostGroupBody | dict,
    ) -> dt.PostGroupResponse:
        """Send POST request to '/backend/v1/groups'.

        Create group.

        Create group.

        Args:
            body: Body of the request

        Returns:
            PostGroupResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/groups",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostGroupResponse,
            responseContentType="application/json",
        )

    async def deleteGroupId(
        self,
        groupId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/groups/{groupId}'.

        Delete group.

        Delete group.

        Args:
            groupId: ID of the group

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/groups/{groupId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def getGroupId(
        self,
        groupId: UUID | str,
    ) -> dt.GetGroupResponse:
        """Send GET request to '/backend/v1/groups/{groupId}'.

        Get group by its ID.

        Get group by its ID.

        Args:
            groupId: ID of the group

        Returns:
            GetGroupResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/groups/{groupId}",
            queryParams={},
            responseModel=dt.GetGroupResponse,
            responseContentType="application/json",
        )

    async def patchGroupId(
        self,
        groupId: UUID | str,
        body: dt.PatchGroupBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/groups/{groupId}'.

        Update group's name.

        User must be an admin of the group.

        Args:
            groupId: ID of the group
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/groups/{groupId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
