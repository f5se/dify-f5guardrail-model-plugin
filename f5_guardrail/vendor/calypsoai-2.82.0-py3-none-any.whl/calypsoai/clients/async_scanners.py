from datetime import datetime
from uuid import UUID
from zipfile import ZipFile

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class ScannersExportAsyncClient(_BaseClient):
    """Async client for all requests under '/scanners/export'."""

    async def post(
        self,
        body: dict | dt.ExportScannersBody | None = None,
    ) -> ZipFile:
        """Send POST request to '/backend/v1/scanners/export'.

        Export the given guardrails and guardrail packages in a zip file.

        Export the given guardrails and guardrail packages in a zip file.

        Args:
            body: Body of the request

        Returns:
            Zip file object containing the contents of the response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/scanners/export",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=None,
            responseContentType="application/zip",
        )


class ScannersImportAsyncClient(_BaseClient):
    """Async client for all requests under '/scanners/import'."""

    async def post(
        self,
        body: dt.BodyPostScannersImport | dict,
    ) -> dt.ZipImportResult:
        """Send POST request to '/backend/v1/scanners/import'.

        Import guardrails.

        Import guardrails and guardrail packages from a zip file.

        Args:
            body: Body of the request

        Returns:
            ZipImportResult object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/scanners/import",
            queryParams={},
            body=body,
            contentType="multipart/form-data",
            responseModel=dt.ZipImportResult,
            responseContentType="application/json",
        )


class ScannersAccessAsyncClient(_BaseClient):
    """Async client for all requests under '/scanners/{scannerId}/access'."""

    async def patch(
        self,
        scannerId: UUID | str,
        body: dt.PatchScannerAccessBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/scanners/{scannerId}/access'.

        Update guardrail availability.

        Updates a guardrail's availability across projects.

        Args:
            scannerId: ID of the scanner
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/scanners/{scannerId}/access",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class ScannersVersionsAsyncClient(_BaseClient):
    """Async client for all requests under '/scanners/{scannerId}/versions'."""

    async def get(
        self,
        scannerId: UUID | str,
        *,
        onlyPublished: bool = False,
    ) -> dt.GetScannerVersionsResponse:
        """Send GET request to '/backend/v1/scanners/{scannerId}/versions'.

        Get metadata for all existing versions of a guardrail.

        Get metadata for all existing versions of a guardrail.

        Args:
            scannerId: ID of the scanner
            onlyPublished: Only return published versions.

        Returns:
            GetScannerVersionsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/scanners/{scannerId}/versions",
            queryParams={
                "onlyPublished": onlyPublished,
            },
            responseModel=dt.GetScannerVersionsResponse,
            responseContentType="application/json",
        )

    async def patchVersionId(
        self,
        scannerId: UUID | str,
        versionId: UUID | str,
        body: dt.PatchScannerVersionBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/scanners/{scannerId}/versions/{versionId}'.

        Update a guardrail version.

        Update a guardrail version.

        Args:
            scannerId: ID of the scanner
            versionId: ID of the version
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/scanners/{scannerId}/versions/{versionId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class ScannersAsyncClient(_BaseClient):
    """Async client for all requests under '/scanners'."""

    export: ScannersExportAsyncClient
    "Async client for all requests under '/scanners/export'."
    import_: ScannersImportAsyncClient
    "Async client for all requests under '/scanners/import'."
    access: ScannersAccessAsyncClient
    "Async client for all requests under '/scanners/{scannerId}/access'."
    versions: ScannersVersionsAsyncClient
    "Async client for all requests under '/scanners/{scannerId}/versions'."

    async def get(
        self,
        *,
        includePackages: bool = False,
        cursor: str | None = None,
        search: str | None = None,
        limit: int = 10,
        ascending: bool = False,
        published: bool | None = None,
        direction: dt.ScannerDirection | str | None = None,
        source: list[dt.ScannerSourceType | str] | None = None,
        type_: list[dt.ScanType | str] | None = None,
        packaged: bool | None = None,
        sortBy: dt.ScannerSearchSortBy | str = "created_at",
        active: bool | None = None,
        groupId: UUID | str | None = None,
        endpoint: UUID | str | None = None,
        enabledForProject: UUID | str | None = None,
        tags: list[str] | None = None,
        addedToProjectId: UUID | str | None = None,
        accessibleToProjectId: UUID | str | None = None,
        packageId: UUID | str | list[UUID | str] | None = None,
        mode: list[dt.ScanMode | str] | None = None,
    ) -> dt.GetScannersResponse:
        """Send GET request to '/backend/v1/scanners'.

        Get guardrails.

        Retrieves a list of guardrails that match the given criteria,
        with the option to adjust the limit for more results.

        Args:
            includePackages: Include the packages for guardrails in the response.
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            search: Only return results that match the given text.
            limit: Limits the amount of results.
            ascending: Whether results should be sorted in ascending order.
            published: Get guardrails that match the given published state.
            direction: Get results that scan in the given direction.
            source: Get results that were created from the given source.
            type_: Get results that are of the given scan type.
            packaged: Get results that are packaged or not.
            sortBy: Sort results by the given parameter.
            active: Get results that are active/inactive. Only has an effect if addedToProjectId or
                    availableToProjectId is provided.
            groupId: Get results created for the given group.
            endpoint: Get results match the chosen active state for the given endpoint.
            enabledForProject: Get results match the chosen active state for the given project.
            tags: Get results with the given tags.
            addedToProjectId: Get guardrails added to project.
            accessibleToProjectId: Get guardrails accessible to project.
            packageId: Get guardrails that belong to the specified packages.
            mode: Get guardrails that are set to given mode(s) for the chosen project.

        Returns:
            GetScannersResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        if packageId is None:
            packageId = []
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/scanners",
            queryParams={
                "includePackages": includePackages,
                "cursor": cursor,
                "search": search,
                "limit": limit,
                "ascending": ascending,
                "published": published,
                "direction": direction,
                "source": source,
                "type": type_,
                "packaged": packaged,
                "sortBy": sortBy,
                "active": active,
                "groupId": groupId,
                "endpoint": endpoint,
                "enabledForProject": enabledForProject,
                "tags": tags,
                "addedToProjectId": addedToProjectId,
                "accessibleToProjectId": accessibleToProjectId,
                "packageId": packageId,
                "mode": mode,
            },
            responseModel=dt.GetScannersResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dict | dt.DuplicateScannerRequest | dt.PostScannersBody,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/scanners'.

        Create guardrail.

        Creates a new guardrail with the specified configuration.

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/scanners",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    async def deleteScannerId(
        self,
        scannerId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/scanners/{scannerId}'.

        Delete guardrail.

        Deletes a guardrail by ID.

        Args:
            scannerId: ID of the scanner

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/scanners/{scannerId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def getScannerId(
        self,
        scannerId: UUID | str,
        *,
        configAt: datetime | str | None = None,
        version: UUID | datetime | str | None = None,
    ) -> dt.GetScannerResponse:
        """Send GET request to '/backend/v1/scanners/{scannerId}'.

        Get guardrail.

        Retrieves a guardrail by ID.

        Args:
            scannerId: ID of the scanner
            configAt: Get the config at a given point in time.
            version: Get the guardrail at a specific version

        Returns:
            GetScannerResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/scanners/{scannerId}",
            queryParams={
                "configAt": configAt,
                "version": version,
            },
            responseModel=dt.GetScannerResponse,
            responseContentType="application/json",
        )

    async def patchScannerId(
        self,
        scannerId: UUID | str,
        body: dict | dt.PatchScannerBody | dt.UpdateScannerFromSourceBody,
    ) -> dt.PatchScannerResponse:
        """Send PATCH request to '/backend/v1/scanners/{scannerId}'.

        Update guardrail.

        Updates a guardrail's configuration, name, files, tags and direction.

        Args:
            scannerId: ID of the scanner
            body: Body of the request

        Returns:
            PatchScannerResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/scanners/{scannerId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PatchScannerResponse,
            responseContentType="application/json",
        )
