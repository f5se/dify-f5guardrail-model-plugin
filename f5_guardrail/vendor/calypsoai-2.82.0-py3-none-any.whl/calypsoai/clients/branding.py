from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class BrandingFaviconClient(_BaseClient):
    """Client for all requests under '/branding/favicon'."""

    def delete(
        self,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/branding/favicon'.

        Reset favicon.

        Reset the favicon to the first in the history, normally the CalypsoAI branding.

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="delete",
            path="/backend/v1/branding/favicon",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    def get(
        self,
    ) -> bytes:
        """Send GET request to '/backend/v1/branding/favicon'.

        Get favicon.

        Return the favicon as raw bytes.

        Returns:
            Raw binary content of the response body.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/branding/favicon",
            queryParams={},
            responseModel=None,
            responseContentType="image/png",
        )

    def post(
        self,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/branding/favicon'.

        Upload favicon.

        Upload a new favicon.

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/branding/favicon",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class BrandingLogoClient(_BaseClient):
    """Client for all requests under '/branding/logo'."""

    def delete(
        self,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/branding/logo'.

        Reset logo.

        Reset the logo to the first in the history, normally the CalypsoAI branding.

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="delete",
            path="/backend/v1/branding/logo",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    def get(
        self,
    ) -> bytes:
        """Send GET request to '/backend/v1/branding/logo'.

        Get logo.

        Return the logo image as raw bytes.

        Returns:
            Raw binary content of the response body.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/branding/logo",
            queryParams={},
            responseModel=None,
            responseContentType="image/svg+xml",
        )

    def post(
        self,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/branding/logo'.

        Upload logo.

        Upload a new logo image.

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/branding/logo",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class BrandingClient(_BaseClient):
    """Client for all requests under '/branding'."""

    favicon: BrandingFaviconClient
    "Client for all requests under '/branding/favicon'."
    logo: BrandingLogoClient
    "Client for all requests under '/branding/logo'."

    def get(
        self,
    ) -> dt.GetBrandingResponse:
        """Send GET request to '/backend/v1/branding'.

        Get branding.

        Return the branding config.

        Returns:
            GetBrandingResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/branding",
            queryParams={},
            responseModel=dt.GetBrandingResponse,
            responseContentType="application/json",
        )

    def patch(
        self,
        body: dt.PatchBrandingBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/branding'.

        Update branding.

        Edit the branding config.

        Args:
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="patch",
            path="/backend/v1/branding",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
