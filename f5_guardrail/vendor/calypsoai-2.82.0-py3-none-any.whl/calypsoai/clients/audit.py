from datetime import datetime

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class AuditClient(_BaseClient):
    """Client for all requests under '/audit'."""

    def get(
        self,
        *,
        cursor: str | None = None,
        search: str | None = None,
        limit: int = 10,
        ascending: bool = False,
        before: datetime | str | None = None,
        after: datetime | str | None = None,
        type_: dt.AuditEventType | str | list[dt.AuditEventType | str] = None,
        userId: list[str] | None = None,
    ) -> dt.GetAuditResponse:
        """Send GET request to '/backend/v1/audit'.

        Get audit events.

        Retrieves a paginated list of events that detail the configuration history of the app.

        Args:
            cursor:                  Selects page for paginated results. Pass in the next or prev attribute
                    in the response.
            search: Only return results that match the given text.
            limit: Limits the amount of results.
            ascending: Whether results should be sorted in ascending order.
            before: Only return results from before this timestamp.
            after: Only return results from after this timestamp.
            type_: Only return specific types of audit events.
            userId: Only return audit events created by specified user.

        Returns:
            GetAuditResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        if type_ is None:
            type_ = []
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/audit",
            queryParams={
                "cursor": cursor,
                "search": search,
                "limit": limit,
                "ascending": ascending,
                "before": before,
                "after": after,
                "type": type_,
                "userId": userId,
            },
            responseModel=dt.GetAuditResponse,
            responseContentType="application/json",
        )
