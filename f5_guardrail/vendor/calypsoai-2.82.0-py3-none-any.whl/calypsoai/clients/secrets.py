from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class SecretsClient(_BaseClient):
    """Client for all requests under '/secrets'."""

    def get(
        self,
    ) -> dt.GetSecretsResponse:
        """Send GET request to '/backend/v1/secrets'.

        Get secrets.

        Retrieves all available secrets, with their values obfuscated.

        Returns:
            GetSecretsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/secrets",
            queryParams={},
            responseModel=dt.GetSecretsResponse,
            responseContentType="application/json",
        )

    def post(
        self,
        body: dt.PostSecretsBody | dict,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/secrets'.

        Create secret.

        Creates a secret. The value will not be accessible through the API after creation.

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/secrets",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    def deleteSecretId(
        self,
        secretId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/secrets/{secretId}'.

        Delete secret.

        Deletes a secret by its ID.

        Args:
            secretId: ID of the secret

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="delete",
            path=f"/backend/v1/secrets/{secretId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    def getSecretId(
        self,
        secretId: UUID | str,
    ) -> dt.GetSecretResponse:
        """Send GET request to '/backend/v1/secrets/{secretId}'.

        Get secret.

        Retrieves a secret by its ID.

        Args:
            secretId: ID of the secret

        Returns:
            GetSecretResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path=f"/backend/v1/secrets/{secretId}",
            queryParams={},
            responseModel=dt.GetSecretResponse,
            responseContentType="application/json",
        )

    def patchSecretId(
        self,
        secretId: UUID | str,
        body: dt.PatchSecretBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/secrets/{secretId}'.

        Update secret.

        Updates a secret by its ID, including the name and value.

        Args:
            secretId: ID of the secret
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="patch",
            path=f"/backend/v1/secrets/{secretId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
