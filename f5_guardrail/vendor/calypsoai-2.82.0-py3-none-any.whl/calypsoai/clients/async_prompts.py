from datetime import datetime
from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class PromptsTemplatesAsyncClient(_BaseClient):
    """Async client for all requests under '/prompts/templates'."""

    async def get(
        self,
        *,
        before: UUID | datetime | str | None = None,
        after: UUID | datetime | str | None = None,
        limit: int = 10,
        endpointId: UUID | str | None = None,
        project: UUID | str | None = None,
    ) -> dt.GetPromptTemplatesResponse:
        """Send GET request to '/backend/v1/prompts/templates'.

        Get prompt templates.

        Retrieves a list of prompt templates that match the given criteria,
        with the option to adjust the limit for more results.

        Args:
            before: ID of an api token, only return results created before that token. Or if datetime
                    instead of ID, will only return results before that datetime
            after: ID of an api token, only return results created after that token. Or if datetime instead
                   of ID, will only return results after that datetime
            limit: Limits the amount of returned objects. Max 100, min 1
            endpointId: Deprecated
            project: Filter by project ID or friendly ID.

        Returns:
            GetPromptTemplatesResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/prompts/templates",
            queryParams={
                "before": before,
                "after": after,
                "limit": limit,
                "endpointId": endpointId,
                "project": project,
            },
            responseModel=dt.GetPromptTemplatesResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dt.PostPromptTemplatesBody | dict,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/prompts/templates'.

        Create prompt template.

        Create a new prompt template.

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/prompts/templates",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    async def deletePromptTemplateId(
        self,
        promptTemplateId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/prompts/templates/{promptTemplateId}'.

        Delete a prompt template.

        Delete a prompt template.

        Args:
            promptTemplateId: ID of the prompt template

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/prompts/templates/{promptTemplateId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def getPromptTemplateId(
        self,
        promptTemplateId: UUID | str,
    ) -> dt.GetPromptTemplateResponse:
        """Send GET request to '/backend/v1/prompts/templates/{promptTemplateId}'.

        Get prompt template.

        Retrieves a prompt template by its ID.

        Args:
            promptTemplateId: ID of the prompt template

        Returns:
            GetPromptTemplateResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/prompts/templates/{promptTemplateId}",
            queryParams={},
            responseModel=dt.GetPromptTemplateResponse,
            responseContentType="application/json",
        )

    async def patchPromptTemplateId(
        self,
        promptTemplateId: UUID | str,
        body: dt.PatchPromptTemplateBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/prompts/templates/{promptTemplateId}'.

        Update prompt template.

        Modifies a prompt template, allowing you to update the name.

        Args:
            promptTemplateId: ID of the prompt template
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/prompts/templates/{promptTemplateId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class PromptsAsyncClient(_BaseClient):
    """Async client for all requests under '/prompts'."""

    templates: PromptsTemplatesAsyncClient
    "Async client for all requests under '/prompts/templates'."

    async def get(
        self,
        *,
        cursor: str | None = None,
        search: str | None = None,
        limit: int = 10,
        ascending: bool = False,
        before: datetime | str | None = None,
        after: datetime | str | None = None,
        externalMetadata: str | None = None,
        onlyUser: bool = True,
        outcomes: list[dt.PromptOutcome | str] | None = None,
        endpointId: UUID | str | list[UUID | str] | None = None,
        projectId: UUID | str | list[UUID | str] | None = None,
        providerId: UUID | str | list[UUID | str] | None = None,
        type_: dt.PromptType | str | list[dt.PromptType | str] = None,
        userId: str | list[str] | None = None,
    ) -> dt.GetPromptsResponse:
        """Send GET request to '/backend/v1/prompts'.

        Get prompts.

        Retrieves a list of prompts that match the given criteria, with the option to adjust the limit for more results.

        Args:
            cursor: Pass cursor from response to get next or prev page.
            search: Only return results that match the given text.
            limit: Limits the amount of results.
            ascending: Whether results should be sorted in ascending order.
            before: Only return results from before this timestamp.
            after: Only return results from after this timestamp.
            externalMetadata: Only return results that match the given external metadata (as a stringified
                              json e.g. '{"key": "value"}' would return only
                              prompts with a "key" entry matching "value")
            onlyUser: Only returns prompts belonging to the authenticated user.
            outcomes: Repeated query parameters of outcomes. Filters results by these outcomes.
            endpointId: Only returns prompts sent to specified endpoints.
            projectId: Only returns prompts sent to specified projects.
            providerId: Only returns prompts sent to specified providers.
            type_: Only returns prompts that match the given types.
            userId: Only return prompts sent by the given user(s).

        Returns:
            GetPromptsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        if userId is None:
            userId = []
        if type_ is None:
            type_ = []
        if providerId is None:
            providerId = []
        if projectId is None:
            projectId = []
        if endpointId is None:
            endpointId = []
        if outcomes is None:
            outcomes = []
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/prompts",
            queryParams={
                "cursor": cursor,
                "search": search,
                "limit": limit,
                "ascending": ascending,
                "before": before,
                "after": after,
                "externalMetadata": externalMetadata,
                "onlyUser": onlyUser,
                "outcomes": outcomes,
                "endpointId": endpointId,
                "projectId": projectId,
                "providerId": providerId,
                "type": type_,
                "userId": userId,
            },
            responseModel=dt.GetPromptsResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dict | dt.PostPromptsBody | dt.PostPromptsBodyFromChat,
    ) -> dt.PostPromptsResponse:
        """Send POST request to '/backend/v1/prompts'.

        Send prompt.

        Send a prompt to a provider, after being scanned with the chosen project configuration.

        Args:
            body: Body of the request

        Returns:
            PostPromptsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/prompts",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostPromptsResponse,
            responseContentType="application/json",
        )

    async def getPromptId(
        self,
        promptId: UUID | str,
        *,
        fetchScanners: bool = False,
    ) -> dt.GetPromptResponse:
        """Send GET request to '/backend/v1/prompts/{promptId}'.

        Get prompt.

        Retrieves a prompt by its ID.

        Args:
            promptId: ID of the prompt
            fetchScanners: Return the guardrails and their configuration that were run on the prompt.

        Returns:
            GetPromptResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/prompts/{promptId}",
            queryParams={
                "fetchScanners": fetchScanners,
            },
            responseModel=dt.GetPromptResponse,
            responseContentType="application/json",
        )

    async def patchPromptId(
        self,
        promptId: UUID | str,
        body: dt.PatchPromptBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/prompts/{promptId}'.

        Update prompt.

        Modifies a prompt by its ID.
        This endpoint allows you to mark the prompt for preservation when deleting prompts periodically.

        Args:
            promptId: ID of the prompt
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/prompts/{promptId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
