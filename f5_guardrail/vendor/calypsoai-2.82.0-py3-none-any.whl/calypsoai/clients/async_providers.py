from datetime import datetime
from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class ProvidersSystemAsyncClient(_BaseClient):
    """Async client for all requests under '/providers/system'."""

    async def get(
        self,
    ) -> dt.GetSystemProvidersResponse:
        """Send GET request to '/backend/v1/providers/system'.

        Get available system providers.

        Get available system providers.

        Returns:
            GetSystemProvidersResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/providers/system",
            queryParams={},
            responseModel=dt.GetSystemProvidersResponse,
            responseContentType="application/json",
        )

    async def getSystemProvider(
        self,
        systemProvider: UUID | str,
    ) -> dt.GetSystemProviderResponse:
        """Send GET request to '/backend/v1/providers/system/{systemProvider}'.

        Get system provider.

        Retrieves a system provider by ID or name.

        Args:
            systemProvider: ID or name of the system provider

        Returns:
            GetSystemProviderResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/providers/system/{systemProvider}",
            queryParams={},
            responseModel=dt.GetSystemProviderResponse,
            responseContentType="application/json",
        )


class ProvidersTestAsyncClient(_BaseClient):
    """Async client for all requests under '/providers/test'."""

    async def post(
        self,
        body: dict | dt.PostProviderTestSystemBody | dt.PostProviderTestTemplateBody,
    ) -> dt.PostProviderTestResponse:
        """Send POST request to '/backend/v1/providers/test'.

        Test provider.

        Tests the connection to a provider using either a provider template or system provider,
        ensuring the connection is functional.

        Args:
            body: Body of the request

        Returns:
            PostProviderTestResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/providers/test",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostProviderTestResponse,
            responseContentType="application/json",
        )


class ProvidersAccessAsyncClient(_BaseClient):
    """Async client for all requests under '/providers/{provider}/access'."""

    async def patch(
        self,
        provider: UUID | str,
        body: dt.PatchProviderAccessBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/providers/{provider}/access'.

        Update provider availability.

        Updates the availability of a specified provider within a project.

        Args:
            provider: ID or name of the provider
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/providers/{provider}/access",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class ProvidersAsyncClient(_BaseClient):
    """Async client for all requests under '/providers'."""

    system: ProvidersSystemAsyncClient
    "Async client for all requests under '/providers/system'."
    test: ProvidersTestAsyncClient
    "Async client for all requests under '/providers/test'."
    access: ProvidersAccessAsyncClient
    "Async client for all requests under '/providers/{provider}/access'."

    async def get(
        self,
        *,
        limit: int = 10,
        addedToProjectId: UUID | str | None = None,
        accessibleToProjectId: UUID | str | None = None,
        enabledForProjectId: UUID | str | None = None,
        availableGlobally: bool | None = None,
        configAt: datetime | str | None = None,
        cursor: str | None = None,
        endpoint: UUID | str | None = None,
        groupId: UUID | str | None = None,
        redTeam: bool = False,
    ) -> dt.GetProvidersResponse:
        """Send GET request to '/backend/v1/providers'.

        Get providers.

        Retrieves a list of providers that match the given criteria,
        with the option to adjust the limit for more results.

        Args:
            limit: Limits the amount of results.
            addedToProjectId: Get providers added to the project
            accessibleToProjectId: Get providers accessible to the project
            enabledForProjectId: Get providers enabled for the project
            availableGlobally: Get providers that are or are not available to all projects.
            configAt: Get the config at a given point in time.
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            endpoint: ID or name of an endpoint to get active providers for.
            groupId: Deprecated
            redTeam: Get providers that are for red team use only.

        Returns:
            GetProvidersResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/providers",
            queryParams={
                "limit": limit,
                "addedToProjectId": addedToProjectId,
                "accessibleToProjectId": accessibleToProjectId,
                "enabledForProjectId": enabledForProjectId,
                "availableGlobally": availableGlobally,
                "configAt": configAt,
                "cursor": cursor,
                "endpoint": endpoint,
                "groupId": groupId,
                "redTeam": redTeam,
            },
            responseModel=dt.GetProvidersResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dict | dt.PostProvidersFromSystemBody | dt.PostProvidersWithTemplateBody,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/providers'.

        Create provider.

        Creates a new provider using a template or a system provider.

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/providers",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    async def deleteProvider(
        self,
        provider: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/providers/{provider}'.

        Delete provider.

        Must be admin of the provider's group or super admin if it is globally accessible.

        Args:
            provider: ID or name of the provider

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/providers/{provider}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def getProvider(
        self,
        provider: UUID | str,
        *,
        configAt: datetime | str | None = None,
    ) -> dt.GetProviderResponse:
        """Send GET request to '/backend/v1/providers/{provider}'.

        Get provider.

        Retrieves a provider by ID or name.

        Args:
            provider: ID or name of the provider
            configAt: Get the config at a given point in time.

        Returns:
            GetProviderResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/providers/{provider}",
            queryParams={
                "configAt": configAt,
            },
            responseModel=dt.GetProviderResponse,
            responseContentType="application/json",
        )

    async def patchProvider(
        self,
        provider: UUID | str,
        body: dt.PatchProviderBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/providers/{provider}'.

        Update provider.

        Requires group admin access for the provider or org admin access if it is globally accessible.
        You can update the provider's name, template, inputs, and secrets.

        Args:
            provider: ID or name of the provider
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/providers/{provider}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
