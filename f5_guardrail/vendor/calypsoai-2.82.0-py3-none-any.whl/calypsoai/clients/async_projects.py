from datetime import datetime
from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class ProjectsMembersAsyncClient(_BaseClient):
    """Async client for all requests under '/projects/{project}/members'."""

    async def post(
        self,
        project: UUID | str,
        body: dt.PostProjectMembersBody | dict,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/projects/{project}/members'.

        Add users to project.

        Only a project admin can add users to a project.

        Args:
            project: ID or name of the project
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path=f"/backend/v1/projects/{project}/members",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def deleteUserId(
        self,
        project: UUID | str,
        userId: str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/projects/{project}/members/{userId}'.

        Remove user from project.

        Removes a user from a project. Only a project admin can perform this action.

        Args:
            project: ID or name of the project
            userId: ID of the user

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/projects/{project}/members/{userId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def patchUserId(
        self,
        project: UUID | str,
        userId: str,
        body: dt.PatchProjectMemberBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/projects/{project}/members/{userId}'.

        Update project user.

        Updates a user's admin status within a project. Only project admins can modify a user's admin status.

        Args:
            project: ID or name of the project
            userId: ID of the user
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/projects/{project}/members/{userId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class ProjectsProvidersAsyncClient(_BaseClient):
    """Async client for all requests under '/projects/{project}/providers'."""

    async def deleteProviderId(
        self,
        project: UUID | str,
        providerId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/projects/{project}/providers/{providerId}'.

        Remove provider from project.

        Remove provider from project.

        Args:
            project: ID or name of the project
            providerId: ID of the provider

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/projects/{project}/providers/{providerId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def postProviderId(
        self,
        project: UUID | str,
        providerId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/projects/{project}/providers/{providerId}'.

        Add provider to project.

        Add provider to project.

        Args:
            project: ID or name of the project
            providerId: ID of the provider

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path=f"/backend/v1/projects/{project}/providers/{providerId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class ProjectsScannerPackagesAsyncClient(_BaseClient):
    """Async client for all requests under '/projects/{project}/scanner-packages'."""

    async def deleteScannerPackageId(
        self,
        project: UUID | str,
        scannerPackageId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/projects/{project}/scanner-packages/{scannerPackageId}'.

        Remove guardrail package from project.

        Remove guardrail package from project.

        Args:
            project: ID or name of the project
            scannerPackageId: ID of the scanner package

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/projects/{project}/scanner-packages/{scannerPackageId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def postScannerPackageId(
        self,
        project: UUID | str,
        scannerPackageId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/projects/{project}/scanner-packages/{scannerPackageId}'.

        Add scanner_package to project.

        Add scanner_package to project.

        Args:
            project: ID or name of the project
            scannerPackageId: ID of the scanner package

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path=f"/backend/v1/projects/{project}/scanner-packages/{scannerPackageId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class ProjectsScannersAsyncClient(_BaseClient):
    """Async client for all requests under '/projects/{project}/scanners'."""

    async def get(
        self,
        project: UUID | str,
        *,
        configAt: datetime | str | None = None,
    ) -> dt.GetProjectScannersResponse:
        """Send GET request to '/backend/v1/projects/{project}/scanners'.

        Get project guardrails.

        Retrieves all guardrails and their configurations
        used when sending prompts or performing scans within the project.

        Args:
            project: ID or name of the project
            configAt: Get the config at a given point in time.

        Returns:
            GetProjectScannersResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/projects/{project}/scanners",
            queryParams={
                "configAt": configAt,
            },
            responseModel=dt.GetProjectScannersResponse,
            responseContentType="application/json",
        )

    async def deleteScannerId(
        self,
        project: UUID | str,
        scannerId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/projects/{project}/scanners/{scannerId}'.

        Remove guardrail from project.

        Remove guardrail from project.

        Args:
            project: ID or name of the project
            scannerId: ID of the scanner

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/projects/{project}/scanners/{scannerId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def postScannerId(
        self,
        project: UUID | str,
        scannerId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send POST request to '/backend/v1/projects/{project}/scanners/{scannerId}'.

        Add guardrail to project.

        Add guardrail to project.

        Args:
            project: ID or name of the project
            scannerId: ID of the scanner

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path=f"/backend/v1/projects/{project}/scanners/{scannerId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class ProjectsAsyncClient(_BaseClient):
    """Async client for all requests under '/projects'."""

    members: ProjectsMembersAsyncClient
    "Async client for all requests under '/projects/{project}/members'."
    providers: ProjectsProvidersAsyncClient
    "Async client for all requests under '/projects/{project}/providers'."
    scannerPackages: ProjectsScannerPackagesAsyncClient
    "Async client for all requests under '/projects/{project}/scanner-packages'."
    scanners: ProjectsScannersAsyncClient
    "Async client for all requests under '/projects/{project}/scanners'."

    async def get(
        self,
        *,
        cursor: str | None = None,
        search: str | None = None,
        limit: int = 10,
        ascending: bool = False,
        type_: list[dt.ProjectType | str] | None = None,
        providerId: list[UUID | str] | None = None,
        sortBy: dt.ProjectSearchSortBy | str = "created_at",
        admin: bool | None = None,
        createdBy: str | None = None,
        deploymentStatus: dt.ProjectDeploymentStatus | str | None = None,
    ) -> dt.GetProjectsResponse:
        """Send GET request to '/backend/v1/projects'.

        Get projects.

        Retrieves a list of projects that match the given criteria,
        with the option to adjust the limit for more results.

        Args:
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            search: Only return results that match the given text.
            limit: Limits the amount of results.
            ascending: Whether results should be sorted in ascending order.
            type_: Filter projects by these types.
            providerId: Filter by projects that have these providers added.
            sortBy: Sort results by the given parameter.
            admin: Get projects that the current user is/isn't admin of.
            createdBy: Filter by projects created by the specified user.
            deploymentStatus: Filter projects by their deployment status.

        Returns:
            GetProjectsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/projects",
            queryParams={
                "cursor": cursor,
                "search": search,
                "limit": limit,
                "ascending": ascending,
                "type": type_,
                "providerId": providerId,
                "sortBy": sortBy,
                "admin": admin,
                "createdBy": createdBy,
                "deploymentStatus": deploymentStatus,
            },
            responseModel=dt.GetProjectsResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dt.PostProjectsBody | dict,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/projects'.

        Create project.

        Creates a new project

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/projects",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    async def deleteProject(
        self,
        project: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/projects/{project}'.

        Delete project.

        Deletes a project.
        Only an org admin can delete projects.

        Args:
            project: ID or name of the project

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/projects/{project}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def getProject(
        self,
        project: UUID | str,
        *,
        configAt: datetime | str | None = None,
    ) -> dt.GetProjectResponse:
        """Send GET request to '/backend/v1/projects/{project}'.

        Get project by ID or name.

        Retrieves a project by its ID or name.

        Args:
            project: ID or name of the project
            configAt: Get the config at a given point in time.

        Returns:
            GetProjectResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/projects/{project}",
            queryParams={
                "configAt": configAt,
            },
            responseModel=dt.GetProjectResponse,
            responseContentType="application/json",
        )

    async def patchProject(
        self,
        project: UUID | str,
        body: dt.PatchProjectBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/projects/{project}'.

        Update project.

        Modifies a project, including its name, friendly ID and configuration.

        Args:
            project: ID or name of the project
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/projects/{project}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
