from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class AppMetricsAsyncClient(_BaseClient):
    """Async client for all requests under '/app/metrics'."""

    async def get(
        self,
    ) -> dt.AppMetrics:
        """Send GET request to '/backend/v1/app/metrics'.

        Get app metrics.

        Returns the list of metrics such as the available bd connections,
        available threads, load stats and worker stats.

        Returns:
            AppMetrics object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/app/metrics",
            queryParams={},
            responseModel=dt.AppMetrics,
            responseContentType="application/json",
        )


class AppAsyncClient(_BaseClient):
    """Async client for all requests under '/app'."""

    metrics: AppMetricsAsyncClient
    "Async client for all requests under '/app/metrics'."
