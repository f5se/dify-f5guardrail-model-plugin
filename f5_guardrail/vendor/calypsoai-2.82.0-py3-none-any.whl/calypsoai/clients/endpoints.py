from datetime import datetime
from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class EndpointsScannersClient(_BaseClient):
    """Client for all requests under '/endpoints/{endpoint}/scanners'."""

    def get(
        self,
        endpoint: UUID | str,
        *,
        configAt: datetime | str | None = None,
    ) -> dt.GetEndpointScannersResponse:
        """Send GET request to '/backend/v1/endpoints/{endpoint}/scanners'.

        Get the guardrails and their configuration that will be used when sending prompts to a given endpoint.

        Get the guardrails and their configuration that will be used when sending prompts to a given endpoint.

        Args:
            endpoint: ID or name of the endpoint
            configAt: Get the config at a given point in time.

        Returns:
            GetEndpointScannersResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path=f"/backend/v1/endpoints/{endpoint}/scanners",
            queryParams={
                "configAt": configAt,
            },
            responseModel=dt.GetEndpointScannersResponse,
            responseContentType="application/json",
        )


class EndpointsClient(_BaseClient):
    """Client for all requests under '/endpoints'."""

    scanners: EndpointsScannersClient
    "Client for all requests under '/endpoints/{endpoint}/scanners'."

    def get(
        self,
        *,
        groupId: UUID | str | None = None,
        chatbotId: UUID | str | None = None,
    ) -> dt.GetEndpointsResponse:
        """Send GET request to '/backend/v1/endpoints'.

        Get endpoints matching the given filter criteria.

        Get endpoints matching the given filter criteria.

        Args:
            groupId: ID of group to get endpoints for.
            chatbotId: ID of chatbot to get endpoints for.

        Returns:
            GetEndpointsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/endpoints",
            queryParams={
                "groupId": groupId,
                "chatbotId": chatbotId,
            },
            responseModel=dt.GetEndpointsResponse,
            responseContentType="application/json",
        )

    def post(
        self,
        body: dt.PostEndpointsBody | dict,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/endpoints'.

        Create a new endpoint.

        Create a new endpoint.

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/endpoints",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    def getEndpoint(
        self,
        endpoint: UUID | str,
        *,
        configAt: datetime | str | None = None,
    ) -> dt.GetEndpointResponse:
        """Send GET request to '/backend/v1/endpoints/{endpoint}'.

        Get endpoint by its ID or name.

        Get endpoint by its ID or name.

        Args:
            endpoint: ID or name of the endpoint
            configAt: Get the config at a given point in time.

        Returns:
            GetEndpointResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path=f"/backend/v1/endpoints/{endpoint}",
            queryParams={
                "configAt": configAt,
            },
            responseModel=dt.GetEndpointResponse,
            responseContentType="application/json",
        )

    def patchEndpoint(
        self,
        endpoint: UUID | str,
        body: dt.PatchEndpointBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/endpoints/{endpoint}'.

        Update endpoint.

        Update endpoint.

        Args:
            endpoint: ID or name of the endpoint
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="patch",
            path=f"/backend/v1/endpoints/{endpoint}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
