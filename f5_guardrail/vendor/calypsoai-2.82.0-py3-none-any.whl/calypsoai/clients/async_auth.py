from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class AuthRolesPermissionsAsyncClient(_BaseClient):
    """Async client for all requests under '/auth/roles/{roleId}/permissions'."""

    async def delete(
        self,
        roleId: UUID | str,
        body: dt.PatchAuthRolePermissionsBody | dict,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/auth/roles/{roleId}/permissions'.

        Remove permissions.

        Revokes one or more existing permissions from the specified role.

        Args:
            roleId: ID of the role
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/auth/roles/{roleId}/permissions",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def patch(
        self,
        roleId: UUID | str,
        body: dt.PatchAuthRolePermissionsBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/auth/roles/{roleId}/permissions'.

        Add permissions.

        Add new permissions to a role.

        Args:
            roleId: ID of the role
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/auth/roles/{roleId}/permissions",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class AuthRolesAsyncClient(_BaseClient):
    """Async client for all requests under '/auth/roles'."""

    permissions: AuthRolesPermissionsAsyncClient
    "Async client for all requests under '/auth/roles/{roleId}/permissions'."

    async def get(
        self,
        *,
        projectId: UUID | str | None = None,
        limit: int = 10,
        cursor: str | None = None,
    ) -> dt.GetAuthRolesResponse:
        """Send GET request to '/backend/v1/auth/roles'.

        Get roles.

        Retrieves a list of available roles associated with a given resource,
        with the option to adjust the limit for more results.

        Args:
            projectId: Returns roles associated with the specified project. If not provided, organization
                       roles are returned
            limit: Max number of items to be returned.
            cursor: Pass cursor from response to get next or prev page.

        Returns:
            GetAuthRolesResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/auth/roles",
            queryParams={
                "projectId": projectId,
                "limit": limit,
                "cursor": cursor,
            },
            responseModel=dt.GetAuthRolesResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dt.PostAuthRolesBody | dict,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/auth/roles'.

        Create role.

        Create a new role associated with a given resource.

        Currently available resources to associate with a role are the organization and projects.

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/auth/roles",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    async def deleteRoleId(
        self,
        roleId: UUID | str,
        body: dict | dt.DeleteAuthRoleBody | None = None,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/auth/roles/{roleId}'.

        Delete role.

        Deletes a role. If the role has assigned users, they can be moved to a new role if one is provided.

        Args:
            roleId: ID of the role
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/auth/roles/{roleId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def getRoleId(
        self,
        roleId: UUID | str,
    ) -> dt.GetAuthRoleResponse:
        """Send GET request to '/backend/v1/auth/roles/{roleId}'.

        Get role.

        Request a role by its ID.

        Args:
            roleId: ID of the role

        Returns:
            GetAuthRoleResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/auth/roles/{roleId}",
            queryParams={},
            responseModel=dt.GetAuthRoleResponse,
            responseContentType="application/json",
        )

    async def patchRoleId(
        self,
        roleId: UUID | str,
        body: dt.PatchAuthRoleBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/auth/roles/{roleId}'.

        Update role.

        Modifies the role's name and/or permissions. If permissions are provided, they will replace the existing set.

        Args:
            roleId: ID of the role
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/auth/roles/{roleId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )


class AuthAsyncClient(_BaseClient):
    """Async client for all requests under '/auth'."""

    roles: AuthRolesAsyncClient
    "Async client for all requests under '/auth/roles'."
