from calypsoai.clients.admin import AdminClient
from calypsoai.clients.agentSessions import AgentSessionsClient
from calypsoai.clients.app import AppClient
from calypsoai.clients.async_admin import AdminAsyncClient
from calypsoai.clients.async_agentSessions import AgentSessionsAsyncClient
from calypsoai.clients.async_app import AppAsyncClient
from calypsoai.clients.async_audit import AuditAsyncClient
from calypsoai.clients.async_auth import AuthAsyncClient
from calypsoai.clients.async_branding import BrandingAsyncClient
from calypsoai.clients.async_campaignRuns import CampaignRunsAsyncClient
from calypsoai.clients.async_campaigns import CampaignsAsyncClient
from calypsoai.clients.async_campaignSchedules import CampaignSchedulesAsyncClient
from calypsoai.clients.async_chats import ChatsAsyncClient
from calypsoai.clients.async_datasets import DatasetsAsyncClient
from calypsoai.clients.async_endpoint import EndpointAsyncClient
from calypsoai.clients.async_endpoints import EndpointsAsyncClient
from calypsoai.clients.async_files import FilesAsyncClient
from calypsoai.clients.async_generations import GenerationsAsyncClient
from calypsoai.clients.async_groups import GroupsAsyncClient
from calypsoai.clients.async_license import LicenseAsyncClient
from calypsoai.clients.async_org import OrgAsyncClient
from calypsoai.clients.async_project import ProjectAsyncClient
from calypsoai.clients.async_projects import ProjectsAsyncClient
from calypsoai.clients.async_prompts import PromptsAsyncClient
from calypsoai.clients.async_providers import ProvidersAsyncClient
from calypsoai.clients.async_scannerPackages import ScannerPackagesAsyncClient
from calypsoai.clients.async_scanners import ScannersAsyncClient
from calypsoai.clients.async_scans import ScansAsyncClient
from calypsoai.clients.async_secrets import SecretsAsyncClient
from calypsoai.clients.async_tokens import TokensAsyncClient
from calypsoai.clients.async_users import UsersAsyncClient
from calypsoai.clients.audit import AuditClient
from calypsoai.clients.auth import AuthClient
from calypsoai.clients.base import BaseCalypsoAIAsyncClient, BaseCalypsoAIClient, RequestError
from calypsoai.clients.branding import BrandingClient
from calypsoai.clients.campaignRuns import CampaignRunsClient
from calypsoai.clients.campaigns import CampaignsClient
from calypsoai.clients.campaignSchedules import CampaignSchedulesClient
from calypsoai.clients.chats import ChatsClient
from calypsoai.clients.datasets import DatasetsClient
from calypsoai.clients.endpoint import EndpointClient
from calypsoai.clients.endpoints import EndpointsClient
from calypsoai.clients.files import FilesClient
from calypsoai.clients.generations import GenerationsClient
from calypsoai.clients.groups import GroupsClient
from calypsoai.clients.license import LicenseClient
from calypsoai.clients.org import OrgClient
from calypsoai.clients.project import ProjectClient
from calypsoai.clients.projects import ProjectsClient
from calypsoai.clients.prompts import PromptsClient
from calypsoai.clients.providers import ProvidersClient
from calypsoai.clients.scannerPackages import ScannerPackagesClient
from calypsoai.clients.scanners import ScannersClient
from calypsoai.clients.scans import ScansClient
from calypsoai.clients.secrets import SecretsClient
from calypsoai.clients.tokens import TokensClient
from calypsoai.clients.users import UsersClient


class CalypsoAIClient(BaseCalypsoAIClient):
    """Top level client for all CalypsoAI APIs."""

    admin: AdminClient
    "Client for all requests under '/admin'."
    agentSessions: AgentSessionsClient
    "Client for all requests under '/agent-sessions'."
    app: AppClient
    "Client for all requests under '/app'."
    audit: AuditClient
    "Client for all requests under '/audit'."
    auth: AuthClient
    "Client for all requests under '/auth'."
    branding: BrandingClient
    "Client for all requests under '/branding'."
    campaignRuns: CampaignRunsClient
    "Client for all requests under '/campaign-runs'."
    campaignSchedules: CampaignSchedulesClient
    "Client for all requests under '/campaign-schedules'."
    campaigns: CampaignsClient
    "Client for all requests under '/campaigns'."
    chats: ChatsClient
    "Client for all requests under '/chats'."
    datasets: DatasetsClient
    "Client for all requests under '/datasets'."
    endpoint: EndpointClient
    "Client for all requests under '/endpoint'."
    endpoints: EndpointsClient
    "Client for all requests under '/endpoints'."
    files: FilesClient
    "Client for all requests under '/files'."
    generations: GenerationsClient
    "Client for all requests under '/generations'."
    groups: GroupsClient
    "Client for all requests under '/groups'."
    license: LicenseClient
    "Client for all requests under '/license'."
    org: OrgClient
    "Client for all requests under '/org'."
    project: ProjectClient
    "Client for all requests under '/project'."
    projects: ProjectsClient
    "Client for all requests under '/projects'."
    prompts: PromptsClient
    "Client for all requests under '/prompts'."
    providers: ProvidersClient
    "Client for all requests under '/providers'."
    scannerPackages: ScannerPackagesClient
    "Client for all requests under '/scanner-packages'."
    scanners: ScannersClient
    "Client for all requests under '/scanners'."
    scans: ScansClient
    "Client for all requests under '/scans'."
    secrets: SecretsClient
    "Client for all requests under '/secrets'."
    tokens: TokensClient
    "Client for all requests under '/tokens'."
    users: UsersClient
    "Client for all requests under '/users'."


class CalypsoAIAsyncClient(BaseCalypsoAIAsyncClient):
    """Top level async client for all CalypsoAI APIs."""

    admin: AdminAsyncClient
    "Async client for all requests under '/admin'."
    agentSessions: AgentSessionsAsyncClient
    "Async client for all requests under '/agent-sessions'."
    app: AppAsyncClient
    "Async client for all requests under '/app'."
    audit: AuditAsyncClient
    "Async client for all requests under '/audit'."
    auth: AuthAsyncClient
    "Async client for all requests under '/auth'."
    branding: BrandingAsyncClient
    "Async client for all requests under '/branding'."
    campaignRuns: CampaignRunsAsyncClient
    "Async client for all requests under '/campaign-runs'."
    campaignSchedules: CampaignSchedulesAsyncClient
    "Async client for all requests under '/campaign-schedules'."
    campaigns: CampaignsAsyncClient
    "Async client for all requests under '/campaigns'."
    chats: ChatsAsyncClient
    "Async client for all requests under '/chats'."
    datasets: DatasetsAsyncClient
    "Async client for all requests under '/datasets'."
    endpoint: EndpointAsyncClient
    "Async client for all requests under '/endpoint'."
    endpoints: EndpointsAsyncClient
    "Async client for all requests under '/endpoints'."
    files: FilesAsyncClient
    "Async client for all requests under '/files'."
    generations: GenerationsAsyncClient
    "Async client for all requests under '/generations'."
    groups: GroupsAsyncClient
    "Async client for all requests under '/groups'."
    license: LicenseAsyncClient
    "Async client for all requests under '/license'."
    org: OrgAsyncClient
    "Async client for all requests under '/org'."
    project: ProjectAsyncClient
    "Async client for all requests under '/project'."
    projects: ProjectsAsyncClient
    "Async client for all requests under '/projects'."
    prompts: PromptsAsyncClient
    "Async client for all requests under '/prompts'."
    providers: ProvidersAsyncClient
    "Async client for all requests under '/providers'."
    scannerPackages: ScannerPackagesAsyncClient
    "Async client for all requests under '/scanner-packages'."
    scanners: ScannersAsyncClient
    "Async client for all requests under '/scanners'."
    scans: ScansAsyncClient
    "Async client for all requests under '/scans'."
    secrets: SecretsAsyncClient
    "Async client for all requests under '/secrets'."
    tokens: TokensAsyncClient
    "Async client for all requests under '/tokens'."
    users: UsersAsyncClient
    "Async client for all requests under '/users'."


__all__ = ["CalypsoAIAsyncClient", "CalypsoAIClient", "RequestError"]
