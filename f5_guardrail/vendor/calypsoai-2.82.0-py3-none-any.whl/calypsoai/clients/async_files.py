from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class FilesAsyncClient(_BaseClient):
    """Async client for all requests under '/files'."""

    async def post(
        self,
        body: dt.BodyPostFiles | dict,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/files'.

        Upload a file.

        Upload a file.

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/files",
            queryParams={},
            body=body,
            contentType="multipart/form-data",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    async def getFileId(
        self,
        fileId: UUID | str,
    ) -> dt.GetFileResponse:
        """Send GET request to '/backend/v1/files/{fileId}'.

        Get a file's metadata by the file ID.

        Get a file's metadata by the file ID.

        Args:
            fileId: ID of the file

        Returns:
            GetFileResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/files/{fileId}",
            queryParams={},
            responseModel=dt.GetFileResponse,
            responseContentType="application/json",
        )
