from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class CampaignSchedulesAsyncClient(_BaseClient):
    """Async client for all requests under '/campaign-schedules'."""

    async def get(
        self,
        *,
        limit: int = 10,
        cursor: str | None = None,
        campaignId: UUID | str | None = None,
    ) -> dt.GetCampaignSchedulesResponse:
        """Send GET request to '/backend/v1/campaign-schedules'.

        Get campaign schedules.

        Retrieves a list of campaign schedules that match the given criteria,
        with the option to adjust the limit for more results.

        Args:
            limit: Limits the amount of returned objects. Max 100, min 1
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            campaignId: If specified, will only return schedules that run the specified campaign

        Returns:
            GetCampaignSchedulesResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/campaign-schedules",
            queryParams={
                "limit": limit,
                "cursor": cursor,
                "campaignId": campaignId,
            },
            responseModel=dt.GetCampaignSchedulesResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dt.PostCampaignScheduleBody | dict,
    ) -> dt.PostCampaignScheduleResponse:
        """Send POST request to '/backend/v1/campaign-schedules'.

        Run campaigns on a schedule.

        Schedules a campaign run by its ID.
        You can specify the interval time, start time, end time, frequency, number of occurrences, providers and name.

        Args:
            body: Body of the request

        Returns:
            PostCampaignScheduleResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/campaign-schedules",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostCampaignScheduleResponse,
            responseContentType="application/json",
        )

    async def deleteCampaignScheduleId(
        self,
        campaignScheduleId: UUID | str,
        *,
        cancelRunningAttacks: bool | None = None,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/campaign-schedules/{campaignScheduleId}'.

        Delete a campaign run schedule.

        This will cancel any scheduled campaign runs created by the schedule

        Args:
            campaignScheduleId: ID of the campaign schedule
            cancelRunningAttacks: Also cancel campaign runs in the schedule that are in progress, defaults
                                  to False

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/campaign-schedules/{campaignScheduleId}",
            queryParams={
                "cancelRunningAttacks": cancelRunningAttacks,
            },
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def getCampaignScheduleId(
        self,
        campaignScheduleId: UUID | str,
    ) -> dt.CampaignSchedule:
        """Send GET request to '/backend/v1/campaign-schedules/{campaignScheduleId}'.

        Get scheduled campaign run.

        Retrieves a scheduled campaign run by its ID.

        Args:
            campaignScheduleId: ID of the campaign schedule

        Returns:
            CampaignSchedule object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/campaign-schedules/{campaignScheduleId}",
            queryParams={},
            responseModel=dt.CampaignSchedule,
            responseContentType="application/json",
        )

    async def patchCampaignScheduleId(
        self,
        campaignScheduleId: UUID | str,
        body: dt.UpdateScheduleParams | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/campaign-schedules/{campaignScheduleId}'.

        Update a scheduled campaign run.

        Updates a scheduled campaign run.
        You can modify the interval time, start time, end time, frequency, number of occurrences, and name.

        Args:
            campaignScheduleId: ID of the campaign schedule
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/campaign-schedules/{campaignScheduleId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
