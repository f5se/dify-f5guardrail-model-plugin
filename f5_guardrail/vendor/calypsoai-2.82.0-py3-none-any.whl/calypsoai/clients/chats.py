from datetime import datetime
from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class ChatsPublicClient(_BaseClient):
    """Client for all requests under '/chats/public'."""

    def getAccessId(
        self,
        accessId: UUID | str,
    ) -> dt.GetPublicChatResponse:
        """Send GET request to '/backend/v1/chats/public/{accessId}'.

        Get chat by access ID.

        Retrieves a chat using a public access ID, including its prompts and other relevant data.

        The chat must be publicly accessible.

        Args:
            accessId: ID of the access

        Returns:
            GetPublicChatResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path=f"/backend/v1/chats/public/{accessId}",
            queryParams={},
            responseModel=dt.GetPublicChatResponse,
            responseContentType="application/json",
        )


class ChatsClient(_BaseClient):
    """Client for all requests under '/chats'."""

    public: ChatsPublicClient
    "Client for all requests under '/chats/public'."

    def get(
        self,
        *,
        limit: int = 10,
        before: UUID | datetime | str | None = None,
        after: UUID | datetime | str | None = None,
        starred: bool | None = None,
    ) -> dt.GetChatsResponse:
        """Send GET request to '/backend/v1/chats'.

        Get chats.

        Retrieves a list of chats that match the given criteria, with the option to adjust the limit for more results.

        Chats contain details of user interactions with a LLM.

        Args:
            limit: Limits the amount of returned objects. Max 100, min 1
            before: If is an AwareDatetime, will only return results before that time. If is a UUID of an
                    api token, will instead only return results created before that
                    token
            after: If is an AwareDatetime, will only return results after that time. If is a UUID of an api
                   token, will instead only return results created after that token
            starred: If true return only chats that have been marked 'starred'

        Returns:
            GetChatsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path="/backend/v1/chats",
            queryParams={
                "limit": limit,
                "before": before,
                "after": after,
                "starred": starred,
            },
            responseModel=dt.GetChatsResponse,
            responseContentType="application/json",
        )

    def post(
        self,
        body: dict | dt.PostChatsFromPromptBody | dt.PostChatsFromTemplateBody,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/chats'.

        Create chat.

        Create a new chat with an LLM.

        Accepts two types of request bodies, allowing you to create chats from prompts or prompt templates.

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="post",
            path="/backend/v1/chats",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    def deleteChatId(
        self,
        chatId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/chats/{chatId}'.

        Delete chat.

        Deletes a chat. Only the chat's owner can delete it.

        Args:
            chatId: ID of the chat

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="delete",
            path=f"/backend/v1/chats/{chatId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    def getChatId(
        self,
        chatId: UUID | str,
    ) -> dt.GetChatResponse:
        """Send GET request to '/backend/v1/chats/{chatId}'.

        Get chat.

        Retrieves a chat by its ID, including its associated prompts.

        The user must have access to the chat.

        Access is automatically granted to the creator and can be manually assigned to others by the owner.

        Args:
            chatId: ID of the chat

        Returns:
            GetChatResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="get",
            path=f"/backend/v1/chats/{chatId}",
            queryParams={},
            responseModel=dt.GetChatResponse,
            responseContentType="application/json",
        )

    def patchChatId(
        self,
        chatId: UUID | str,
        body: dt.PatchChatBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/chats/{chatId}'.

        Update chat.

        Only the chat's owner can perform updates.
        You can modify the chat name, public access, organization access, user access, remove user access,
        and mark the chat as starred.

        Args:
            chatId: ID of the chat
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return self._requestProxy.request(
            method="patch",
            path=f"/backend/v1/chats/{chatId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
