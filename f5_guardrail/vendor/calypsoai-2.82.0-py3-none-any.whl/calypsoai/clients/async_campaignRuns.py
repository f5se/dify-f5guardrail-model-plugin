from datetime import datetime
from uuid import UUID

from calypsoai import datatypes as dt
from calypsoai.clients.base import _BaseClient


class CampaignRunsAsyncClient(_BaseClient):
    """Async client for all requests under '/campaign-runs'."""

    async def get(
        self,
        *,
        cursor: str | None = None,
        search: str | None = None,
        limit: int = 10,
        ascending: bool = False,
        before: datetime | str | None = None,
        after: datetime | str | None = None,
        name: str | None = None,
        campaignScheduleId: UUID | str | None = None,
        status: list[dt.CampaignRunStatus | str] | None = None,
        providerId: list[UUID | str] | None = None,
        createdBy: list[str] | None = None,
        scoreRange: list[dt.CampaignRunScoreRating | str] | None = None,
        includeProviders: bool = False,
        includeRemediations: bool = False,
        includeCampaigns: bool = False,
        includeSchedules: bool = False,
        includeUsers: bool = False,
        sortBy: dt.CampaignRunSearchSortBy | str = "created_at",
        preserve: bool | None = None,
        vendored: bool = False,
    ) -> dt.GetCampaignRunsResponse:
        """Send GET request to '/backend/v1/campaign-runs'.

        Get campaign runs.

        Retrieves a list of campaign runs that match the given criteria,
        with the option to adjust the limit for more results.

        Args:
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            search: Only return results that match the given text.
            limit: Limits the amount of results.
            ascending: Whether results should be sorted in ascending order.
            before: Only return results from before this timestamp.
            after: Only return results from after this timestamp.
            name: Filter by campaign runs with names that match this value.
            campaignScheduleId: Filter by campaign runs in this schedule.
            status: Filter by campaign runs with any of these statuses.
            providerId: Filter by provider that the campaign was run against.
            createdBy: Filter by users that created the campaign runs.
            scoreRange: Only return campaign runs with a score between range.
            includeProviders: Include providers that the campaign was run against.
            includeRemediations: Include remediations that were created from the campaign runs.
            includeCampaigns: Include campaigns.
            includeSchedules: Include campaign schedules.
            includeUsers: Include users.
            sortBy: Sort results by the given parameter.
            preserve: Filter by campaign runs that are preserved or not.
            vendored: Filter by campaign runs that are vendored or not.

        Returns:
            GetCampaignRunsResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path="/backend/v1/campaign-runs",
            queryParams={
                "cursor": cursor,
                "search": search,
                "limit": limit,
                "ascending": ascending,
                "before": before,
                "after": after,
                "name": name,
                "campaignScheduleId": campaignScheduleId,
                "status": status,
                "providerId": providerId,
                "createdBy": createdBy,
                "scoreRange": scoreRange,
                "includeProviders": includeProviders,
                "includeRemediations": includeRemediations,
                "includeCampaigns": includeCampaigns,
                "includeSchedules": includeSchedules,
                "includeUsers": includeUsers,
                "sortBy": sortBy,
                "preserve": preserve,
                "vendored": vendored,
            },
            responseModel=dt.GetCampaignRunsResponse,
            responseContentType="application/json",
        )

    async def post(
        self,
        body: dt.PostRunCampaignBody | dict,
    ) -> dt.PostSuccessMessage:
        """Send POST request to '/backend/v1/campaign-runs'.

        Run campaign.

        Runs the campaign using the specified providers. The provided name helps identify the campaign run.

        Args:
            body: Body of the request

        Returns:
            PostSuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="post",
            path="/backend/v1/campaign-runs",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.PostSuccessMessage,
            responseContentType="application/json",
        )

    async def deleteCampaignRunId(
        self,
        campaignRunId: UUID | str,
    ) -> dt.SuccessMessage:
        """Send DELETE request to '/backend/v1/campaign-runs/{campaignRunId}'.

        Delete a campaign run.

        Deletes a campaign run.

        Args:
            campaignRunId: ID of the campaign run

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="delete",
            path=f"/backend/v1/campaign-runs/{campaignRunId}",
            queryParams={},
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )

    async def getCampaignRunId(
        self,
        campaignRunId: UUID | str,
        *,
        includeResults: bool = False,
        includeProviders: bool = False,
        includeSchedule: bool = False,
        includeCampaign: bool = False,
    ) -> dt.GetCampaignRunResponse:
        """Send GET request to '/backend/v1/campaign-runs/{campaignRunId}'.

        Get campaign run.

        Returns a campaign run based on its ID. Optional parameters allow including results,
        providers, and schedule objects in the response.

        Args:
            campaignRunId: ID of the campaign run
            includeResults: Include attack results in response
            includeProviders: Include providers that the campaign was run against
            includeSchedule: Include the campaign run's schedule if it has one
            includeCampaign: Include the campaign run's campaign

        Returns:
            GetCampaignRunResponse object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="get",
            path=f"/backend/v1/campaign-runs/{campaignRunId}",
            queryParams={
                "includeResults": includeResults,
                "includeProviders": includeProviders,
                "includeSchedule": includeSchedule,
                "includeCampaign": includeCampaign,
            },
            responseModel=dt.GetCampaignRunResponse,
            responseContentType="application/json",
        )

    async def patchCampaignRunId(
        self,
        campaignRunId: UUID | str,
        body: dt.PatchCampaignRunBody | dict,
    ) -> dt.SuccessMessage:
        """Send PATCH request to '/backend/v1/campaign-runs/{campaignRunId}'.

        Update campaign run.

        Modifies the campaign run's status, name and start time.

        Args:
            campaignRunId: ID of the campaign run
            body: Body of the request

        Returns:
            SuccessMessage object parsed from JSON response.

        Raises:
            RequestError: If a non-2xx response code is returned for the request.
        """
        return await self._requestProxy.asyncRequest(
            method="patch",
            path=f"/backend/v1/campaign-runs/{campaignRunId}",
            queryParams={},
            body=body,
            contentType="application/json",
            responseModel=dt.SuccessMessage,
            responseContentType="application/json",
        )
