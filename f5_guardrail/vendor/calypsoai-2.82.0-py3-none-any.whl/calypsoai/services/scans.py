from collections.abc import Iterator

from pydantic import AwareDatetime

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId
from calypsoai.services.scanners import ScannerConfig


class ScansService(BaseService):
    """Service to interact with scan requests."""

    def scan(
        self,
        input_: str,
        *,
        project: ObjOrId[dt.Project] | None = None,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        override: dict[ObjOrId[dt.Scanner] | dt.ScanType, ScannerConfig | dict] | None = None,
        forceEnabled: list[ObjOrId[dt.Scanner] | dt.ScanType] | None = None,
        disabled: list[ObjOrId[dt.Scanner] | dt.ScanType] | None = None,
        flagOnly: bool = True,
    ) -> dt.ScanRequest:
        """Scan the given input, optionally overriding default configuration for the selected or default endpoint.

        Args:
            input_: Data to be scanned.
            project: Project to use configuration for. If not provided, the global default will be used.
            endpoint: (Deprecated) Endpoint to use configuration for. If not provided, the global default will be used.
            override: Config overrider for scanners, specified by type for system scanners or ID for custom scanners.
            forceEnabled: Force scanners to be enabled, specified by type for system scanners or ID for custom scanners.
            disabled: Disable scanners, specified by type for system scanners or ID for custom scanners.
            flagOnly: If true, the final outcome is 'flagged' if any scanner is triggered.
                      Otherwise, the outcome depends on the scanner's mode.

        Returns:
            The newly created scan request, containing all scanner results.
        """
        response = self.client.scans.post(
            dt.PostScansBody(
                input=input_,
                endpoint=self._util.getIdOrNone(endpoint),
                project=self._util.getIdOrNone(project),
                configOverrides={self._util.getId(key): value for key, value in (override or {}).items()},
                forceEnabled=[self._util.getId(val) for val in (forceEnabled or [])],
                disabled=[self._util.getId(val) for val in (disabled or [])],
                flagOnly=flagOnly,
            ),
        )
        scan = self.client.scans.getScanRequestId(response.id).scan
        messages = {scan.scannerId: scan.message for scan in response.result.scannerResults}
        for scanResult in scan.result.scannerResults:
            scanResult.message = messages.get(scanResult.scannerId)
        return scan

    def iterate(
        self,
        *,
        search: str | None = None,
        ascending: bool = False,
        before: AwareDatetime | str | None = None,
        after: AwareDatetime | str | None = None,
        onlyUser: bool = True,
        outcomes: list[dt.PromptOutcome | str] | None = None,
        batchSize: int = 100,
    ) -> Iterator[dt.ScanRequest]:
        """Iterate through all previous scan requests.

        Example:
            ```python
            cai = CalypsoAI()

            for scan_request in cai.scans.iterate():
                print("Input: " + scan_request.input)
                print("Outcome: " + scan_request.result.outcome)
            ```

        Args:
            batchSize: Size of batches to request.
            search: Only return results that match the given text.
            ascending: Whether results should be sorted in ascending order.
            before: Only return results from before this timestamp.
            after: Only return results from after this timestamp.
            onlyUser: Only returns prompts belonging to the authenticated user.
            outcomes: Repeated query parameters of outcomes. Filters results by these outcomes.

        Yields:
            All previously recorded scan requests.
        """
        cursor = None
        while True:
            response = self.client.scans.get(
                search=search,
                outcomes=outcomes,
                ascending=ascending,
                before=before,
                after=after,
                cursor=cursor,
                limit=batchSize,
                onlyUser=onlyUser,
            )
            yield from response.scans
            if not response.next:
                break
            cursor = response.next
