from collections.abc import Iterator, Sequence

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId


class RolesService(BaseService):
    """Service to interact with roles."""

    def get(self, role: ObjOrId[dt.Role]) -> dt.Role:
        """Get a role by ID.

        Args:
            role: The role to retrieve.

        Returns:
            The requested role.
        """
        return self.client.auth.roles.getRoleId(self._util.getId(role)).role

    def create(
        self,
        *,
        name: str,
        project: ObjOrId[dt.Project] | None = None,
        permissions: list[str],
    ) -> dt.Role:
        """Create a new custom role.

        Args:
            name: Name of the new role. Must be unique.
            project: A project to create the role for. If not supplied, an organization role is created.
            permissions: Permissions to assign to the role.

        Returns:
            The newly created role.
        """
        roleId = self.client.auth.roles.post(
            dt.PostAuthRolesBody(
                name=name,
                permissions=permissions,
                projectId=self._util.getIdOrNone(project),
            )
        ).id

        return self.get(roleId)

    def update(
        self,
        role: ObjOrId[dt.Role],
        *,
        name: str | None = None,
        permissions: Sequence[str] | None = None,
    ) -> None:
        """Update an existing role.

        Args:
            role: Role to update.
            name: New name for the role. Must be unique.
            permissions: New set of permissions to assign to the role.
        """
        self.client.auth.roles.patchRoleId(
            roleId=self._util.getId(role),
            body=dt.PatchAuthRoleBody(
                name=name,
                permissions=permissions,
            ),
        )

    def addPermissions(self, role: ObjOrId[dt.Role], permissions: Sequence[str]) -> None:
        """Add additional permissions to a role.

        Args:
            role: Role to add permissions to.
            permissions: New permissions to add to the role.
        """
        self.client.auth.roles.permissions.patch(
            roleId=self._util.getId(role),
            body=dt.PatchAuthRolePermissionsBody(
                permissions=permissions,
            ),
        )

    def removePermissions(self, role: ObjOrId[dt.Role], permissions: Sequence[str]) -> None:
        """Remove permissions from a role.

        Args:
            role: Role to remove permissions from.
            permissions: Permissions to remove from the role.
        """
        self.client.auth.roles.permissions.delete(
            roleId=self._util.getId(role),
            body=dt.PatchAuthRolePermissionsBody(
                permissions=permissions,
            ),
        )

    def iterate(self, *, project: ObjOrId[dt.Project] | None = None, batchSize: int = 10) -> Iterator[dt.Role]:
        """Iterate over all roles under an organization or project.

        Args:
            project: If supplied, roles for this project are returned. If not supplied, organization roles are returned.
            batchSize: Number of items returned by each underlying API call.

        Yields:
            All roles matching the given filters.
        """
        cursor = None
        while True:
            response = self.client.auth.roles.get(
                cursor=cursor,
                limit=batchSize,
                projectId=self._util.getIdOrNone(project),
            )
            yield from response.roles
            if not (cursor := response.next):
                break

    def delete(self, role: ObjOrId[dt.Role], *, reassignToRole: ObjOrId[dt.Role] | None = None) -> None:
        """Delete an existing role.

        Args:
            role: Role to delete.
            reassignToRole: If supplied, all users with the role to delete will be re-assigned to this role.
        """
        self.client.auth.roles.deleteRoleId(
            roleId=self._util.getId(role),
            body=dt.DeleteAuthRoleBody(
                reassignToRoleId=self._util.getIdOrNone(reassignToRole),
            ),
        )
