from typing import Any

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService


class OrganizationsService(BaseService):
    """Service to interact with organizations."""

    def getPreferences(self) -> list[dt.Setting]:
        """Gets the organization preferences.

        Returns:
            The requested preferences.
        """
        return self.client.org.preferences.get().preferences

    def updatePreferences(self, preferences: dict[str, Any]) -> None:
        """Update organization preferences.

        Example:
            ```python
            import os

            cai = CalypsoAI()

            cai.org.updatePreferences({"org.preferences.record_prompts": False})
            ```

        Args:
            preferences: The preferences to update.
                org.preferences.record_prompts: Whether or not prompts should be recorded.
        """
        self.client.org.preferences.patch(dt.PatchOrganizationPreferencesBody(preferences=preferences))
