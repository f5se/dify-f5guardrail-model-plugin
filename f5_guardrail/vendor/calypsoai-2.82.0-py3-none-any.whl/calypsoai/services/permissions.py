from collections.abc import Iterable
from uuid import UUID

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId


class PermissionsService(BaseService):
    """Service to interact with permissions."""

    def for_organization(self, names: Iterable[dt.PermissionName | str]) -> list[str]:
        """Construct permissions for the current user's organization.

        Args:
            names: Permission names to build for the organization.

        Returns:
            List of permission strings for the current user's organization.
        """
        user = self.client.users.me.get().user

        return self._for("organization", user.org, names)

    def for_project(self, names: Iterable[dt.PermissionName | str], *, project: ObjOrId[dt.Project]) -> list[str]:
        """Construct permissions for a project.

        Args:
            names: Permission names to build for the project.
            project: The project to create permissions for

        Returns:
            List of permission strings for the chosen project.
        """
        return self._for("project", self._util.getId(project), names)

    def _for(self, resource_type: str, resource_id: str | UUID, names: Iterable[dt.PermissionName | str]) -> list[str]:
        return [
            f"{resource_type}:{resource_id}:{name.value if isinstance(name, dt.PermissionName) else name}"
            for name in names
        ]
