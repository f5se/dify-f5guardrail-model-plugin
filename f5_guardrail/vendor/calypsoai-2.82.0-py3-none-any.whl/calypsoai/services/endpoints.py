from collections.abc import Iterator, Sequence
from typing import TypeVar
from uuid import UUID

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId

_ConfigObj = TypeVar("_ConfigObj")
_ConfigObjOrId = _ConfigObj | UUID | str | dict


class EndpointsService(BaseService):
    """Service to interact with endpoints."""

    def get(self, endpoint: ObjOrId[dt.Endpoint]) -> dt.Endpoint:
        """Get an endpoint by ID or name.

        Args:
            endpoint: Endpoint to retrieve.

        Returns:
            The requested endpoint.
        """
        return self.client.endpoints.getEndpoint(self._util.getId(endpoint)).endpoint

    def getDefault(self, group: ObjOrId[dt.Group] | None = None) -> dt.Endpoint:
        """Get the default endpoint for the chosen group.

        Args:
            group: Group to use. If not provided, the global default will be retrieved.

        Returns:
            The default endpoint for the chosen group or global settings.
        """
        return self.client.endpoint.get(groupId=self._util.getIdOrNone(group)).endpoint

    def iterate(self, group: ObjOrId[dt.Group] | None = None) -> Iterator[dt.Endpoint]:
        """Iterate over all available endpoints for the chosen group.

        Args:
            group: Group to use. If not provided, the global endpoints will be retrieved.

        Yields:
            Each endpoint for the chosen group or global settings.
        """
        yield from self.client.endpoints.get(groupId=self._util.getIdOrNone(group)).endpoints

    def create(
        self,
        *,
        group: ObjOrId[dt.Group] | None = None,
        name: str | None = None,
        packages: Sequence[_ConfigObjOrId[dt.ProjectConfigScanner]] = [],
        providers: Sequence[_ConfigObjOrId[dt.ProjectConfigProvider]] = [],
        scanners: Sequence[_ConfigObjOrId[dt.ProjectConfigScanner]] = [],
    ) -> dt.Endpoint:
        """Create a new endpoint for a group or global settings.

        Args:
            name: Optional name for the endpoint. Must be unique.
            group: Group to assign endpoint to. If not provided, the endpoint will be globally accessible.
            packages: Scanner packages to run on prompts sent to the endpoint.
            scanners: Scanners to run on prompts sent to the endpoint.
            providers: Providers to allow sending prompts to through the endpoint.

        Returns:
            The newly created endpoint.
        """
        endpointId = self.client.endpoints.post(
            body=dt.PostEndpointsBody(
                config=dt.ProjectConfig(
                    packages=[self._toScannerConfig(obj) for obj in packages],
                    scanners=[self._toScannerConfig(obj) for obj in scanners],
                    providers=[self._toProviderConfig(obj) for obj in providers],
                ),
                groupId=self._util.getIdOrNone(group),
                name=name,
            ),
        ).id
        return self.get(endpointId)

    def update(
        self,
        endpoint: ObjOrId[dt.Endpoint],
        *,
        name: str | None = None,
        packages: Sequence[_ConfigObjOrId[dt.ProjectConfigScanner]] = [],
        providers: Sequence[_ConfigObjOrId[dt.ProjectConfigProvider]] = [],
        scanners: Sequence[_ConfigObjOrId[dt.ProjectConfigScanner]] = [],
    ) -> None:
        """Update an existing endpoint.

        Args:
            endpoint: Endpoint to update.
            name: New name for the endpoint. Must be unique.
            packages: Toggle or edit configuration for scanner packages for the endpoint.
            scanners: Toggle or edit configuration for scanners for the endpoint.
            providers: Toggle or edit configuration for providers for the endpoint.
        """
        self.client.endpoints.patchEndpoint(
            endpoint=self._util.getId(endpoint),
            body=dt.PatchEndpointBody(
                config=dt.ProjectConfig(
                    packages=[self._toScannerConfig(obj) for obj in packages],
                    scanners=[self._toScannerConfig(obj) for obj in scanners],
                    providers=[self._toProviderConfig(obj) for obj in providers],
                ),
                name=name,
            ),
        )

    def getScanners(
        self,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        group: ObjOrId[dt.Group] | None = None,
    ) -> dt.ProjectScanners:
        """Get the scanners that will run when a prompt is sent to the specified endpoint.

        Args:
            endpoint: Endpoint to get get scanners for.
                If not provided, the endpoint for the group specified or global settings will be used.
            group: Group to get default endpoint for. If not provided, the global settings will be used.

        Returns:
            All scanners that will be run on this endpoint, including their endpoint specific configuration.
        """
        endpointId = self._util.getIdOrNone(endpoint) or self.getDefault(group=group).id

        return self.client.endpoints.scanners.get(endpoint=endpointId).endpointScanners

    def _toScannerConfig(self, obj: _ConfigObjOrId[dt.ProjectConfigScanner]) -> dt.ProjectConfigScanner:
        if isinstance(obj, dt.ProjectConfigScanner):
            return obj
        if isinstance(obj, UUID | str):
            return dt.ProjectConfigScanner(id=obj)
        return dt.ProjectConfigScanner.model_validate(obj)

    def _toProviderConfig(self, obj: _ConfigObjOrId[dt.ProjectConfigProvider]) -> dt.ProjectConfigProvider:
        if isinstance(obj, dt.ProjectConfigProvider):
            return obj
        if isinstance(obj, UUID | str):
            return dt.ProjectConfigProvider(id=obj, enabled=True)
        return dt.ProjectConfigProvider.model_validate(obj)
