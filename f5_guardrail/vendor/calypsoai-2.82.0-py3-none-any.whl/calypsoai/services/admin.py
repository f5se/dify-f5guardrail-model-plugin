import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService


class AdminService(BaseService):
    """Service to interact with admin functionality."""

    def exportSettings(self) -> dt.OrgExport:
        """Export all scanner and provider configurations in JSON format.

        Exported data can be used to restore configurations to previous points in time.

        Secrets used by providers will not have their values included in the
        export and so should be replaced in the export before importing or
        updated after import.

        Example:
            ```python
                from calypsoai import CalypsoAI

                cai = CalypsoAI()

                scanner = cai.scanners.createCustom("Puppy Scanner", "puppies")

                export = cai.admin.exportSettings()

                cai.scanners.updateCustom(scanner, name="Kitten Scanner", description="kittens")

                cai.admin.importSettings(export)

                scanner = cai.scanners.get(scanner)

                assert scanner.name == "Puppy Scanner"
            ```



        Returns:
            The configuration for all scanners and providers for both global and group settings.
        """
        response = self.client.admin.export.post()
        return response.export

    def importSettings(self, export: dt.OrgExport | dict, *, clearExisting: bool = False) -> None:
        """Import a previous export of scanner and provider configurations.

        Args:
            export: The previously exported data.
            clearExisting: Clear all existing organization data. This can not be reversed.
        """
        self.client.admin.import_.post(
            dt.PostAdmingSettingsImportBody(clearExisting=clearExisting, export=export),
        )
