from collections.abc import Iterator, Sequence

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId


class GroupsService(BaseService):
    """Service to interact with groups."""

    def iterate(
        self,
        *,
        search: str | None = None,
        admin: bool | None = None,
        batchSize: int = 50,
    ) -> Iterator[dt.Group]:
        """Iterate through all groups, filtered by args.

        Args:
            search: Filter groups with names matching the given query.
            admin: Filter groups that the authenticated user is admin of.
            batchSize: Size of batches to request.

        Yields:
            Groups matching the given filters.
        """
        response = self.client.groups.get(limit=batchSize, search=search, admin=admin)
        yield from response.groups
        while cursor := response.next:
            response = self.client.groups.get(limit=batchSize, search=search, admin=admin, cursor=cursor)
            yield from response.groups

    def create(self, name: str) -> dt.Group:
        """Create a new group.

        Args:
            name: Name of the new group. Must be unique.

        Returns:
            The newly created group.
        """
        return self.client.groups.post(body=dt.PostGroupBody(name=name)).group

    def get(self, group: ObjOrId[dt.Group]) -> dt.Group:
        """Get a group by ID.

        Args:
            group: Group to retrieve.

        Returns:
            The requested group.
        """
        return self.client.groups.getGroupId(groupId=self._util.getId(group)).group

    def update(self, group: ObjOrId[dt.Group], *, name: str) -> None:
        """Update a group.

        User must be an admin of the group.

        Args:
            group: Group to update.
            name: New name for the group. Must be unique.
        """
        self.client.groups.patchGroupId(groupId=self._util.getId(group), body=dt.PatchGroupBody(name=name))

    def delete(self, group: ObjOrId[dt.Group]) -> None:
        """Delete a group.

        Args:
            group: Group to delete.
        """
        self.client.groups.deleteGroupId(groupId=self._util.getId(group))

    def addUsers(self, group: ObjOrId[dt.Group], *, users: Sequence[ObjOrId[dt.User]]) -> None:
        """Add users to a group.

        Only a group admin can add users to a group.

        Args:
            group: Group to add users to.
            users: Users to add to the chosen group.
        """
        self.client.groups.users.post(
            groupId=self._util.getId(group),
            body=dt.PostGroupUsersBody(members=[self._util.getId(obj) for obj in users]),
        )

    def setAdminStatus(self, group: ObjOrId[dt.Group], *, user: ObjOrId[dt.User], admin: bool) -> None:
        """Make or remove a user as an admin of group.

        Only group admins can change a users admin status.

        Args:
            group: Group to change user's status in.
            user: User to update status of.
            admin: Whether or not the user should be admin.
        """
        self.client.groups.users.patchUserId(
            groupId=self._util.getId(group),
            userId=self._util.getId(user),
            body=dt.PatchGroupUserBody(admin=admin),
        )

    def removeUser(self, group: ObjOrId[dt.Group], *, user: ObjOrId[dt.User]) -> None:
        """Remove a user from a group.

        Only a group admin can remove a user from a group.

        Args:
            group: Group to remove user from.
            user: User to remove from group.
        """
        self.client.groups.users.deleteUserId(groupId=self._util.getId(group), userId=self._util.getId(user))
