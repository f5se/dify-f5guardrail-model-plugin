from collections.abc import Iterator, Sequence
from uuid import UUID

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId, ObjWithId


class ChatsService(BaseService):
    """Service to interact with chats."""

    def iterate(
        self,
        *,
        limit: int = 10,
        starred: bool | None = None,
    ) -> Iterator[dt.Chat]:
        """Iterate through chats belonging to the user.

        These contain details of users interactions with an LLM. Results can be filtered by query args.

        Yields:
            Each chat belonging the authenticated user.
        """
        response = self.client.chats.get(limit=limit, starred=starred)
        yield from response.chats
        while response.chats:
            response = self.client.chats.get(limit=limit, before=response.chats[-1].id, starred=starred)
            yield from response.chats

    def createFromPrompt(self, *, name: str, prompt: ObjOrId[dt.Prompt]) -> dt.Chat:
        """Create a new chat with an LLM from a prompt.

        The newly created chat will use the existing prompts referred to instead of duplicating.

        Args:
            name: Name of the new chat.
            prompt: Prompt to create the chat from.
                Sending a new prompt to this chat will use this prompt as its previous messages.

        Returns:
            The newly created chat.
        """
        chatId = self.client.chats.post(dt.PostChatsFromPromptBody(name=name, promptId=self._util.getId(prompt))).id
        return self.get(chatId)

    def createFromPromptTemplate(self, *, name: str, promptTemplate: ObjOrId[dt.PromptTemplate]) -> dt.Chat:
        """Create a new chat with an LLM from a prompt template.

        The newly created chat will duplicate all prompts in the prompt template.

        Args:
            name: Name of the new chat.
            promptTemplate: Prompt template to create the chat from.
                Sending a new prompt to this chat will use the prompts from this template as its previous messages.

        Returns:
            The newly created chat.
        """
        chatId = self.client.chats.post(
            dt.PostChatsFromTemplateBody(name=name, promptTemplateId=self._util.getId(promptTemplate)),
        ).id
        return self.get(chatId)

    def getPublic(self, access: UUID) -> dt.GetPublicChatResponse:
        """Get a chat using a public access ID along with its prompts and other relevant data.

        Chat must be publicly accessible.

        Args:
            access: Access ID generated when making the chat publicly accessible.

        Returns:
            The chat along with other related data that is also publically available.
        """
        return self.client.chats.public.getAccessId(accessId=access)

    def get(self, chat: ObjOrId[dt.Chat]) -> dt.Chat:
        """Get a chat by ID.

        User must have access to the chat.

        Access is automatically given to the user who created the chat and can be manually given to others by the owner.

        Returns:
            The requested chat object.
        """
        return self.client.chats.getChatId(chatId=self._util.getId(chat)).chat

    def update(
        self,
        chat: ObjOrId[dt.Chat],
        *,
        name: str | None = None,
        starred: bool | None = None,
        publicAccess: bool | None = None,
        orgAccess: bool | None = None,
        userAccess: Sequence[ObjWithId[dt.User]] = [],
        removeUserAccess: Sequence[ObjWithId[dt.User]] = [],
    ) -> None:
        """Update a chat.

        Only the chats owner may update a chat.

        Args:
            chat: Chat to update.
            name: New name for the chat.
            starred: Whether or not the chat should be starred.
            publicAccess: Make the chat publically shareable.
            orgAccess: Allow the chat to be access by anyone in the org.
            userAccess: Give specific users access by adding their user ID to the list
            removeUserAccess: Remove a users access if they have been given access.
        """
        self.client.chats.patchChatId(
            body=dt.PatchChatBody(
                name=name,
                orgAccess=orgAccess,
                publicAccess=publicAccess,
                userAccess=[self._util.getId(obj) for obj in userAccess],
                removeUserAccess=[self._util.getId(obj) for obj in removeUserAccess],
                starred=starred,
            ),
            chatId=self._util.getId(chat),
        )

    def delete(self, chat: ObjOrId[dt.Chat]) -> None:
        """Delete a chat.

        Only the chats owner may delete a chat.
        """
        self.client.chats.deleteChatId(chatId=self._util.getId(chat))
