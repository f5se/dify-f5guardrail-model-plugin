from collections.abc import Iterator, Sequence
from datetime import datetime
from typing import Literal

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId


class CampaignsService(BaseService):
    """Service to interact with campaigns."""

    def create(
        self,
        *,
        name: str,
        description: str | None = None,
        attacks: Sequence[
            Literal["static_content", "operational"]
            | dt.StaticContentAttack
            | dt.DynamicSingleTurnContentAttack
            | dt.DynamicMultiTurnContentAttack
            | dt.OperationalAttack
        ],
    ) -> dt.Campaign:
        """Create a new campaign.

        Example:
            ```python
            from calypsoai import CalypsoAI

            cai = CalypsoAI()

            campaign = cai.campaigns.create(
                name="My First Campaign",
                attacks=["static_content"],
            )
            print(f"Created campaign {campaign.name}")
        ```

        Args:
            name: Name for the campaign.
            description: Optional description for the campaign.
            attacks: List of attacks to run as part of this campaign.

        Returns:
            The newly created campaign.
        """
        campaignId = self.client.campaigns.post(
            dt.PostCampaignsBody(name=name, description=description, attacks=list(attacks)),
        ).id
        return self.client.campaigns.getCampaignId(campaignId).campaign

    def update(
        self,
        campaign: ObjOrId[dt.Campaign],
        *,
        name: str | None = None,
        description: str | None = None,
        attacks: Sequence[
            dt.StaticContentAttack
            | dt.DynamicSingleTurnContentAttack
            | dt.DynamicMultiTurnContentAttack
            | dt.OperationalAttack
        ]
        | None = None,
    ) -> None:
        """Update an existing campaign.

        Example:
            ```python
            from calypsoai import CalypsoAI

            cai = CalypsoAI()

            campaign = cai.campaigns.create(name="My First Campaign", attacks=[])

            cai.campaigns.update(campaign, attacks=["static_content", "operational"])
        ```

        Args:
            campaign: The campaign to update.
            name: New name for the campaign.
            description: New description for the campaign.
            attacks: New list of attacks to run as part of this campaign.

        """
        self.client.campaigns.patchCampaignId(
            self._util.getId(campaign),
            dt.PatchCampaignBody(name=name, description=description, attacks=attacks),
        )

    def get(self, campaign: ObjOrId[dt.Campaign]) -> dt.Campaign:
        """Get a campaign by ID.

        Args:
            campaign: Campaign to retrieve.

        Returns:
            The chosen campaign.
        """
        return self.client.campaigns.getCampaignId(self._util.getId(campaign)).campaign

    def iterate(self, *, batchSize: int = 10) -> Iterator[dt.Campaign]:
        """Iterate through all campaigns.

        Args:
            batchSize: Number of items returned by each underlying API call. Default is 10

        Yields:
            All campaigns.
        """
        cursor = None
        while True:
            response = self.client.campaigns.get(
                cursor=cursor,
                limit=batchSize,
            )
            yield from response.campaigns

            if not response.next:
                break
            cursor = response.next

    def run(
        self, campaign: ObjOrId[dt.Campaign], *, name: str, providers: Sequence[ObjOrId[dt.Provider]]
    ) -> dt.CampaignRun:
        """Run a campaign against one or more providers.

        Args:
            campaign: Campaign to run.
            providers: Providers to run the campaign against.
            name: Name of the campaign run

        Returns:
            The campaign run that has been started.
        """
        runId = self.client.campaignRuns.post(
            dt.PostRunCampaignBody(
                campaignId=self._util.getId(campaign),
                providerIds=[self._util.getId(provider) for provider in providers],
                name=name,
            ),
        ).id
        return self.client.campaignRuns.getCampaignRunId(runId).campaignRun

    def scheduleRun(
        self,
        campaign: ObjOrId[dt.Campaign],
        *,
        name: str,
        startAt: datetime,
        providers: Sequence[ObjOrId[dt.Provider]],
        count: int | None = None,
        endAt: datetime | None = None,
        frequency: dt.CampaignScheduleFrequency | Literal["days", "weeks"] | None = None,
        interval: int | None = None,
    ) -> tuple[dt.CampaignRun, dt.CampaignSchedule]:
        """Schedule a campaign to run against one or more providers.

        Example:
            ```python
            from datetime import datetime, UTC
            import calypsoai.datatypes as dt
            from calypsoai import CalypsoAI

            cai = CalypsoAI()

            campaign = cai.campaigns.create(
                name="My First Campaign", attacks=["static_content", "operational"]
            )

            # Will run every 2 days at 12:00pm until 5 runs have ran.
            cai.campaigns.scheduleRun(
                created_campaign.id,
                providers=[provider.id],
                name="Ends on Jan 10rd",
                startAt=datetime(year=2025, month=1, day=1, hour=12, tzinfo=UTC),
                frequency=dt.CampaignScheduleFrequency.DAYS,
                interval=2,
                count=5,
            )
            # Will run every 2 days at 12:00pm until the 10th of Jan (5 runs in total).
            cai.campaigns.scheduleRun(
                created_campaign.id,
                providers=[provider.id],
                name="Ends on Jan 10rd",
                startAt=datetime(year=2025, month=1, day=1, hour=12, tzinfo=UTC),
                frequency=dt.CampaignScheduleFrequency.DAYS,
                interval=2,
                endAt=datetime(year=2025, month=1, day=10, hour=23),
            )
        ```

        Args:
            campaign: Campaign to run.
            providers: Providers to run the campaign against.
            name: Name of the scheduled run.
            startAt: Target time to start the first campaign run, it must be in the future.
            count: Determines how many occurrences will be generated. Cannot specify both count and endAt.
            frequency: How often the schedule should run.
            endAt: Target time after which no future occurrences will be generated.
            interval: The interval between each frequency iteration. For example, when using DAYS, an interval of 2
                means once every two days. The default interval is 1.


        Returns:
            A tuple of the campaign run and campaign schedule.
        """
        run = self.client.campaignSchedules.post(
            dt.PostCampaignScheduleBody(
                campaignId=self._util.getId(campaign),
                providerIds=[self._util.getId(provider) for provider in providers],
                name=name,
                startAt=startAt,
                count=count,
                endAt=endAt,
                frequency=frequency,
                interval=interval,
            ),
        )
        return (
            self.client.campaignRuns.getCampaignRunId(run.campaignRunId).campaignRun,
            self.client.campaignSchedules.getCampaignScheduleId(run.id),
        )

    def updateSchedule(
        self,
        campaignSchedule: ObjOrId[dt.CampaignSchedule],
        *,
        name: str | None = None,
        startAt: datetime | None = None,
        count: int | None = None,
        endAt: datetime | None = None,
        frequency: dt.CampaignScheduleFrequency | Literal["days", "weeks"] | None = None,
        interval: int | None = None,
    ) -> None:
        """Update a campaign schedule.

        Args:
            campaignSchedule: Id of campaign schedule to be updated.
            name: Name of the camapign schedule.
            startAt: Target time to start the first campaign run, it must be in the future.
            count: Determines how many occurrences will be generated. Cannot specify both count and endAt.
            frequency: How often the schedule should run.
            endAt: Target time after which no future occurrences will be generated.
            interval: The interval between each frequency iteration. For example, when using DAYS, an interval of 2
                means once every two days. The default interval is 1.
        """
        self.client.campaignSchedules.patchCampaignScheduleId(
            campaignScheduleId=self._util.getId(campaignSchedule),
            body=dt.UpdateScheduleParams(
                name=name, startAt=startAt, count=count, endAt=endAt, frequency=frequency, interval=interval
            ),
        )

    def deleteSchedule(
        self, campaignSchedule: ObjOrId[dt.CampaignSchedule], *, cancelRunningAttacks: bool | None = False
    ) -> None:
        """Delete a campaign schedule. This will cancel the scheduled campaign runs.

        Args:
            campaignSchedule: Id of campaign schedule to be deleted.
            cancelRunningAttacks: Will cancel attacks created by this schedule, which are currently in progress.
                Defaults to False
        """
        self.client.campaignSchedules.deleteCampaignScheduleId(
            campaignScheduleId=self._util.getId(campaignSchedule),
            cancelRunningAttacks=cancelRunningAttacks,
        )

    def getRun(self, campaignRun: ObjOrId[dt.CampaignRun]) -> dt.CampaignRun:
        """Get a campaign run by ID.

        Args:
            campaignRun: Campaign run to retrieve.

        Returns:
            The chosen campaign run.
        """
        return self.client.campaignRuns.getCampaignRunId(self._util.getId(campaignRun)).campaignRun

    def deleteRun(self, campaignRun: ObjOrId[dt.CampaignRun]) -> None:
        """Delete a campaign run by ID.

        Args:
            campaignRun: Campaign run to delete.
        """
        self.client.campaignRuns.deleteCampaignRunId(self._util.getId(campaignRun))

    def updateRun(
        self,
        campaignRun: ObjOrId[dt.CampaignRun],
        *,
        name: str | None = None,
        startAt: datetime | None = None,
    ) -> None:
        """Update a campaign run.

        Args:
            campaignRun: Campaign run to patch.
            name: New name for campaign run.
            startAt: New start time for run.
        """
        self.client.campaignRuns.patchCampaignRunId(
            campaignRunId=self._util.getId(campaignRun),
            body=dt.PatchCampaignRunBody(name=name, startAt=startAt),
        )

    def cancelRun(
        self,
        campaignRun: ObjOrId[dt.CampaignRun],
    ) -> None:
        """Cancel a campaign run.

        Args:
            campaignRun: Campaign run to cancel.
        """
        self.client.campaignRuns.patchCampaignRunId(
            campaignRunId=self._util.getId(campaignRun),
            body=dt.PatchCampaignRunBody(status=dt.CampaignRunStatus.CANCELLED),
        )

    def delete(self, campaign: ObjOrId[dt.Campaign]) -> None:
        """Delete a campaign by ID.

        Args:
            campaign: Campaign to delete.

        """
        self.client.campaigns.deleteCampaignId(self._util.getId(campaign))
