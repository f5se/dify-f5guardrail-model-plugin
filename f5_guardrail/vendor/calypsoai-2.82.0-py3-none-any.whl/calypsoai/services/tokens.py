from collections.abc import Iterator
from datetime import datetime, timedelta, timezone

from pydantic import AwareDatetime

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId


class TokensService(BaseService):
    """Service to interact with API tokens."""

    def iterate(
        self,
        *,
        project: ObjOrId[dt.Project] | None = None,
        group: ObjOrId[dt.Group] | None = None,
        machine: bool = False,
        batchSize: int = 10,
    ) -> Iterator[dt.Token]:
        """Iterate through all API tokens created.

        The secret value will be masked in the response.

        Args:
            machine: If true returns only machine tokens, if false doesn't return machine tokens.
            project: If set to the Id of a user project and machine=True,
                returns machine tokens for only that specific user project. Has no effect if machine=False
            group: (Deprecated) If set to the Id of a user group and machine=True,
                returns machine tokens for only that specific user group. Has no effect if machine=False
            batchSize: Size of batches to request

        Yields:
            All previously created API tokens, matching the given filters.
        """
        cursor = None
        while True:
            response = self.client.tokens.get(
                machine=machine,
                groupId=self._util.getIdOrNone(group),
                projectId=self._util.getIdOrNone(project),
                limit=batchSize,
                cursor=cursor,
            )
            yield from response.tokens
            if not (cursor := response.next):
                break

    def createUserToken(self, *, name: str, expiresAt: AwareDatetime | None = None) -> dt.Token:
        """Create a new user API token.

        Args:
            name: Name for the new API token.
            expiresAt: When the API token expires. If not provided, defaults to 30 days after creation time.

        Returns:
            The newly created API token with the value available.
            The value will not be visible when retrieving from the API again.

        """
        return self.client.tokens.post(
            body=dt.PostTokensBody(name=name, expiresAt=expiresAt or (datetime.now(timezone.utc) + timedelta(days=30))),
        ).token

    def createMachineToken(
        self,
        *,
        name: str,
        expiresAt: AwareDatetime | None = None,
        project: ObjOrId[dt.Project] | None = None,
        group: ObjOrId[dt.Group] | None = None,
    ) -> dt.Token:
        """Create a new API token.

        Args:
            name: Name for the new API token.
            expiresAt: When the API token expires. If not provided, defaults to 30 days after creation time.
            project: Project to create the API token for.
                If not provided, the token will be a global token with super admin permissions.
            group: Group to create the API token for.
                If not provided, the token will be a global token with super admin permissions.

        Returns:
            The newly created API token with the value available.
            The value will not be visible when retrieving from the API again.
        """
        return self.client.tokens.post(
            body=dt.PostTokensMachineBody(
                machine=True,
                name=name,
                groupId=self._util.getIdOrNone(group),
                projectId=self._util.getIdOrNone(project),
                expiresAt=expiresAt or (datetime.now(timezone.utc) + timedelta(days=30)),
            ),
        ).token

    def delete(self, token: ObjOrId[dt.Token]) -> None:
        """Delete an API token.

        Args:
            token: rPI token to delete.
        """
        self.client.tokens.deleteTokenId(tokenId=self._util.getId(token))
