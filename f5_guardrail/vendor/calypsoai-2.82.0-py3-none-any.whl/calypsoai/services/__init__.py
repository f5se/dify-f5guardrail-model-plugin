from concurrent.futures import ThreadPoolExecutor

from calypsoai.clients import CalypsoAIClient
from calypsoai.services.admin import AdminService
from calypsoai.services.base import BaseService
from calypsoai.services.campaigns import CampaignsService
from calypsoai.services.chats import ChatsService
from calypsoai.services.endpoints import EndpointsService
from calypsoai.services.groups import GroupsService
from calypsoai.services.org import OrganizationsService
from calypsoai.services.permissions import PermissionsService
from calypsoai.services.projects import ProjectsService
from calypsoai.services.prompt_templates import PromptTemplateService
from calypsoai.services.prompts import PromptsService
from calypsoai.services.providers import ProvidersService
from calypsoai.services.roles import RolesService
from calypsoai.services.scanner_packages import ScannerPackagesService
from calypsoai.services.scanners import ScannersService
from calypsoai.services.scans import ScansService
from calypsoai.services.tokens import TokensService
from calypsoai.services.users import UsersService


class CalypsoAI(BaseService):
    """Top level service for all CalypsoAI APIs.

    Services provide extra functionality on top of using API clients directly.
    """

    client: CalypsoAIClient
    "Low level client to interact directly with the CalypsoAI API."

    admin: AdminService
    "Service to interact with admin functionality."
    prompts: PromptsService
    "Service to interact with prompts."
    endpoints: EndpointsService
    "Service to interact with endpoints."
    providers: ProvidersService
    "Service to interact with providers."
    scanners: ScannersService
    "Service to interact with scanners."
    scannerPackages: ScannerPackagesService
    "Service to interact with scanner packages."
    scans: ScansService
    "Service to interact with scan requests."
    groups: GroupsService
    "Service to interact with groups."
    chats: ChatsService
    "Service to interact with chats."
    promptTemplates: PromptTemplateService
    "Service to interact with prompt templates."
    tokens: TokensService
    "Service to interact with API tokens."
    users: UsersService
    "Service to interact with users."
    organizations: OrganizationsService
    "Service to interact with organizations."
    campaigns: CampaignsService
    "Service to interact with campaigns."
    projects: ProjectsService
    "Service to interact with projects."
    roles: RolesService
    "Service to interact with roles."
    permissions: PermissionsService
    "Service to interact with permissions."

    def __init__(
        self,
        client: CalypsoAIClient | None = None,
        *,
        url: str | None = None,
        token: str | None = None,
        headers: dict | None = None,
        verify_tls: bool = True,
    ) -> None:
        """Create a new top level service for CalypsoAI services.

        Args:
            client: Low level client to use to make requests to the CalypsoAI API.
                If provided, all other arguments are ignored.
            url: Base URL to use for requests. Read from CALYPSOAI_URL if not given, defaults to "https://calypsoai.app"
            token: API token to use for authorization in requests. Read from CALYPSOAI_TOKEN if not given.
            headers: Additional headers to send in all requests.
            verify_tls: Verify TLS certificates on each request. Set to False to accept any certificate.

        """
        client = client or CalypsoAIClient(url=url, token=token, headers=headers, verify_tls=verify_tls)
        executor = ThreadPoolExecutor(max_workers=32)
        super().__init__(client=client, _executor=executor)
