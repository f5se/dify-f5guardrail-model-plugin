from collections.abc import Iterator

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId


class PromptTemplateService(BaseService):
    """Service to interact with prompt templates."""

    def create(
        self,
        prompt: ObjOrId[dt.Prompt],
        name: str,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        project: ObjOrId[dt.Project] | None = None,
    ) -> dt.PromptTemplate:
        """Create a new prompt template.

        Args:
            prompt: Prompt to create the template from. The prompt and its ancestors will be duplicated.
            name: Name of the prompt template.
            endpoint: (Deprecated) Endpoint to make the prompt template available to.
            project: Project to make the prompt template available to.
                If not provided, the template will be only available to the authenticated user.

        Returns:
            The newly created prompt template.
        """
        templateId = self.client.prompts.templates.post(
            body=dt.PostPromptTemplatesBody(
                endpointId=self._util.getIdOrNone(endpoint),
                project=self._util.getIdOrNone(project),
                name=name,
                promptId=self._util.getId(prompt),
            ),
        ).id
        return self.get(templateId)[0]

    def iterate(
        self,
        *,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        project: ObjOrId[dt.Project] | None = None,
        batchSize: int = 10,
    ) -> Iterator[dt.PromptTemplate]:
        """Iterate through all prompt templates.

        Args:
            endpoint: (Deprecated) Endpoint to get prompt templates for.
                If not provided, the personal prompt templates for the authenticated user will be retrieved.
            project: Project to get prompt templates for.
                If not provided, the personal prompt templates for the authenticated user will be retrieved.
            batchSize: Size of batches to request.

        Yields:
            Prompt templates available for the chosen endpoint or user.
        """
        before = None
        while promptTemplates := self.client.prompts.templates.get(
            before=before,
            limit=batchSize,
            endpointId=self._util.getIdOrNone(endpoint),
            project=self._util.getIdOrNone(project),
        ).promptTemplates:
            yield from promptTemplates
            before = promptTemplates[-1].id

    def get(self, promptTemplate: ObjOrId[dt.PromptTemplate]) -> tuple[dt.PromptTemplate, list[dt.Prompt]]:
        """Get a prompt template by ID along with the prompts it contains.

        Args:
            promptTemplate: The prompt template to retrieve.

        Returns:
            The chosen prompt template and its prompts
        """
        response = self.client.prompts.templates.getPromptTemplateId(promptTemplateId=self._util.getId(promptTemplate))
        return response.promptTemplate, response.prompts

    def update(self, promptTemplate: ObjOrId[dt.PromptTemplate], *, name: str) -> None:
        """Update a prompt template.

        Args:
            promptTemplate: The prompt template to update.
            name: New name for the prompt template.
        """
        self.client.prompts.templates.patchPromptTemplateId(
            promptTemplateId=self._util.getId(promptTemplate),
            body=dt.PatchPromptTemplateBody(name=name),
        )

    def delete(self, promptTemplate: ObjOrId[dt.PromptTemplate]) -> None:
        """Delete a prompt template.

        The prompts within the template are not deleted.

        Args:
            promptTemplate: Prompt template to delete.
        """
        self.client.prompts.templates.deletePromptTemplateId(promptTemplateId=self._util.getId(promptTemplate))
