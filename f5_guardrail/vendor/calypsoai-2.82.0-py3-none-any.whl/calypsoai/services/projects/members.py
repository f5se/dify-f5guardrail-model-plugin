from collections.abc import Iterator, Sequence

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId


class ProjectMembersService(BaseService):
    """Service to interact with project members."""

    def add(
        self,
        project: ObjOrId[dt.Project],
        *,
        members: Sequence[ObjOrId[dt.User]],
        admin: bool = False,
    ) -> None:
        """Add users to a group.

        Only a group admin can add users to a project.

        Args:
            project: Project to add members to.
            admin: If true, all members added are assigned as admin as well.
            members: Users to add as members.
        """
        self.client.projects.members.post(
            self._util.getId(project),
            dt.PostProjectMembersBody(admin=admin, members=[self._util.getId(member) for member in members]),
        )

    def setRole(self, project: ObjOrId[dt.Project], *, admin: bool, user: ObjOrId[dt.User]) -> None:
        """Update a user's admin status in a project.

        Only project admins can change a users admin status.

        Args:
            project: Project to set the user's role within.
            admin: Whether to set the user to admin or not.
            user: User to change the role.
        """
        self.client.projects.members.patchUserId(
            project=self._util.getId(project),
            userId=self._util.getId(user),
            body=dt.PatchProjectMemberBody(admin=admin),
        )

    def remove(self, project: ObjOrId[dt.Project], *, user: ObjOrId[dt.User]) -> None:
        """Remove a user from a project.

        Only project admins can change a users membership status.

        Args:
            project: Project to remove the user from.
            user: User to remove as member.
        """
        self.client.projects.members.deleteUserId(
            project=self._util.getId(project),
            userId=self._util.getId(user),
        )

    def iterate(
        self,
        project: ObjOrId[dt.Project],
        *,
        search: str | None = None,
        batchSize: int = 10,
        admin: bool = False,
    ) -> Iterator[dt.User]:
        """Iterate over all members of a project.

        Args:
            project: Project to get users from.
            search: Only return users matching the given text.
            admin: If true, only return members that are admins.
            batchSize: Number of users returned by each underlying API call.

        Yields:
            All members of a project, matching the given filters.
        """
        project = project if isinstance(project, dt.Project) else self.client.projects.getProject(project).project

        role = project.adminRoleId if admin else project.memberRoleId

        cursor = None
        while True:
            response = self.client.users.get(
                cursor=cursor,
                search=search,
                limit=batchSize,
                roleId=role,
            )
            yield from response.users
            if not (cursor := response.next):
                break
