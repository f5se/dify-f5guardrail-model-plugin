from collections.abc import Iterator, Sequence
from typing import TypeVar
from uuid import UUID

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId
from calypsoai.services.projects.members import ProjectMembersService

_ConfigObj = TypeVar("_ConfigObj")
_ConfigObjOrId = _ConfigObj | UUID | str | dict


class ProjectsService(BaseService):
    """Service to interact with projects."""

    members: ProjectMembersService
    "Service to interact with project members."

    P = TypeVar("P", bound=dt.Project)

    def get(self, project: ObjOrId[P]) -> P:
        """Get an project by ID or name.

        Args:
            project: Project to retrieve.

        Returns:
            The requested project.
        """
        return self.client.projects.getProject(self._util.getId(project)).project

    def getDefault(self) -> dt.Project:
        """Get the default project for the current user.

        If using a personal token, this will be the global project.
        If using a machine token, this will be the project the token was created for.

        Returns:
            The default project for the current user.
        """
        return self.client.project.get().project

    def iterate(
        self,
        *,
        search: str | None = None,
        sortBy: dt.ProjectSearchSortBy | str = "name",
        batchSize: int = 100,
        projectType: dt.ProjectType | list[dt.ProjectType] | None = None,
        ascending: bool = True,
    ) -> Iterator[dt.Project]:
        """Iterate over all available projects.

        Args:
            search: Only return projects that match the given text.
            batchSize: Number of scanners returned by each underlying API call. Default is 10
            ascending: Whether results should be sorted in ascending order.
            projectType: Only return projects of the given type(s).
            sortBy: Sort results by the given parameter.

        Yields:
            Each project available to the current user.
        """
        cursor = None
        if projectType and not isinstance(projectType, list):
            projectType = [projectType]
        while True:
            response = self.client.projects.get(
                cursor=cursor,
                ascending=ascending,
                search=search,
                sortBy=sortBy,
                limit=batchSize,
                type_=projectType,
            )
            yield from response.projects
            if not response.next:
                break
            cursor = response.next

    def create(
        self,
        *,
        name: str,
        projectType: dt.ProjectType,
        friendlyId: str | None = None,
        packages: Sequence[_ConfigObjOrId[dt.ProjectConfigScanner]] = [],
        providers: Sequence[_ConfigObjOrId[dt.ProjectConfigProvider]] = [],
        scanners: Sequence[_ConfigObjOrId[dt.ProjectConfigScanner]] = [],
        admins: Sequence[ObjOrId[dt.User]] = [],
        members: Sequence[ObjOrId[dt.User]] = [],
    ) -> dt.Project:
        """Create a new project.

        Args:
            name: Name for the project.
            projectType: Type of project to create.
            friendlyId: Optional alias for the project. Must be unique.
            packages: Scanner packages to run on prompts sent to the project.
            scanners: Scanners to run on prompts sent to the project.
            providers: Providers to allow sending prompts to through the project.
            admins: List of users to assign as admins of the new project.
            members: List of users to add as members of the new project (chat project IDs only).

        Returns:
            The newly created project.
        """
        projectId = self.client.projects.post(
            body=dt.PostProjectsBody(
                type=projectType,
                friendlyId=friendlyId,
                config=dt.ProjectConfig(
                    packages=[self._toScannerConfig(obj) for obj in packages],
                    scanners=[self._toScannerConfig(obj) for obj in scanners],
                    providers=[self._toProviderConfig(obj) for obj in providers],
                ),
                name=name,
                adminIds=[self._util.getId(user) for user in admins],
                memberIds=[self._util.getId(user) for user in members],
            ),
        ).id
        return self.get(projectId)

    def update(
        self,
        project: ObjOrId[dt.Project],
        *,
        name: str | None = None,
        friendlyId: str | None = None,
        packages: Sequence[_ConfigObjOrId[dt.ProjectConfigScanner]] = [],
        providers: Sequence[_ConfigObjOrId[dt.ProjectConfigProvider]] = [],
        scanners: Sequence[_ConfigObjOrId[dt.ProjectConfigScanner]] = [],
    ) -> None:
        """Update an existing project.

        Args:
            project: Project to update.
            name: New name for the project.
            friendlyId: New alias for the project. Must be unique.
            packages: Toggle or edit configuration for scanner packages for the project.
            scanners: Toggle or edit configuration for scanners for the project.
            providers: Toggle or edit configuration for providers for the project.
        """
        self.client.projects.patchProject(
            project=self._util.getId(project),
            body=dt.PatchProjectBody(
                friendlyId=friendlyId,
                config=dt.ProjectConfig(
                    packages=[self._toScannerConfig(obj) for obj in packages],
                    scanners=[self._toScannerConfig(obj) for obj in scanners],
                    providers=[self._toProviderConfig(obj) for obj in providers],
                ),
                name=name,
            ),
        )

    def getScanners(self, project: ObjOrId[dt.Project] | None = None) -> dt.ProjectScanners:
        """Get the scanners that will run when a prompt is sent to the specified project.

        Args:
            project: Project to get get scanners for.
                If not provided, the default settings will be used.

        Returns:
            All scanners that will be run on this project, including their project specific configuration.
        """
        projectId = self._util.getIdOrNone(project) or self.getDefault().id

        return self.client.projects.scanners.get(project=projectId).projectScanners

    def _toScannerConfig(self, obj: _ConfigObjOrId[dt.ProjectConfigScanner]) -> dt.ProjectConfigScanner:
        if isinstance(obj, dt.ProjectConfigScanner):
            return obj
        if isinstance(obj, UUID | str):
            return dt.ProjectConfigScanner(id=obj)
        return dt.ProjectConfigScanner.model_validate(obj)

    def _toProviderConfig(self, obj: _ConfigObjOrId[dt.ProjectConfigProvider]) -> dt.ProjectConfigProvider:
        if isinstance(obj, dt.ProjectConfigProvider):
            return obj
        if isinstance(obj, UUID | str):
            return dt.ProjectConfigProvider(id=obj, enabled=True)
        return dt.ProjectConfigProvider.model_validate(obj)
