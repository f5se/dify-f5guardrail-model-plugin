from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId

if TYPE_CHECKING:
    from calypsoai.services.scanners import ScannersService

ScannerConfig = (
    dt.BlacklistScannerConfig
    | dt.DemographicScannerConfig
    | dt.PIIScannerConfig
    | dt.PromptInjectionScannerConfig
    | dt.SentimentAnalysisScannerConfig
    | dt.SourceCodeScannerConfig
    | dt.NamedEntityScannerConfig
    | dt.ToxicityScannerConfig
    | dt.TopicsScannerConfig
    | dt.LegalScannerConfig
    | dt.SecretScannerConfig
)


class ScannerVersionsService(BaseService):
    """Service to interact with scanner versions."""

    scanners: ScannersService

    def iterate(self, scanner: ObjOrId[dt.Scanner], *, onlyPublished: bool = False) -> Iterator[dt.ScannerVersionMeta]:
        """Get metadata for all existing versions of a scanner.

        Args:
            scanner: The scanner to retrieve versions from.
            onlyPublished: Only return published versions of the scanner.

        Yields:
            All versions for a scanner matching the given filters.
        """
        yield from self.client.scanners.versions.get(self._util.getId(scanner), onlyPublished=onlyPublished).versions

    def publish(
        self,
        scanner: ObjOrId[dt.Scanner],
        version: dt.ScannerVersionQuery | None = None,
        *,
        push: bool = False,
    ) -> None:
        """Publish a scanner version for use in projects.

        Args:
            scanner: The scanner to publish the version of.
            version: The version of the scanner to publish.
                     If not specified, the version on given scanner argument will be used.
            push: If true all projects using this scanner will switch to the version being published.
        """
        if not isinstance(scanner, dt.Scanner):
            scanner = self.scanners.get(scanner)

        if not version:
            version = scanner.versionMeta.id

        self.client.scanners.versions.patchVersionId(
            scanner.id, str(version), dt.PatchScannerVersionBody(published=True, push=push)
        )

    def update(
        self,
        scanner: ObjOrId[dt.Scanner],
        version: dt.ScannerVersionQuery | None = None,
        *,
        description: str,
    ) -> None:
        """Update a scanner version.

        Args:
            scanner: The scanner to update the version of.
            version: The version of the scanner to update.
                     If not specified, the version on given scanner argument will be used.
            description: New description for the version.
        """
        if not isinstance(scanner, dt.Scanner):
            scanner = self.scanners.get(scanner)

        if not version:
            version = scanner.versionMeta.id

        self.client.scanners.versions.patchVersionId(
            scanner.id, str(version), dt.PatchScannerVersionBody(description=description)
        )
