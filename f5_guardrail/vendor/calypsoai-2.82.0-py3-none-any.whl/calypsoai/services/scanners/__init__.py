from collections.abc import Iterator
from uuid import UUID

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId
from calypsoai.services.scanners.versions import ScannerVersionsService

ScannerConfig = (
    dt.BlacklistScannerConfig
    | dt.DemographicScannerConfig
    | dt.PIIScannerConfig
    | dt.PromptInjectionScannerConfig
    | dt.SentimentAnalysisScannerConfig
    | dt.SourceCodeScannerConfig
    | dt.NamedEntityScannerConfig
    | dt.ToxicityScannerConfig
    | dt.TopicsScannerConfig
    | dt.LegalScannerConfig
    | dt.SecretScannerConfig
)


class ScannersService(BaseService):
    """Service to interact with scanners."""

    versions: ScannerVersionsService

    def get(self, scanner: ObjOrId[dt.Scanner], *, version: dt.ScannerVersionQuery | None = None) -> dt.Scanner:
        """Get a scanner by ID.

        Args:
            scanner: The scanner to retrieve.
            version: Get the scanner at a particular version.
                     If not specified, the latest published version is fetched.
                     If no published version exists, the latest unpublished version is retrieved.

        Returns:
            The requested scanner.
        """
        return self.client.scanners.getScannerId(self._util.getId(scanner), version=version).scanner

    def iterate(
        self,
        *,
        active: bool = True,
        ascending: bool = False,
        batchSize: int = 10,
        direction: dt.ScannerDirection | str | None = None,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        project: ObjOrId[dt.Project] | None = None,
        group: UUID | dt.Group | None = None,
        published: bool | None = None,
        search: str | None = None,
        sortBy: dt.ScannerSearchSortBy | str = "updated_at",
        source: dt.ScannerSourceType | str | None = None,
        tags: str | None = None,
        modes: list[dt.ScanMode | str] | None = None,
    ) -> Iterator[dt.Scanner]:
        """Iterate through all scanners, filtered by args.

        Args:
            search: Only return scanners that match the given text.
            published: Only return scanners that are published or not.
            direction: Only return scanners that scan in the given direction.
            batchSize: Number of scanners returned by each underlying API call. Default is 10
            group: (Deprecated) Only return scanners that are available to the given
                      group, default is to only return global scanners.
            published: If provided, only return scanners with given published status.
            ascending: Whether results should be sorted in ascending order.
            source: Get results that were created from the given source.
            sortBy: Sort results by the given parameter.
            active: Get results that are active. Only has an effect if endpoint is provided.
            project: Get results match the chosen active state for the given project.
            endpoint: (Deprecated) Get results match the chosen active state for the given endpoint.
            tags: Get results with the given tag
            modes: Get scanners that are set to given mode(s) for the chosen project.

        Yields:
            All scanners matching the given filters.
        """
        cursor = None
        while True:
            response = self.client.scanners.get(
                cursor=cursor,
                active=active,
                ascending=ascending,
                endpoint=self._util.getIdOrNone(endpoint),
                sortBy=sortBy,
                source=source,
                tags=tags,
                enabledForProject=self._util.getIdOrNone(project),
                search=search,
                published=published,
                groupId=self._util.getIdOrNone(group),
                direction=direction,
                limit=batchSize,
                mode=modes,
            )
            yield from response.scanners

            if not response.next:
                break
            cursor = response.next

    def createCustom(
        self,
        name: str,
        description: str,
        *,
        published: bool = False,
        direction: dt.ScannerDirection | str = dt.ScannerDirection.REQUEST,
        group: dt.Group | UUID | str | None = None,
    ) -> dt.Scanner:
        """Create a new custom scanner.

        Args:
            name: Name for the new scanner.
            published: Whether the new scanner is ready for use by users (true) or if it is in testing (false).
            direction: Whether the scanner should scan prompts being sent to an LLM (request), responses coming from
                       an LLM (response) or both (both).
            description: a str describing what the scanner should be scanning for, examples "emojis or emoticons",
                         "people's names".
            group: (Deprecated) Group to limit this scanner to.

        Returns:
            The newly created scanner.
        """
        scannerId = self.client.scanners.post(
            body=dt.PostScannersBody(
                name=name,
                published=published,
                direction=direction,
                config=dt.GenAIScannerConfig(input=description, type="custom"),
                groupId=self._util.getIdOrNone(group),
            ),
        ).id

        return self.get(scannerId)

    def create(
        self,
        name: str,
        config: dt.RegexScannerConfig | dt.GenAIScannerConfig | dt.KeywordScannerConfig,
        *,
        published: bool = True,
        direction: dt.ScannerDirection | str = dt.ScannerDirection.REQUEST,
        version: str | dt.ScannerVersionInputModel | None = None,
    ) -> dt.Scanner:
        """Create a new custom scanner.

        Args:
            name: Name for the new scanner.
            config: Config for the new scanner.
            published: Whether the new scanner is ready for use by users (true) or if it is in testing (false).
            direction: Whether the scanner should scan prompts being sent to an LLM (request), responses coming from
                       an LLM (response) or both (both).
            version: Initial version for the scanner.
                     Can either be a name or object containing extra arguments for the version.

        Returns:
            The newly created scanner.
        """
        scannerId = self.client.scanners.post(
            body=dt.PostScannersBody(
                name=name,
                published=published,
                direction=direction,
                config=config,
                version=version,
            ),
        ).id

        return self.get(scannerId)

    def updateCustom(
        self,
        scanner: ObjOrId[dt.Scanner],
        *,
        name: str | None = None,
        published: bool | None = None,
        direction: dt.ScannerDirection | str | None = None,
        description: str | None = None,
        tags: list[str] | None = None,
    ) -> None:
        """Update a custom scanner.

        Args:
            scanner: Scanner to update.
            name: Name for the new scanner.
            published: Whether the new scanner is ready for use by users (true) or if it is in testing (false).
            direction: Whether the scanner should scan prompts being sent to an LLM (request), responses coming from
                       an LLM (response) or both (both).
            description: a str describing what the scanner should be scanning for, examples "emojis or emoticons",
                         "people's names".
            tags: Tags used to filter scanners.
        """
        self.client.scanners.patchScannerId(
            self._util.getId(scanner),
            dt.PatchScannerBody(
                name=name,
                published=published,
                direction=direction,
                config=dt.GenAIScannerConfig(input=description, type="custom") if description else None,
                tags=tags,
            ),
        )

    def update(
        self,
        scanner: ObjOrId[dt.Scanner],
        *,
        name: str | None = None,
        published: bool | None = None,
        direction: dt.ScannerDirection | str | None = None,
        config: dt.RegexScannerConfig | dt.GenAIScannerConfig | dt.KeywordScannerConfig | None,
        version: str | dict | dt.ScannerVersionInputModel | None = None,
        push: bool = False,
        tags: list[str] | None = None,
    ) -> dt.ScannerVersionMeta | None:
        """Update a custom scanner.

        Args:
            scanner: Scanner to update.
            name: New name for the scanner.
            config: New config for the scanner.
            published: Whether the new scanner is ready for use by users (true) or if it is in testing (false).
            direction: Whether the scanner should scan prompts being sent to an LLM (request), responses coming from
                       an LLM (response) or both (both).
            version: New version for the scanner.
                     Can either be a name or object containing extra arguments for the version.
            tags: Tags used to filter scanners.
            push: If true all projects using this scanner will switch to the version being published.

        Returns:
            Metadata for the new version of the scanner if one was created.
        """
        if push:
            if not isinstance(version, dt.ScannerVersionInputModel | dict):
                version = dt.ScannerVersionInputModel(push=push, name=version)
            elif isinstance(version, dict):
                version = {**version, "push": True}
            elif not version.push:
                version = version.model_copy(update={"push": push})

        return self.client.scanners.patchScannerId(
            self._util.getId(scanner),
            dt.PatchScannerBody(
                name=name,
                published=published,
                version=version,
                direction=direction,
                config=config,
                tags=tags,
            ),
        ).versionMeta

    def delete(self, scanner: ObjOrId[dt.Scanner]) -> None:
        """Delete a scanner by its ID.

        Args:
            scanner: Scanner to delete.

        """
        self.client.scanners.deleteScannerId(self._util.getId(scanner))
