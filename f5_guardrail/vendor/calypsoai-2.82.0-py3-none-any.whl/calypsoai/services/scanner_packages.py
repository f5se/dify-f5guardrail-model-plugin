from collections.abc import Sequence

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId


class ScannerPackagesService(BaseService):
    """Service to interact with scanner packages."""

    def create(self, *, name: str, scanners: Sequence[ObjOrId[dt.Scanner]]) -> dt.ScannerPackage:
        """Create a new scanner package.

        Args:
            name: Name for the new package.
            scanners: Scanners to include in the package.

        Returns:
            The newly created scanner package.
        """
        scannerPackageId = self.client.scannerPackages.post(
            body=dt.PostPackageRequest(
                name=name,
                scannerIds=[self._util.getId(obj) for obj in scanners],
            ),
        ).id

        return self.get(scannerPackageId)

    def get(self, scannerPackage: ObjOrId[dt.ScannerPackage]) -> dt.ScannerPackage:
        """Get a scanner package by ID.

        Args:
            scannerPackage: The scanner package to retrieve.

        Returns:
            The chosen scanner package.
        """
        return self.client.scannerPackages.getScannerPackageId(self._util.getId(scannerPackage)).package

    def getWithScanners(self, scannerPackage: ObjOrId[dt.ScannerPackage]) -> tuple[dt.ScannerPackage, list[dt.Scanner]]:
        """Get a scanner package by ID along with the scanners within it.

        Args:
            scannerPackage: Scanner package to retrieve.

        Returns:
            A tuple of the scanner package and packaged scanners.
        """
        response = self.client.scannerPackages.getScannerPackageId(self._util.getId(scannerPackage))
        return response.package, response.scanners

    def update(self, scannerPackage: ObjOrId[dt.ScannerPackage], *, name: str) -> None:
        """Update an existing scanner package.

        Args:
            scannerPackage: Scanner package to update.
            name: New name for the scanner package.
        """
        self.client.scannerPackages.patchScannerPackageId(
            self._util.getId(scannerPackage),
            dt.PatchScannerPackageBody(name=name),
        )

    def delete(self, scannerPackage: ObjOrId[dt.ScannerPackage], *, deleteScanners: bool = False) -> None:
        """Delete a scanner package by its ID, optionally deleting the packaged scanners.

        Args:
            scannerPackage: Scanner package to delete.
            deleteScanners: Whether to delete the scanners in the package.
                If false, the scanners will be available for use individually.
        """
        self.client.scannerPackages.deleteScannerPackageId(
            self._util.getId(scannerPackage),
            dt.DeleteScannerPackageBody(deleteScanners=deleteScanners),
        )
