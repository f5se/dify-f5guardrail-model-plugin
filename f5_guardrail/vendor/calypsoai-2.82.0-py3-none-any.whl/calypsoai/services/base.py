import inspect
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING, Generic, Protocol, TypeVar, get_type_hints
from uuid import UUID

from calypsoai.clients import CalypsoAIClient

_Id = TypeVar("_Id")

logger = logging.getLogger("calypsoai")


class ObjWithId(Protocol, Generic[_Id]):
    """An object with an `id` attribute."""

    id: _Id


_Obj = TypeVar("_Obj", bound=ObjWithId)

ObjOrId = _Obj | UUID | str


class ServiceUtils:
    """Utilities for services to abstract common operations."""

    @classmethod
    def getId(cls, obj: ObjWithId[_Id] | UUID | str) -> _Id:
        """Given an object with an ID or an ID, return the ID."""  # noqa: DOC201
        return getattr(obj, "id", obj)

    @classmethod
    def getIdOrNone(cls, obj: ObjWithId[_Id] | UUID | str | None) -> _Id | None:
        """Given an object with an ID, an ID or None, return the ID or None."""  # noqa: DOC201
        return getattr(obj, "id", obj)


_namespace = {}


class BaseService:  # noqa: D101
    client: CalypsoAIClient
    _executor: ThreadPoolExecutor
    _util = ServiceUtils

    def __init_subclass__(cls) -> None:
        if cls.__name__ in _namespace:
            logger.warning(f"Found duplicate name {cls.__name__} for service, replacing")  # noqa: G004
        _namespace[cls.__name__] = cls

    def __init__(self, **deps: object) -> None:  # noqa: D107
        for attr, val in deps.items():
            setattr(self, attr, val)
        self._deps = deps

    # Hide from type checking so bad property names raise type errors during linting.
    if not TYPE_CHECKING:

        def __getattr__(self, name: str):  # noqa: ANN204
            serviceClass = None
            for cls in self.__class__.__mro__[:-1]:
                annotations = get_type_hints(cls, localns=_namespace)
                if serviceClass := annotations.get(name):
                    break
            if not serviceClass:
                msg = f"Attribute not found {name}"
                raise AttributeError(msg)
            if not inspect.isclass(serviceClass) or not issubclass(serviceClass, BaseService):
                msg = f"Attribute is not a sub-service {name}"
                raise AttributeError(msg)
            service = serviceClass(**self._deps)
            setattr(self, name, service)
            return service
