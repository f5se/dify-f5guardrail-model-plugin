import json
from collections.abc import Iterator, Sequence
from uuid import UUID

from pydantic import AwareDatetime, constr

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId
from calypsoai.services.providers import ProvidersService

JSONValue = str | dict | list | float | bool


class PromptsService(BaseService):
    """Service to interact with prompts."""

    providers: ProvidersService

    def get(
        self,
        prompt: ObjOrId[dt.Prompt],
    ) -> list[dt.Prompt]:
        """Retrieve a prompt and all parent prompts.

        Args:
            prompt: Prompt to retrieve

        Returns:
            Ordered list of prompts, with the requested prompt at the end.
        """
        response = self.client.prompts.getPromptId(self._util.getId(prompt))
        return [*response.memory, response.prompt]

    def send(
        self,
        input_: JSONValue,
        *,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        project: ObjOrId[dt.Project] | None = None,
        provider: ObjOrId[dt.Provider] | None = None,
        parent: UUID | dt.Prompt | None = None,
        scan: bool = True,
        chat: ObjOrId[dt.Chat] | None = None,
        externalMetadata: dict[str, constr(max_length=255)] | None = None,
    ) -> dt.Prompt:
        r"""Send a prompt, optionally choosing the provider, project, and parent prompt.

        Example:
            ```python
                import os

                cai = CalypsoAI()

                provider = cai.providers.get("gpt-4") or cai.providers.create(
                    "gpt-4",
                    systemProvider="openai-chat",
                    secrets={
                        "apiKey": {
                            "name": "OpenAI API Key",
                            "value": os.environ["OPENAI_KEY"],
                        }
                    },
                )
                cai.providers.enable(provider)

                parent = None
                while data := input("You: "):
                    prompt = cai.prompts.send(
                        input=data,
                        provider=provider,
                        parent=parent,
                    )
                    print(f"\\n{provider.name}: {prompt.result.response}\\n")
                    parent = prompt
            ```

        Args:
            input_: Prompt data to be sent to the provider.
            endpoint: (Deprecated) Endpoint to send the prompt to. If not provided, the global default is used.
            project: Project to send the prompt to. If not provided, the global default is used.
            provider: The provider to send the prompt to. If not provided, the chosen endpoint's default is used.
            parent: Prompt to use as the message history.
            chat: Chat to add the prompt to and use history from.
            scan: Whether or not to run scans on the prompt. Can only be disabled by admins.
            externalMetadata: A json string for users to attach any data to the prompt for their own use.
                For example to tag certain prompts for tracking.
                Limited to 10 items, keys of up to 50 characters and values of up to 255 characters.

        Returns:
            The prompt object created, containing the response and scanning results.

            If prompt recording is disabled, the returned object will only have the result attribute set.
        """
        response = self.client.prompts.post(
            dt.PostPromptsBody(
                input=input_,
                endpoint=self._util.getIdOrNone(endpoint),
                project=self._util.getIdOrNone(project),
                provider=self._util.getIdOrNone(provider),
                parentId=self._util.getIdOrNone(parent),
                skipScanning=not scan,
                externalMetadata=externalMetadata,
            )
            if not chat
            else dt.PostPromptsBodyFromChat(
                input=input_, chatId=self._util.getId(chat), externalMetadata=externalMetadata
            ),
        )
        if not response.id:
            return dt.Prompt(result=response.result)
        prompt = self.client.prompts.getPromptId(response.id).prompt
        messages = {scan.scannerId: scan.message for scan in response.result.scannerResults}
        for scanResult in prompt.result.scannerResults:
            scanResult.message = messages.get(scanResult.scannerId)
        return prompt

    def iterate(
        self,
        *,
        batchSize: int = 100,
        search: str | None = None,
        ascending: bool = False,
        before: AwareDatetime | str | None = None,
        after: AwareDatetime | str | None = None,
        externalMetadata: dict[str, str] | None = None,
        onlyUser: bool = True,
        outcomes: list[dt.PromptOutcome | str] | None = None,
        endpoint: ObjOrId[dt.Endpoint] | Sequence[ObjOrId[dt.Endpoint]] | None = None,
        project: ObjOrId[dt.Project] | Sequence[ObjOrId[dt.Project]] | None = None,
        provider: ObjOrId[dt.Provider] | Sequence[ObjOrId[dt.Provider]] | None = None,
        type_: dt.PromptType | str | list[dt.PromptType | str] | None = None,
        users: list[dt.User] | None = None,
    ) -> Iterator[dt.Prompt]:
        """Iterate through all prompts previously sent.

        Example:
            ```python
            cai = CalypsoAI()

            for prompt in cai.prompts.iterate():
                print("Input: " + prompt.input)
                print("Response: " + prompt.result.response)
            ```

        Args:
            onlyUser: Whether to get prompts belonging to the authenticated user or all users.
                Must be an admin to see other user's prompts.
            batchSize: Size of batches to request
            search: Only return results that match the given text.
            ascending: Whether results should be sorted in ascending order.
            before: Only return results from before this timestamp.
            after: Only return results from after this timestamp.
            externalMetadata: Only return results that match the given external metadata
                              (e.g. {"key": "value"} would return only prompts with a "key" entry matching "value")
            outcomes: Repeated query parameters of outcomes. Filters results by these outcomes.
            endpoint: (Deprecated) Only returns prompts sent to specified endpoints.
            project: Only returns prompts sent to specified projects.
            provider: Only returns prompts sent to specified providers.
            type_: Only returns prompts that match the given types.
            users: Only returns prompts from the given users.

        Yields:
            All available prompts matching the filters.
        """
        cursor = None

        endpointId = (
            [self._util.getId(e) for e in endpoint]
            if isinstance(endpoint, Sequence)
            else self._util.getIdOrNone(endpoint)
        )

        projectId = (
            [self._util.getId(e) for e in project] if isinstance(project, Sequence) else self._util.getIdOrNone(project)
        )

        providerId = (
            [self._util.getId(e) for e in provider]
            if isinstance(provider, Sequence)
            else self._util.getIdOrNone(provider)
        )

        while True:
            response = self.client.prompts.get(
                search=search,
                outcomes=outcomes,
                endpointId=endpointId,
                projectId=projectId,
                providerId=providerId,
                type_=type_ or [],
                before=before,
                after=after,
                externalMetadata=json.dumps(externalMetadata) if externalMetadata else None,
                ascending=ascending,
                cursor=cursor,
                onlyUser=onlyUser,
                limit=batchSize,
                userId=[self._util.getId(u) for u in users] if users else None,
            )
            yield from response.prompts
            if not response.next:
                break
            cursor = response.next

    def broadcast(
        self,
        input_: JSONValue,
        *,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        project: ObjOrId[dt.Project] | None = None,
        providers: Sequence[ObjOrId[dt.Provider]] | None = None,
        parent: UUID | dt.Prompt | None = None,
        scan: bool = True,
        externalMetadata: dict[str, constr(max_length=255)] | None = None,
    ) -> dict[str, dt.Prompt]:
        """Send a prompt to multiple providers in parallel and return the responses.

        Example:
            ```python
            cai = CalypsoAI()
            prompts = cai.prompts.broadcast("What is the meaning of life?")
            for (
                provider,
                prompt,
            ) in prompts.items():
                print(f"{provider}: {prompt.result.response}")
            ```

        Args:
            input_: Prompt data to be sent to the providers.
            endpoint: (Deprecated) Endpoint to send the prompt to. If not provided, the global default is used.
            project: Project to send the prompt to. If not provided, the global default is used.
            providers: The providers to send the prompt to.
                If not provided, all providers enabled for the chosen endpoint will be used.
            parent: Prompt to use as the message history.
            scan: Whether or not to run scans on the prompt. Can only be disabled by admins.
            externalMetadata: A json string for users to attach any data to the prompt for their own use.
                For example to tag certain prompts for tracking.
                Limited to 10 items, keys of up to 50 characters and values of up to 255 characters.

        Returns:
            Provider responses, mapped by the provider names.
        """
        if providers is None:
            providerNames = list(self.providers.enabled(project=project).keys())
        else:
            providerNames = list(
                self._executor.map(
                    lambda p: p.name if isinstance(p, dt.Provider) else self.providers.get(p).name,
                    providers,
                ),
            )

        return dict(
            zip(
                providerNames,
                self._executor.map(
                    lambda p: self.send(
                        input_,
                        endpoint=endpoint,
                        project=project,
                        provider=p,
                        parent=parent,
                        scan=scan,
                        externalMetadata=externalMetadata,
                    ),
                    providerNames,
                ),
                strict=False,
            ),
        )
