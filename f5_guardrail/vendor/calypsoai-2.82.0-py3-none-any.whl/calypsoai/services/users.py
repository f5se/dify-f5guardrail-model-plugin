from collections.abc import Iterator

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId


class UsersService(BaseService):
    """Service to interact with users."""

    def iterate(
        self,
        *,
        group: ObjOrId[dt.Group] | None = None,
        project: ObjOrId[dt.Project] | None = None,
        role: ObjOrId[dt.Role] | None = None,
        search: str | None = None,
        batchSize: int = 50,
    ) -> Iterator[dt.User]:
        """Iterate through all users, filtered by args.

        Args:
            project: Filter users that are members of the given project.
            group: (Deprecated) Filter users that are members of the given group.
            project: Filter users that are members of the given project.
            role: Filter users that are members of the given role.
            search: Filter users that match the given text.
            batchSize: Size of batches to request

        Yields:
            Users matching the given filters.
        """
        group = self._util.getIdOrNone(group)
        project = self._util.getIdOrNone(project)
        role = self._util.getIdOrNone(role)
        response = self.client.users.get(limit=batchSize, search=search, groupId=group, project=project, roleId=role)
        yield from response.users
        while cursor := response.next:
            response = self.client.users.get(
                limit=batchSize,
                search=search,
                groupId=group,
                project=project,
                roleId=role,
                cursor=cursor,
            )
            yield from response.users

    def create(
        self, *, email: str, name: str, roles: list[dt.UserRole] | None = None, sendInvite: bool = True
    ) -> dt.User:
        """Create a new user.

        Args:
            email: The user's email address.
            name: The full name of the user.
            roles: Roles to assign to the user. If not provided, they will be assigned only the basic role.
            sendInvite: Send an invite email to the user.

        Returns:
            The newly created user.
        """
        userId = self.client.users.post(
            body=dt.PostUserBody(email=email, name=name, roles=roles or [], sendInvite=sendInvite)
        ).id
        return self.get(userId)

    def get(self, user: ObjOrId[dt.User]) -> dt.User:
        """Get a user by ID.

        Args:
            user: The user to get.

        Returns:
            The requested user.
        """
        return self.client.users.getUserId(userId=self._util.getId(user)).user

    def delete(self, user: ObjOrId[dt.User]) -> None:
        """Delete a user.

        Args:
            user: The user to delete.
        """
        self.client.users.deleteUserId(userId=self._util.getId(user))

    def update(self, user: ObjOrId[dt.User], *, name: str | None = None, blocked: bool | None = None) -> None:
        """Update a user.

        Only users can change their own name.
        Users created through social account connections (Google, Microsoft), can not change their names.

        Args:
            user: The user to update.
            name: New name for the user.
            blocked: The new blocked status of the user.
        """
        self.client.users.patchUserId(userId=self._util.getId(user), body=dt.PatchUserBody(name=name, blocked=blocked))

    def resendVerificationEmail(self, user: ObjOrId[dt.User]) -> None:
        """Re-sends a users verification email.

        Args:
            user: The user to send re-send the verification email to.
        """
        self.client.users.verification.resend.post(userId=self._util.getId(user))

    def assignRole(self, user: ObjOrId[dt.User], role: ObjOrId[dt.Role]) -> None:
        """Assign a role to a user.

        Args:
            user: User to assign role to.
            role: Role to assign to user.
        """
        self.client.users.roles.postRoleId(
            userId=self._util.getId(user),
            roleId=self._util.getId(role),
        )

    def retractRole(self, user: ObjOrId[dt.User], role: ObjOrId[dt.Role]) -> None:
        """Retract a role from a user.

        Args:
            user: User to retract role from.
            role: Role to retract from user.
        """
        self.client.users.roles.deleteRoleId(
            userId=self._util.getId(user),
            roleId=self._util.getId(role),
        )
