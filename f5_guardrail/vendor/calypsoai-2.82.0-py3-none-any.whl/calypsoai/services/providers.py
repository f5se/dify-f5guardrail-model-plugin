from collections.abc import Iterator
from datetime import datetime
from typing import Any, Literal
from uuid import UUID

import calypsoai.datatypes as dt
from calypsoai.services.base import BaseService, ObjOrId


class ProvidersService(BaseService):
    """Service to interact with providers."""

    def create(
        self,
        name: str,
        systemProvider: ObjOrId[dt.Provider] | None = None,
        *,
        template: dt.APIWorkflowBlock | dt.APIRequestBlock | dt.APIRetryBlock | dict | None = None,
        secrets: dict[str, UUID | str | dt.NewSecret | dict | Any] | None = None,
        inputs: dict[str, Any] | None = None,
        group: ObjOrId[dt.Group] | None = None,
        test: bool = True,
        enable: bool = True,
        maxRequestsPerSecond: int | None = None,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        project: ObjOrId[dt.Project] | None = None,
        default: bool = False,
    ) -> dt.Provider:
        """Create a new provider.

        Example:
            ```python
            import os

            cai = CalypsoAI()

            provider = cai.providers.create(
                "gpt-4",
                systemProvider="openai-chat",
                secrets={
                    "apiKey": {
                        "name": "OpenAI API Key",
                        "value": os.environ["OPENAI_KEY"],
                    }
                },
            )
            print(f"Created provider {provider.name}")
        ```

        Args:
            name: Name for the provider, must be unique.
            systemProvider: System provider to use the template from.
            template: Template to instruct on how to send API requests to the provider.
            secrets: Varialbe names to be available in the provider template mapped to either a secret ID
                or the name and value for a new secret to be created.
            inputs: Varialbe names to be available in the provider template mapped to their value.
            group: (Deprecated) Group to limit the provider to be available to.
                If not provided the provider will be globally accessible.
            test: Whether to test the provider connection before creation.
            enable: Enable the new provider for the default endpoint for the chosen group/global settings.
            maxRequestsPerSecond: Max requests allowed to send to the provider per second(red team specific).
            project: Project to enable the provider if enable is True
            endpoint: (Deprecated) Endpoint to enable the provider if enable is True
            default: Whether the new provider should the default provider. Has no effect if enable is false.

        Returns:
            The newly created provider.
        """
        body = {
            "name": name,
            "inputs": inputs,
            "secrets": secrets,
            "groupId": self._util.getIdOrNone(group),
            "test": test,
            "enable": enable if endpoint is None else None,
            "default": default if endpoint is None else None,
            "maxRequestsPerSecond": maxRequestsPerSecond,
        }
        providerId = self.client.providers.post(
            dt.PostProvidersFromSystemBody(systemProvider=self._util.getId(systemProvider), **body)
            if systemProvider
            else dt.PostProvidersWithTemplateBody(template=template, **body),
        ).id

        if (project or endpoint) is not None and enable:
            self._setEnabled(providerId, enabled=enable, project=project, endpoint=endpoint, default=default)

        return self.client.providers.getProvider(providerId).provider

    def iterate(
        self,
        *,
        batchSize: int = 100,
        addedToProjectId: UUID | str | None = None,
        accessibleToProjectId: UUID | str | None = None,
        enabledForProjectId: UUID | str | None = None,
        availableGlobally: bool | None = None,
        configAt: datetime | str | None = None,
        cursor: str | None = None,
        endpoint: UUID | str | None = None,
        groupId: UUID | str | None = None,
        redTeam: bool = False,
    ) -> Iterator[dt.Provider]:
        """Iterate through all providers, filtered by args.

        Args:
            batchSize: Number of providers returned by each underlying API call. Default is 100
            addedToProjectId: Get providers added to the project
            accessibleToProjectId: Get providers accessible to the project
            enabledForProjectId: Get providers enabled for the project
            availableGlobally: Get providers that are or are not available to all projects.
            configAt: Get the config at a given point in time.
            cursor: Selects page for paginated results. Pass in the next or prev attribute in the response
            endpoint: ID or name of an endpoint to get active providers for.
            groupId: Deprecated
            redTeam: Filter results to only red team providers.

        Yields:
            All providers matching the given filters.
        """
        cursor = None
        while True:
            response = self.client.providers.get(
                cursor=cursor,
                limit=batchSize,
                addedToProjectId=addedToProjectId,
                accessibleToProjectId=accessibleToProjectId,
                enabledForProjectId=enabledForProjectId,
                availableGlobally=availableGlobally,
                configAt=configAt,
                endpoint=endpoint,
                groupId=groupId,
                redTeam=redTeam,
            )
            yield from response.providers

            if not response.next:
                break
            cursor = response.next

    def update(
        self,
        provider: ObjOrId[dt.Provider],
        *,
        name: str | None = None,
        template: dt.APIWorkflowBlock | dt.APIRequestBlock | dt.APIRetryBlock | dict | None = None,
        secrets: dict[str, UUID | str | dt.NewSecret | dict | Any] | None = None,
        inputs: dict[str, Any] | None = None,
        test: bool = False,
        maxRequestsPerSecond: int | None = None,
        requestConcurrencyLimit: dt.RequestConcurrencyLimit | dict | Literal[False] | int | None = None,
    ) -> None:
        """Update an existing provider.

        Args:
            provider: Provider to update.
            name: New name for the provider, must be unique.
            template: Template to instruct on how to send API requests to the provider.
            secrets: Varialbe names to be available in the provider template mapped to either a secret ID
                or the name and value for a new secret to be created.
            inputs: Varialbe names to be available in the provider template mapped to their value.
            test: Whether to test the provider connection before updating.
            maxRequestsPerSecond: Max requests allowed to send to the provider per second(red team specific).
            requestConcurrencyLimit: Request concurrency limit for campaign run attacks.
                If an integer is provided, it will allow at most that number of requests to be
                opened against the provider at once. Set to False to remove any limit.

        """
        self.client.providers.patchProvider(
            self._util.getId(provider),
            dt.PatchProviderBody(
                template=template,
                name=name,
                inputs=inputs,
                secrets=secrets,
                test=test,
                maxRequestsPerSecond=maxRequestsPerSecond,
                requestConcurrencyLimit=requestConcurrencyLimit
                if not isinstance(requestConcurrencyLimit, int)
                else dt.RequestConcurrencyLimit(requests=requestConcurrencyLimit),
            ),
        )

    def getSystem(self) -> dict[str, dt.Provider]:
        """Get all system providers that can be used to create new providers.

        Returns:
            All available system providers, mapped by their name.
        """
        return {p.name: p for p in self.client.providers.system.get().providers}

    def get(self, provider: ObjOrId[dt.Provider]) -> dt.Provider:
        """Get a provider by ID or name.

        Args:
            provider: Provider to retrieve.

        Returns:
            The chosen provider.
        """
        return self.client.providers.getProvider(self._util.getId(provider)).provider

    def enabled(
        self,
        *,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        project: ObjOrId[dt.Project] | None = None,
    ) -> dict[str, dt.Provider]:
        """Get all providers currently enabled for the chosen project.

        Args:
            project: Project to get providers for. If not provided, the default global project will be used.
            endpoint: (Deprecated) Endpoint to get providers for.
                If not provided, the default global endpoint will be used.

        Returns:
            All enabled providers for the chosen project, mapped by name.
        """
        if project is None and endpoint is None:
            project = self.client.project.get().project.id

        providers = self.client.providers.get(
            enabledForProjectId=self._util.getIdOrNone(project),
            endpoint=self._util.getIdOrNone(endpoint),
        ).providers
        return {provider.name: provider for provider in providers}

    def getAllByName(
        self,
        *,
        project: ObjOrId[dt.Group] | None = None,
        group: ObjOrId[dt.Group] | None = None,
    ) -> dict[str, dt.Provider]:
        """Get all providers available for the chosen project.

        Args:
            project: Project to get providers for. If not provided, global providers will be retrieved.
            group: (Deprecated) Group to get providers for. If not provided, global providers will be retrieved.

        Returns:
            All available providers for the chosen group, mapped by name.
        """
        providers = self.client.providers.get(
            groupId=self._util.getIdOrNone(group),
            accessibleToProjectId=self._util.getIdOrNone(project),
        ).providers
        return {provider.name: provider for provider in providers}

    def enable(
        self,
        provider: ObjOrId[dt.Provider],
        *,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        project: ObjOrId[dt.Project] | None = None,
        default: bool = False,
    ) -> None:
        """Enable a provider for the chosen project, allowing prompts to be sent to it.

        Args:
            provider: Provider to enable.
            project: Project to enable the provider for. If not provided, the default project is used.
            endpoint: (Deprecated) Endpoint to enable the provider for. If not provided, the default endpoint is used.
            default: Whether the provider should be made the default for the chosen endpoint.
        """
        self._setEnabled(provider, enabled=True, project=project, endpoint=endpoint, default=default)

    def disable(
        self,
        provider: ObjOrId[dt.Provider],
        *,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        project: ObjOrId[dt.Project] | None = None,
    ) -> None:
        """Disable a provider for the chosen project.

        Args:
            provider: Provider to disable.
            project: Project to disable the provider for. If not provided, the default project is used.
            endpoint: (Deprecated) Endpoint to disable the provider for. If not provided, the default endpoint is used.
        """
        self._setEnabled(provider, enabled=False, project=project, endpoint=endpoint)

    def delete(self, provider: ObjOrId[dt.Provider]) -> None:
        """Delete a provider by ID or name.

        Args:
            provider: The provider to delete.
        """
        if isinstance(provider, dt.Provider):
            provider = provider.id
        self.client.providers.deleteProvider(provider)

    def _setEnabled(
        self,
        provider: ObjOrId[dt.Provider],
        *,
        enabled: bool,
        endpoint: ObjOrId[dt.Endpoint] | None = None,
        project: ObjOrId[dt.Project] | None = None,
        default: bool = False,
    ) -> None:
        if isinstance(provider, dt.Provider):
            provider = provider.id

        project = self._util.getIdOrNone(project or endpoint)

        projectData = self.client.projects.getProject(project).project if project else self.client.project.get().project
        provider = self.client.providers.getProvider(self._util.getId(provider)).provider.id
        self.client.endpoints.patchEndpoint(
            projectData.id,
            dt.PatchEndpointBody(
                config=dt.ProjectConfig(
                    providers=[dt.ProjectConfigProvider(id=provider, enabled=enabled, default=default)],
                ),
            ),
        )
