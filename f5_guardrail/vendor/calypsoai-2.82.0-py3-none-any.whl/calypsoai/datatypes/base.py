from pydantic import BaseModel


class UploadFile(BaseModel):
    filename: str
    data: bytes
    contentType: str
