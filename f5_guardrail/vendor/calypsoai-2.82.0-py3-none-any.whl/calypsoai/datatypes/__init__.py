from datetime import datetime
from enum import Enum
from uuid import UUID

from calypsoai.datatypes.base import *  # noqa: F403
from calypsoai.datatypes.generated import *  # noqa: F403
from calypsoai.datatypes.generated import GenAIScannerConfig, GenAIScannerResult

ScannerVersionQuery = UUID | datetime | str


class CustomScannerConfig(GenAIScannerConfig): ...


class CustomScannerResult(GenAIScannerResult): ...


class PermissionName(str, Enum):
    ORG_OWNER = "org_owner"
    ROLES = "roles"
    ORG_ADMIN = "org_admin"
    RED_TEAM = "red_team"
    ORG_MEMBER = "org_member"
    ORGANIZATION = "organization"
    MANAGE_ORGANIZATION = "manage_organization"
    TRANSFER_OWNERSHIP = "transfer_ownership"
    TOGGLE_MFA = "toggle_mfa"
    MANAGE_DATA_RETENTION = "manage_data_retention"
    TOGGLE_PROMPT_HISTORY_LOGGING = "toggle_prompt_history_logging"
    TOGGLE_PROMPT_HISTORY_PURGE = "toggle_prompt_history_purge"
    MANAGE_BRANDING = "manage_branding"
    UPDATE_ORGANIZATION_NAME = "update_organization_name"
    UPDATE_PRODUCT_NAME = "update_product_name"
    UPDATE_LOGO = "update_logo"
    UPDATE_FAVICON = "update_favicon"
    UPDATE_SUPPORT_EMAIL = "update_support_email"
    SCANNERS = "scanners"
    MANAGE_SCANNERS = "manage_scanners"
    MANAGE_SCANNER_PACKAGES = "manage_scanner_packages"
    CREATE_SCANNER_PACKAGE = "create_scanner_package"
    UPDATE_SCANNER_PACKAGE = "update_scanner_package"
    SHARE_SCANNER_PACKAGE = "share_scanner_package"
    DELETE_SCANNER_PACKAGE = "delete_scanner_package"
    USE_CAI_SCANNERS = "use_cai_scanners"
    TOGGLE_CAI_SCANNER = "toggle_cai_scanner"
    TOGGLE_CAI_SCANNER_MODE = "toggle_cai_scanner_mode"
    UPDATE_CAI_SCANNER_RESPONSE = "update_cai_scanner_response"
    ENFORCE_CAI_SCANNER_USE = "enforce_cai_scanner_use"
    UPDATE_CAI_SCANNER = "update_cai_scanner"
    USE_CUSTOM_SCANNERS = "use_custom_scanners"
    PROVIDERS = "providers"
    MANAGE_PROVIDERS = "manage_providers"
    CREATE_PROVIDER = "create_provider"
    UPDATE_PROVIDER = "update_provider"
    DELETE_PROVIDER = "delete_provider"
    CREATE_SECRET = "create_secret"
    UPDATE_SECRET = "update_secret"
    PROJECTS = "projects"
    MANAGE_PROJECTS = "manage_projects"
    CREATE_PROJECT = "create_project"
    USE_PROJECT = "use_project"
    UPDATE_PROJECT = "update_project"
    DELETE_PROJECT = "delete_project"
    TOGGLE_PROVIDER = "toggle_provider"
    UPDATE_DEFAULT_PROVIDER = "update_default_provider"
    CREATE_PROMPT_TEMPLATE = "create_prompt_template"
    MANAGE_API_TOKENS = "manage_api_tokens"
    CREATE_API_TOKEN = "create_api_token"
    DELETE_API_TOKEN = "delete_api_token"
    PROJECT_ANALYTICS = "project_analytics"
    READ_METRICS = "read_metrics"
    READ_PROMPT = "read_prompt"
    USERS = "users"
    MANAGE_USERS = "manage_users"
    CREATE_USER = "create_user"
    UPDATE_USER = "update_user"
    DELETE_USER = "delete_user"
    BLOCK_USER = "block_user"
    UNBLOCK_USER = "unblock_user"
    RESET_USER_MFA = "reset_user_mfa"
