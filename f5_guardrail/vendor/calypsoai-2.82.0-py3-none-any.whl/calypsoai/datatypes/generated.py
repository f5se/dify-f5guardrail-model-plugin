from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal
from uuid import UUID

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    PositiveInt,
    confloat,
    conint,
    constr,
)

from calypsoai.datatypes.base import UploadFile


class AWSAuth(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    accessKey: str | None = Field(default=None, title="Accesskey")
    region: str | None = Field(default=None, title="Region")
    secretKey: str | None = Field(default=None, title="Secretkey")
    service: str | None = Field(default=None, title="Service")
    token: str | None = Field(default=None, title="Token")


class AgentFingerprintStatus(str, Enum):
    IN_PROGRESS = "in_progress"
    FAILED = "failed"
    COMPLETED = "completed"


class AgentSessionSortBy(str, Enum):
    UPDATED_AT = "updated_at"
    CREATED_AT = "created_at"


class AttackRunCancelledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["cancelled"] = Field(default="cancelled", title="Event")


class AttackRunCancellingEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["cancelling"] = Field(default="cancelling", title="Event")


class AttackRunCompletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["completed"] = Field(default="completed", title="Event")


class AttackRunFailedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["failed"] = Field(default="failed", title="Event")
    message: str | None = Field(default=None, title="Message")


class AttackRunQueuedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["queued"] = Field(default="queued", title="Event")


class AttackRunScheduleErrorEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["schedule_error"] = Field(default="schedule_error", title="Event")


class AttackRunScheduledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["scheduled"] = Field(default="scheduled", title="Event")
    scheduledStartTime: datetime | None = Field(default=None, title="Scheduledstarttime")


class AttackRunStartedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["started"] = Field(default="started", title="Event")


class AttackTechnique(str, Enum):
    STATIC_CONTENT = "static_content"
    DYNAMIC_CONTENT = "dynamic_content"
    OPERATIONAL = "operational"
    CUSTOM = "custom"


class AuditEventType(str, Enum):
    API_TOKEN_CREATED = "api-token-created"
    API_TOKEN_REVOKED = "api-token-revoked"
    AGENT_SESSION_CREATED = "agent-session-created"
    AGENT_SESSION_FINGERPRINTS_REQUESTED = "agent-session-fingerprints-requested"
    BRANDING_CREATED = "branding-created"
    BRANDING_UPDATED = "branding-updated"
    CAMPAIGN_CREATED = "campaign-created"
    CAMPAIGN_UPDATED = "campaign-updated"
    CAMPAIGN_DELETED = "campaign-deleted"
    CAMPAIGN_RUN_CREATED = "campaign-run-created"
    CAMPAIGN_RUN_UPDATED = "campaign-run-updated"
    CAMPAIGN_RUN_DELETED = "campaign-run-deleted"
    CAMPAIGN_SCHEDULE_CREATED = "campaign-schedule-created"
    CAMPAIGN_SCHEDULE_UPDATED = "campaign-schedule-updated"
    CAMPAIGN_SCHEDULE_DELETED = "campaign-schedule-deleted"
    CHATBOT_CREATED = "chatbot-created"
    CHATBOT_UPDATED = "chatbot-updated"
    CHATBOT_PROJECT_CREATED = "chatbot-project-created"
    CHATBOT_PROJECT_UPDATED = "chatbot-project-updated"
    ENTITLEMENT_GROUP_CREATED = "entitlement-group-created"
    ENTITLEMENT_GROUP_UPDATED = "entitlement-group-updated"
    ENTITLEMENT_GROUP_DELETED = "entitlement-group-deleted"
    ENTITLEMENT_OVERRIDE_CREATED = "entitlement-override-created"
    ENTITLEMENT_OVERRIDE_DELETED = "entitlement-override-deleted"
    ENTITLEMENT_USAGE_CREATED = "entitlement-usage-created"
    ENTITLEMENT_USAGE_DELETED = "entitlement-usage-deleted"
    FILE_CREATED = "file-created"
    PROJECT_CREATED = "project-created"
    PROJECT_DELETED = "project-deleted"
    PROJECT_UNDELETED = "project-undeleted"
    PROJECT_UPDATED = "project-updated"
    PROJECT_DEFAULT_PROVIDER_UPDATED = "project-default-provider-updated"
    PROJECT_PROVIDER_ROUTING_CREATED = "project-provider-routing-created"
    PROJECT_PROVIDER_ROUTING_UPDATED = "project-provider-routing-updated"
    PROJECT_PROVIDER_ADDED = "project-provider-added"
    PROJECT_PROVIDER_REMOVED = "project-provider-removed"
    PROJECT_SCANNER_ADDED = "project-scanner-added"
    PROJECT_SCANNER_REMOVED = "project-scanner-removed"
    PROJECT_SCANNER_PACKAGE_ADDED = "project-scanner-package-added"
    PROJECT_SCANNER_PACKAGE_REMOVED = "project-scanner-package-removed"
    PROJECT_MEMBER_ADDED = "project-member-added"
    PROJECT_MEMBER_REMOVED = "project-member-removed"
    ORGANIZATION_CREATED = "organization-created"
    ORGANIZATION_UPDATED = "organization-updated"
    ORGANIZATION_PROMPT_RECORDING_ENABLED = "organization-prompt-recording-enabled"
    ORGANIZATION_PROMPT_RECORDING_DISABLED = "organization-prompt-recording-disabled"
    ORGANIZATION_DISABLED = "organization-disabled"
    ORGANIZATION_ENABLED = "organization-enabled"
    ORGANIZATION_DATA_DELETED = "organization-data-deleted"
    ORGANIZATION_ENTITLEMENTS_UPDATED = "organization-entitlements-updated"
    PROVIDER_CREATED = "provider-created"
    PROVIDER_DELETED = "provider-deleted"
    PROVIDER_UNDELETED = "provider-undeleted"
    PROVIDER_UPDATED = "provider-updated"
    PROVIDER_ENABLED = "provider-enabled"
    PROVIDER_DISABLED = "provider-disabled"
    PROVIDER_AVAILABILITY_UPDATED = "provider-availability-updated"
    SCANNER_CREATED = "scanner-created"
    SCANNER_UPDATED = "scanner-updated"
    SCANNER_DELETED = "scanner-deleted"
    SCANNER_UNDELETED = "scanner-undeleted"
    SCANNER_PUBLISHED = "scanner-published"
    SCANNER_UNPUBLISHED = "scanner-unpublished"
    SCANNER_ENABLED = "scanner-enabled"
    SCANNER_DISABLED = "scanner-disabled"
    SCANNER_AVAILABILITY_UPDATED = "scanner-availability-updated"
    SCANNER_SHARED = "scanner-shared"
    SCANNER_VERSION_PUBLISHED = "scanner-version-published"
    SHARE_SCANNER_EMAIL_SENT = "share-scanner-email-sent"
    SCANNER_PACKAGE_CREATED = "scanner-package-created"
    SCANNER_PACKAGE_UPDATED = "scanner-package-updated"
    SCANNER_PACKAGE_DELETED = "scanner-package-deleted"
    SCANNER_PACKAGE_UNDELETED = "scanner-package-undeleted"
    SCANNER_PACKAGE_ENABLED = "scanner-package-enabled"
    SCANNER_PACKAGE_DISABLED = "scanner-package-disabled"
    SCANNER_PACKAGE_AVAILABILITY_UPDATED = "scanner-package-availability-updated"
    SCANNER_TEMPLATE_CREATED = "scanner-template-created"
    SCANNER_TEMPLATE_UPDATED = "scanner-template-updated"
    SECRET_CREATED = "secret-created"
    SECRET_UPDATED = "secret-updated"
    SECRET_DELETED = "secret-deleted"
    TASK_CREATED = "task-created"
    TASK_UPDATED = "task-updated"
    TASK_CANCELED = "task-canceled"
    PROVIDER_TEST = "provider-test"
    USER_AUTH_METHOD_DELETED = "user-auth-method-deleted"
    USER_CREATED = "user-created"
    USER_UPDATED = "user-updated"
    USER_DELETED = "user-deleted"
    USER_VERIFIED = "user-verified"
    USER_BLOCKED = "user-blocked"
    USER_UNBLOCKED = "user-unblocked"
    USER_ROLES_UPDATED = "user-roles-updated"
    USER_ROLE_GRANTED = "user-role-granted"
    USER_ROLE_RETRACTED = "user-role-retracted"
    ROLE_CREATED = "role-created"
    ROLE_UPDATED = "role-updated"
    ROLE_PERMISSIONS_ADDED = "role-permissions-added"
    ROLE_PERMISSIONS_REMOVED = "role-permissions-removed"
    ROLE_DELETED = "role-deleted"
    LICENSE_CREATED = "license-created"
    OAUTH_CLIENT_CREATED = "oauth_client_created"
    OAUTH_CLIENT_DELETED = "oauth_client_deleted"
    OAUTH_CLIENT_UPDATED = "oauth_client_updated"
    REMEDIATION_CREATED = "remediation-created"
    REMEDIATION_DEPLOYED = "remediation-deployed"
    REMEDIATION_REJECTED = "remediation-rejected"


class AuditTermScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    literals: list[str] = Field(default=[], title="Literals")
    type: Literal["audit_term"] = Field(default="audit_term", title="Type")
    words: list[str] | None = Field(default=None, title="Words")
    """
    Words to check for in the prompt. Case insensitive regular expressions
    """


class AuditTermScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    matches: dict[str, list[list]] | None = Field(default=None, title="Matches")
    type: Literal["audit_term"] = Field(default="audit_term", title="Type")


class BlacklistScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    literals: list[str] = Field(default=[], title="Literals")
    type: Literal["blacklist"] = Field(default="blacklist", title="Type")
    words: list[str] | None = Field(default=None, title="Words")
    """
    Words to check for in the prompt. Case insensitive regular expressions
    """


class BlacklistScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    matches: dict[str, list[list]] | None = Field(default=None, title="Matches")
    type: Literal["blacklist"] = Field(default="blacklist", title="Type")


class Purpose(str, Enum):
    CUSTOM_ATTACKS = "custom_attacks"
    DATASETS = "datasets"


class BodyPostFiles(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    file: UploadFile | None = Field(default=None, title="File")
    purposes: list[Purpose] | None = Field(default=None, title="Purposes")


class BodyPostScannersImport(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    file: UploadFile | None = Field(default=None, title="File")
    ids: list[UUID] | None = Field(default=None, title="Ids")


class BrandingConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    disablePoweredByCai: bool | None = Field(default=None, title="Disablepoweredbycai")
    """
    Deprecated
    """
    hasCustomLogo: bool = Field(default=False, title="Hascustomlogo")
    """
    Does the organization have a custom logo
    """
    productName: str | None = Field(default=None, title="Productname")
    """
    Deprecated
    """
    supportEmail: str | None = Field(default=None, title="Supportemail")
    """
    The support email shown in the UI
    """


class CampaignRunErrorType(str, Enum):
    API_TOKEN = "api_token"
    PERMISSION = "permission"
    NOT_FOUND = "not_found"
    VALIDATION = "validation"
    RATE_LIMIT = "rate_limit"
    CLIENT_ERROR = "client_error"
    SERVER_ERROR = "server_error"
    TIMEOUT = "timeout"
    SERVICE_UNAVAILABLE = "service_unavailable"
    UNKNOWN = "unknown"
    FAILURE_LIMIT_REACHED = "failure_limit_reached"
    BAD_PROVIDER_CONFIGURATION = "bad_provider_configuration"


class CampaignRunProviderErrors(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    errorCount: int | None = Field(default=None, title="Errorcount")
    providerFailed: bool | None = Field(default=None, title="Providerfailed")
    providerName: str | None = Field(default=None, title="Providername")
    totalPrompts: int | None = Field(default=None, title="Totalprompts")


class CampaignRunRemediation(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    available: bool = Field(default=False, title="Available")
    id: UUID | None = Field(default=None, title="Id")


class CampaignRunRemediationSettings(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    autorun: bool = Field(default=False, title="Autorun")
    """
    Run remediation once available.
    """


class CampaignRunScoreRating(str, Enum):
    CRITICAL = "critical"
    WARNING = "warning"
    GOOD = "good"
    IDEAL = "ideal"


class CampaignRunSearchSortBy(str, Enum):
    NAME = "name"
    CREATED_AT = "created_at"
    START_AT = "start_at"
    SCORE = "score"
    AVERAGE_PERFORMANCE = "average_performance"


class CampaignRunStatus(str, Enum):
    SCHEDULED = "scheduled"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    ERROR = "error"
    CANCELLING = "cancelling"
    CANCELLED = "cancelled"
    SCHEDULE_ERROR = "schedule_error"


class CampaignScheduleFrequency(str, Enum):
    WEEKS = "weeks"
    DAYS = "days"


class CampaignSortBy(str, Enum):
    NAME = "name"
    CREATED_AT = "created_at"
    LAST_RUN = "last_run"
    NUM_OF_RUNS = "num_of_runs"


class ChatAccess(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    org: bool | None = Field(default=None, title="Org")
    """
    If True, is accessible to anyone in the same org as the user that created the chat
    """
    public: UUID | None = Field(default=None, title="Public")
    """
    If is not None, Chat is publicly accessible to anyone with the access ID
    """
    users: list[str] | None = Field(default=None, title="Users")
    """
    list of users ID of users with access to the chat
    """


class ChatbotType(str, Enum):
    TEAMS = "teams"
    SLACK = "slack"


class CustomAttack(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    fileId: UUID | None = Field(default=None, title="Fileid")
    name: str | None = Field(default=None, title="Name")
    technique: Literal["custom"] = Field(default="custom", title="Technique")


class CustomIntentGenerationInput(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    intent: str | None = Field(default=None, title="Intent")
    type: Literal["custom_intent"] = Field(default="custom_intent", title="Type")


class CustomIntentGenerationOutput(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    intent: str | None = Field(default=None, title="Intent")


class Dataset(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    createdBy: str | None = Field(default=None, title="Createdby")
    fileId: UUID | None = Field(default=None, title="Fileid")
    filename: str | None = Field(default=None, title="Filename")
    id: UUID | None = Field(default=None, title="Id")
    name: str | None = Field(default=None, title="Name")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")


class DatasetScores(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    accuracy: float | None = Field(default=None, title="Accuracy")
    f1Score: float | None = Field(default=None, title="F1Score")
    falseNegative: int | None = Field(default=None, title="Falsenegative")
    falsePositive: int | None = Field(default=None, title="Falsepositive")
    trueNegative: int | None = Field(default=None, title="Truenegative")
    truePositive: int | None = Field(default=None, title="Truepositive")


class DeleteAuthRoleBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    reassignToRoleId: UUID | str | None = Field(default=None, title="Reassigntoroleid")


class DeleteScannerPackageBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    deleteScanners: bool = Field(default=False, title="Deletescanners")
    """
    Whether to delete the guardrails in the package.
    If false, the guardrails will be available for use individually.
    """


class DemographicScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    type: Literal["demographic"] = Field(default="demographic", title="Type")


class DemographicScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    age: dict[str, list[list]] = Field(default={}, title="Age")
    culturalAndSocial: dict[str, list[list]] = Field(default={}, title="Culturalandsocial")
    disability: dict[str, list[list]] = Field(default={}, title="Disability")
    ethnicity: dict[str, list[list]] = Field(default={}, title="Ethnicity")
    genderAndSex: dict[str, list[list]] = Field(default={}, title="Genderandsex")
    generation: dict[str, list[list]] = Field(default={}, title="Generation")
    nationality: dict[str, list[list]] = Field(default={}, title="Nationality")
    politics: dict[str, list[list]] = Field(default={}, title="Politics")
    religion: dict[str, list[list]] = Field(default={}, title="Religion")
    sexualOrientation: dict[str, list[list]] = Field(default={}, title="Sexualorientation")
    type: Literal["demographic"] = Field(default="demographic", title="Type")


class DuplicateScannerRequest(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    duplicate: UUID | None = Field(default=None, title="Duplicate")
    """
    Duplicate the guardrail with the given ID.
    """


class Vector(str, Enum):
    CRESCENDO = "crescendo"
    FRAME = "frame"
    TROLLEY = "trolley"


class Vector1(str, Enum):
    DAN = "dan"
    FICTIONAL_CONTEXT_CHANGE = "fictional_context_change"
    CONDITIONAL_CONTEXT_CHANGE = "conditional_context_change"
    CRESCENDO = "crescendo"
    MATH_PROMPT = "math_prompt"
    FLIP = "flip"
    PERSUASIVE_ADVERSARIAL = "persuasive_adversarial"
    PAYLOAD_SPLITTING = "payload_splitting"
    REFUSAL_SUPPRESSION = "refusal_suppression"
    SCENARIO_NESTING = "scenario_nesting"
    STYLE_INJECTION = "style_injection"
    WORD_GAME = "word_game"
    FALLACY_FAILURE = "fallacy_failure"
    ADVERSARIAL_METAPHOR = "adversarial_metaphor"
    PERSONA_BULLYING = "persona_bullying"
    INVASIVE_CONTEXT_ENGINEERING = "invasive_context_engineering"
    SUGAR_COATED_POISON = "sugar_coated_poison"
    DEVELOPER_ROLE_ATTACK = "developer_role_attack"


class ErrorScanResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    msg: str | None = Field(default=None, title="Msg")
    type: Literal["error"] = Field(default="error", title="Type")


class ExportScannersBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    packageIds: list[UUID] | None = Field(default=None, title="Packageids")
    """
    IDs of guardrail packages to export.
    """
    scannerIds: list[UUID] | None = Field(default=None, title="Scannerids")
    """
    IDs of guardrails to export.
    """


class FilePurpose(str, Enum):
    CUSTOM_ATTACKS = "custom_attacks"
    DATASETS = "datasets"
    DATASET_RUNS = "dataset_runs"
    REMEDIATION_RESULT = "remediation_result"


class FingerprintInternalError(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    message: str | None = Field(default=None, title="Message")
    type: Literal["internal"] = Field(default="internal", title="Type")


class FingerprintProviderError(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    message: str | None = Field(default=None, title="Message")
    providerId: UUID | None = Field(default=None, title="Providerid")
    statusCode: int | None = Field(default=None, title="Statuscode")
    type: Literal["provider"] = Field(default="provider", title="Type")


class FingerprintUnsupportedError(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    message: str | None = Field(default=None, title="Message")
    type: Literal["incompatible_format"] = Field(default="incompatible_format", title="Type")


class FlaggedSpan(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    span: list | None = Field(default=None, max_length=2, min_length=2, title="Span")
    versionId: UUID | None = Field(default=None, title="Versionid")


class ScanContext(str, Enum):
    """
    Describes the context that is provided to the scanner
    individual: Scan only the latest message
    directional: Scan all messages in the conversation in the same direction as the latest message
    """

    INDIVIDUAL = "individual"
    DIRECTIONAL = "directional"


class Type(str, Enum):
    GENAI = "genai"
    CUSTOM = "custom"


class GenAIScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    input: str = Field(default="", title="Input")
    scanContext: ScanContext | str = Field(default="directional", title="Scancontext")
    """
    Describes the context that is provided to the scanner
    individual: Scan only the latest message
    directional: Scan all messages in the conversation in the same direction as the latest message
    """
    type: Literal["custom", "genai"] = Field(..., title="Type")


class GenAIScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    type: Literal["custom", "genai"] = Field(..., title="Type")


class GetBrandingResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    config: BrandingConfig | None = None


class GetDatasetResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    dataset: Dataset | None = None


class Group(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    id: UUID | None = Field(default=None, title="Id")
    memberCount: int | None = Field(default=None, title="Membercount")
    name: str | None = Field(default=None, title="Name")


class HTTPMethod(str, Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"


class InternalScannerSource(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    type: Literal["internal"] = Field(default="internal", title="Type")


class InvalidAttack(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    technique: str | None = Field(default=None, title="Technique")


class KeywordScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    type: Literal["keyword"] = Field(default="keyword", title="Type")
    words: list[str] | None = Field(default=None, title="Words")
    """
    Words to check for in the prompt or response. Case insensitive. Empty strings will be removed.
    """


class KeywordScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    matches: dict[str, list[list]] | None = Field(default=None, title="Matches")
    type: Literal["keyword"] = Field(default="keyword", title="Type")


class LegacyUser(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    id: str | None = Field(default=None, title="Id")
    org: str | None = Field(default=None, title="Org")


class LegalDocumentClasses(str, Enum):
    CONTRACTS = "contracts"
    LAW = "law"
    NDA = "nda"
    TOS_EULA = "tos_eula"
    NON_LEGAL = "non_legal"


class LegalScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    scores: dict[str, confloat(ge=0.0, le=100.0)] | None = Field(default=None, title="Scores")
    type: Literal["legal"] = Field(default="legal", title="Type")


class LoadStats(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    estimatedProcessingTime: float = Field(default=0, title="Estimatedprocessingtime")
    queued: int = Field(default=0, title="Queued")
    sizeQueued: int = Field(default=0, title="Sizequeued")


class NamedEntityScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    type: Literal["named_entity"] = Field(default="named_entity", title="Type")


class NamedEntityScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    entities: list[dict[str, Any]] | None = Field(default=None, title="Entities")
    type: Literal["named_entity"] = Field(default="named_entity", title="Type")


class NewSecret(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: str | None = Field(default=None, title="Name")
    value: str | None = Field(default=None, title="Value")


class NotRunScanResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    msg: str | None = Field(default=None, title="Msg")
    type: Literal["N/A"] = Field(default="N/A", title="Type")


class OCIAuth(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    keyId: str | None = Field(default=None, title="Keyid")
    passphrase: str | None = Field(default=None, title="Passphrase")
    privateKeyPem: str | None = Field(default=None, title="Privatekeypem")


class OperationalAttackVector(str, Enum):
    TLS = "tls"
    FUZZING = "fuzzing"


class PIIDetectors(str, Enum):
    ADDRESS = "address"
    DATE_OF_BIRTH = "date_of_birth"
    EMAIL = "email"
    CREDIT_CARD = "credit_card"
    PHONE = "phone"
    SOCIAL_SECURITY_NUMBER = "social_security_number"
    URL = "url"
    SPACY_NAME = "spacy_name"
    UNKNOWN = "unknown"
    IP_ADDRESS = "ip_address"
    IBAN = "iban"


class PIIScanSensitivity(str, Enum):
    STANDARD = "standard"
    HIGH = "high"


class PIIScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    nonFlagging: list[PIIDetectors] = Field(default=[], title="Nonflagging")
    scanAddresses: bool = Field(default=False, title="Scanaddresses")
    sensitivity: PIIScanSensitivity | str = "standard"
    type: Literal["pii_detection"] = Field(default="pii_detection", title="Type")


class PIIScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    detections: dict[str, list[list]] | None = Field(default=None, title="Detections")
    type: Literal["pii_detection"] = Field(default="pii_detection", title="Type")


class PatchAuthRoleBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    New name of the role. Requires case insensitive uniqueness.
    """
    permissions: list[str] | None = Field(default=None, title="Permissions")
    """
    New set of the permissions assigned by the role. Replaces existing set.

    To add/remove roles use PATCH/DELETE `/auth/roles/{roleId}/permissions`
    """


class PatchAuthRolePermissionsBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    permissions: list[str] | None = Field(default=None, title="Permissions")
    """
    Permissions to add to the existing role permission set.
    """


class PatchBrandingBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    config: BrandingConfig | None = None


class Attacks(str, Enum):
    STATIC_CONTENT = "static_content"
    OPERATIONAL = "operational"


class PatchCampaignRunBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: str | None = Field(default=None, title="Name")
    preserve: bool | None = Field(default=None, title="Preserve")
    """
    If true, the campaign run and its associated data will be preserved from deletion.
    """
    remediationSettings: CampaignRunRemediationSettings | None = None
    """
    Determines if the campaign run will automatically create a remediation for vulnerabilities found
    """
    startAt: datetime | None = Field(default=None, title="Startat")
    """
    New time to start the campaign run
    """
    status: str | None = Field(default=None, title="Status")
    """
    If received, the campaign run will be prevented from running in the future.
    """


class PatchChatBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    orgAccess: bool | None = Field(default=None, title="Orgaccess")
    """
    Allow the chat to be access by anyone in the org
    """
    publicAccess: bool | None = Field(default=None, title="Publicaccess")
    """
    Make the chat publicly shareable
    """
    removeUserAccess: list[str] | None = Field(default=None, title="Removeuseraccess")
    """
    Remove a users access if they have been given user_access
    """
    starred: bool | None = Field(default=None, title="Starred")
    """
    Use starred to bookmark chat
    """
    userAccess: list[str] | None = Field(default=None, title="Useraccess")
    """
    Give specific users access by adding their user ID to the list
    """


class PatchGroupBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    New name for the given group. Must be unique in the org.
    """


class PatchGroupUserBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    admin: bool | None = Field(default=None, title="Admin")
    """
    Whether the user should be an admin of the given group.
    """


class PatchLicenseBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    license: constr(min_length=1) | None = Field(default=None, title="License")
    """
    The license to be applied to the system
    """


class PatchOrgBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    applicationUrl: str | None = Field(default=None, title="Applicationurl")
    name: str | None = Field(default=None, title="Name")
    requireMfa: bool | None = Field(default=None, title="Requiremfa")


class PatchOrganizationPreferencesBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    preferences: dict[str, Any] | None = Field(default=None, title="Preferences")
    """
    Organization preferences to update
    """


class PatchProjectMemberBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    admin: bool | None = Field(default=None, title="Admin")
    """
    Whether the user should be an admin of the given group.
    """


class PatchPromptBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    preserve: bool | None = Field(default=None, title="Preserve")
    """
    Whether or not to preserve this prompt when deleting prompts periodically
    """


class PatchPromptTemplateBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    New name for the prompt template.
    """


class PatchProviderAccessBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    global_: bool | None = Field(default=None, alias="global", title="Global")
    """
    If provider should be available to all projects, set to True
    """
    projectIds: list[UUID] | None = Field(default=None, title="Projectids")
    """
    projects IDs of projects that should be available to use the provider
    """


class PatchScanBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    preserve: bool | None = Field(default=None, title="Preserve")
    """
    Whether or not to preserve this scan request when deleting scan requests periodically
    """


class PatchScannerAccessBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    global_: bool | None = Field(default=None, alias="global", title="Global")
    """
    If guardrail should be available to all projects, set to True
    """
    projectIds: list[UUID] | None = Field(default=None, title="Projectids")
    """
    Projects IDs of projects that should be available to use the guardrail
    """


class PatchScannerPackageAccessBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    global_: bool | None = Field(default=None, alias="global", title="Global")
    """
    If package should be available to all projects, set to True
    """
    projectIds: list[UUID] | None = Field(default=None, title="Projectids")
    """
    IDs of projects that should be available to use the package
    """


class PatchScannerPackageBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: constr(min_length=1, max_length=70) | None = Field(default=None, title="Name")
    """
    New name for the guardrail package.
    """
    scannerIds: list[UUID] | None = Field(default=None, title="Scannerids")
    """
    IDs of guardrails to include in the package. If not provided, the package's guardrails will remain unchanged.
    """


class PatchScannerVersionBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    description: str | None = Field(default=None, title="Description")
    """
    New description for the version.
    """
    published: bool = Field(default=False, title="Published")
    """
    Publish this version.
    """
    push: bool = Field(default=False, title="Push")
    """
    Push this version to all projects with the guardrail enabled.
    Will publish the version automatically if not already.
    """


class PatchSecretBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: str | None = Field(default=None, title="Name")
    """
    New name for the secret.
    """
    value: str | None = Field(default=None, title="Value")
    """
    New value for the secret.
    """


class PatchUserBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    blocked: bool | None = Field(default=None, title="Blocked")
    """
    Whether the user should be blocked.
    """
    name: constr(min_length=3, max_length=255) | None = Field(default=None, title="Name")
    """
    New name for the user.
    """


class PostAnthropicMessagesBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    max_tokens: int | None = Field(default=None, title="Max Tokens")
    messages: list[dict[str, Any]] | None = Field(default=None, title="Messages")
    model: str | None = Field(default=None, title="Model")
    stream: bool = Field(default=False, title="Stream")


class PostAuthRolesBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name of the role. Requires case insensitive uniqueness.
    """
    permissions: list[str] | None = Field(default=None, title="Permissions")
    """
    Permissions to grant to users with the created role.
    """
    projectId: UUID | None = Field(default=None, title="Projectid")
    """
    Assign the created role to a given project. If not provided, the role is associated with the organization.
    """


class PostCampaignScheduleBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignId: UUID | None = Field(default=None, title="Campaignid")
    """
    ID of the campaign to run. If empty, run all attacks.
    """
    count: int | None = Field(default=4, title="Count")
    """
    Determines how many occurrences will be generated. Cannot specify both count and end_at.
    """
    endAt: datetime | None = Field(default=None, title="Endat")
    """
    Target time after which no future occurrences will be generated.
    """
    frequency: CampaignScheduleFrequency | str | None = None
    """
    How often the schedule should run.
    """
    interval: int | None = Field(default=None, title="Interval")
    """
    The interval between each frequency iteration. For example, when using DAYS, an interval of 2 means once every two days. The default interval is 1.
    """
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name to give the campaign runs in this schedule.
    """
    providerIds: list[UUID] | None = Field(None, max_length=5, min_length=1, title="Providerids")
    """
    IDs of the providers to target for the campaign runs in this schedule
    """
    remediationSettings: CampaignRunRemediationSettings | None = None
    """
    Remediation settings for campaign runs in this schedule.
    """
    startAt: datetime | None = Field(default=None, title="Startat")
    """
    Target time to start the first campaign run.
    """


class PostCampaignScheduleResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignRunId: UUID | None = Field(default=None, title="Campaignrunid")
    id: UUID | None = Field(default=None, title="Id")


class PostChatCompletionBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    messages: list[dict[str, Any]] | None = Field(default=None, title="Messages")
    model: str | None = Field(default=None, title="Model")
    stream: bool = Field(default=False, title="Stream")


class PostChatsFromPromptBody(BaseModel):
    """
    Use this if you wish to create a chat out of a prompt.

    The newly created chat will use the existing prompts referred to instead of duplicating.
    """

    model_config = ConfigDict(
        extra="allow",
    )
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name of the new chat.
    """
    promptId: UUID | None = Field(default=None, title="Promptid")
    """
    ID of the prompt you wish to use in the chat
    """


class PostChatsFromTemplateBody(BaseModel):
    """
    Use this if you wish to create a new chat from a prompt template.

    The newly created chat will duplicate all prompts in the prompt template.
    """

    model_config = ConfigDict(
        extra="allow",
    )
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name of the new chat.
    """
    promptTemplateId: UUID | None = Field(default=None, title="Prompttemplateid")
    """
    ID of the prompt template you wish to use
    """


class PostGoogleGenerateContentBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    contents: list[dict[str, Any]] | None = Field(default=None, title="Contents")


class PostGroupBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name of the new group. Must be unique in the org.
    """


class PostGroupResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    group: Group | None = None
    """
    Newly created group.
    """


class PostGroupUsersBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    members: list[str] | None = Field(default=None, title="Members")
    """
    IDs of users to add to the group.
    """


class PostIDResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    id: UUID | None = Field(default=None, title="Id")


class PostOpenAIResponsesBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    input: list[dict[str, Any]] | str | None = Field(default=None, title="Input")
    model: str | None = Field(default=None, title="Model")
    stream: bool = Field(default=False, title="Stream")


class PostOrgResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    id: str | None = Field(default=None, title="Id")
    """
    ID of the created organization
    """


class PostPackageRequest(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    global_: bool = Field(default=True, alias="global", title="Global")
    """
    Whether this guardrail package is globally accessible.
    """
    name: constr(min_length=1, max_length=70) | None = Field(default=None, title="Name")
    """
    Name for the new guardrail package.
    """
    scannerIds: list[UUID] | None = Field(default=None, title="Scannerids")
    """
    IDs of guardrails to add to the package.
    """
    vendored: bool = Field(default=False, title="Vendored")


class PostProjectMembersBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    admin: bool = Field(default=False, title="Admin")
    """
    IDs of users to add to the project.
    """
    members: list[str] | None = Field(default=None, title="Members")


class Type2(str, Enum):
    """
    Type of the project to create.
    """

    APP = "app"
    AGENTIC = "agentic"
    CHAT = "chat"
    BOT = "bot"


class PostPromptTemplatesBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    endpointId: UUID | None = Field(default=None, title="Endpointid")
    """
    ID of an endpoint to allow access to the newly created template.
    """
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name of the prompt template.
    """
    project: UUID | str | None = Field(default=None, title="Project")
    """
    ID or friendly ID of a project to allow access to other users to the newly created template with
    access to the project. If not provided, the new template will only be accessible by the owner.
    """
    promptId: UUID | None = Field(default=None, title="Promptid")
    """
    ID of prompt to create template from.
    """


class PostPromptsBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    endpoint: UUID | str | None = Field(default=None, title="Endpoint")
    """
    (Deprecated) Endpoint ID or name to send prompt to, defaults to global endpoint
    """
    externalMetadata: dict[str, constr(max_length=255)] | None = Field(None, title="Externalmetadata")
    """
    A json string for users to attach any data to the prompt for their own use,
    For example to tag certain prompts for tracking
    (Limited to 10 items, keys of up to 50 characters and values of up to 255 characters).
    """
    input: str | dict[str, Any] | list | int | float | bool | None = Field(None, title="Input")
    """
    Prompt data to send to provider
    """
    parentId: UUID | None = Field(default=None, title="Parentid")
    """
    Parent ID to set on child prompts
    """
    project: UUID | str | None = Field(default=None, title="Project")
    """
    Project ID or name to send prompt to, defaults to global project
    """
    provider: UUID | str | None = Field(default=None, title="Provider")
    """
    Provider ID or name to send prompt to, defaults to chosen project's default provider
    """
    skipScanning: bool | None = Field(default=None, title="Skipscanning")
    verbose: bool = Field(default=False, title="Verbose")
    """
    If true, return details on each guardrail that ran against the input data
    """


class PostPromptsBodyFromChat(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    chatId: UUID | None = Field(default=None, title="Chatid")
    """
    Chat ID to add prompt to
    """
    externalMetadata: dict[str, constr(max_length=255)] | None = Field(None, title="Externalmetadata")
    """
    A json string for users to attach any data to the prompt for their own use,
    For example to tag certain prompts for tracking
    (Limited to 10 items, keys of up to 50 characters and values of up to 255 characters).
    """
    input: str | dict[str, Any] | list | int | float | bool | None = Field(None, title="Input")
    """
    Prompt data to send to provider
    """
    verbose: bool = Field(default=False, title="Verbose")
    """
    If true, return details on each guardrail that ran against the input data
    """


class PostRunCampaignBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignId: UUID | None = Field(default=None, title="Campaignid")
    """
    ID of the campaign to run. If empty, run all attacks.
    """
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name to give the campaign run
    """
    providerIds: list[UUID] | None = Field(None, max_length=5, min_length=1, title="Providerids")
    """
    IDs of the providers to target for the campaign
    """
    remediationSettings: CampaignRunRemediationSettings | None = None
    """
    Remediation settings.
    """


class PostSecretsBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: str | None = Field(default=None, title="Name")
    """
    Name of the newly created secret.
    """
    value: str | None = Field(default=None, title="Value")
    """
    Value of the newly created secret.
    """


class PostSuccessMessage(BaseModel):
    """
    Contains the ID of an object after a successful POST operation.
    """

    model_config = ConfigDict(
        extra="allow",
    )
    id: UUID | str | None = Field(default=None, title="Id")


class PostTokensBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    expiresAt: datetime | None = Field(default=None, title="Expiresat")
    """
    Datetime in the future when the api key will no longer be valid
    """
    name: str | None = Field(default=None, title="Name")
    """
    Name of the api token
    """


class PostTokensMachineBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    expiresAt: datetime | None = Field(default=None, title="Expiresat")
    """
    Datetime in the future when the api key will no longer be valid
    """
    groupId: UUID | None = Field(default=None, title="Groupid")
    """
    If an id of a user group is past in, will create machine token for that user group
    """
    machine: Literal[True] = Field(default=True, title="Machine")
    """
    Can not be set to False
    """
    name: str | None = Field(default=None, title="Name")
    """
    Name of the api token
    """
    projectId: UUID | None = Field(default=None, title="Projectid")
    """
    If an id of a user group is past in, will create machine token for that user group
    """


class PostUserResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    emailSent: bool | None = Field(default=None, title="Emailsent")
    """
    If an email was sent to invite the user
    """
    id: UUID | str | None = Field(default=None, title="Id")
    """
    ID of the created user
    """


class PostUsersVerificationBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    password: str | None = Field(default=None, title="Password")
    """
    New password for user
    """
    token: str | None = Field(default=None, title="Token")
    """
    Token for verification
    """


class PostVerificationTokenResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    token: str | None = Field(default=None, title="Token")


class ProjectDeploymentStatus(str, Enum):
    LIVE = "live"
    DRAFT = "draft"


class ProjectSearchSortBy(str, Enum):
    NAME = "name"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class ProjectType(str, Enum):
    APP = "app"
    BOT = "bot"
    CHAT = "chat"
    GLOBAL_ = "global"
    AGENTIC = "agentic"


class Type3(str, Enum):
    PROMPT = "prompt"
    TEST = "test"


class PromptAnalysis(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    input: list[FlaggedSpan] | None = Field(default=None, title="Input")
    """
    Spans of input text that were flagged.
    """
    response: list[FlaggedSpan] | None = Field(default=None, title="Response")
    """
    Spans of response text that were flagged.
    """


class PromptConverter(str, Enum):
    BASE64 = "base64"
    LEETSPEAK = "leetspeak"
    UNICODE_CONFUSABLE = "unicode_confusable"
    CAESAR = "caesar"
    REPEAT_TOKEN = "repeat_token"
    SINGLE_CHARACTER = "single_character"


class PromptInjectionScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    scores: dict[str, list[confloat(ge=0.0, le=100.0)]] = Field(default={}, title="Scores")
    type: Literal["prompt_injection"] = Field(default="prompt_injection", title="Type")


class PromptOutcome(str, Enum):
    """
    Outcome of a prompt after it has been processed by all guardrails and providers.

    Cleared: All guardrails passed, and the prompt was sent to providers
    Flagged: At least one guardrail failed, and the prompt was sent to providers
    Blocked: At least one guardrail failed, and the prompt was not sent to providers.
    """

    CLEARED = "cleared"
    FLAGGED = "flagged"
    REDACTED = "redacted"
    BLOCKED = "blocked"


class PromptResultFile(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    contentType: str | None = Field(default=None, title="Contenttype")
    data: str | None = Field(default=None, title="Data")
    """
    File data, optionally base64 encoded if isBase64 is true
    """
    id: UUID | None = Field(default=None, title="Id")
    isBase64: bool | None = Field(default=None, title="Isbase64")
    name: str | None = Field(default=None, title="Name")


class PromptTemplate(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    endpointId: UUID | None = Field(default=None, title="Endpointid")
    id: UUID | None = Field(default=None, title="Id")
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    projectId: UUID | None = Field(default=None, title="Projectid")
    """
    ID of a group or None if top level
    """
    promptId: UUID | None = Field(default=None, title="Promptid")
    userId: str | None = Field(default=None, title="Userid")


class PromptType(str, Enum):
    PROMPT = "prompt"
    SCAN = "scan"
    TEST = "test"


class ProvideRunResponseData(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    body: str | None = Field(default=None, title="Body")
    """
    Body of the response if one was received, encoded in base64
    """
    headers: dict[str, Any] | None = Field(default=None, title="Headers")
    """
    Headers of the response
    """
    statusCode: int | None = Field(default=None, title="Statuscode")
    """
    HTTP status code of the response
    """


class ProviderAvailability(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    global_: bool = Field(default=False, alias="global", title="Global")
    """
    If True provider can be used by all projects
    """
    projectIds: list[UUID] = Field(default=[], title="Projectids")


class ProviderCapability(str, Enum):
    CHAT = "chat"
    RED_TEAM = "red_team"
    SIEM = "siem"
    OPENAI_CHAT = "openai_chat"
    OPENAI_RESPONSES = "openai_responses"
    ANTHROPIC_MESSAGES = "anthropic_messages"
    GOOGLE_GENERATE_CONTENT = "google_generate_content"


class ProviderOutputFile(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    contentType: str | None = Field(default=None, title="Contenttype")
    data: Any | None = Field(default=None, title="Data")
    isBase64: bool = Field(default=False, title="Isbase64")
    name: str | None = Field(default=None, title="Name")


class ProviderPromptResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    data: str | None = Field(default=None, title="Data")
    """
    Response contents from LLM
    """
    receivedDate: datetime | None = Field(default=None, title="Receiveddate")
    """
    Time response was received from the LLM
    """
    sentDate: datetime | None = Field(default=None, title="Sentdate")
    """
    Time prompt was sent to the LLM
    """
    statusCode: int | None = Field(default=None, title="Statuscode")
    """
    Status code returned from request to provider
    """


class ProviderRunRequestData(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    body: str | None = Field(default=None, title="Body")
    """
    Body of the request if one was sent, encoded in base64
    """
    headers: dict[str, Any] | None = Field(default=None, title="Headers")
    """
    Headers sent as part of the request
    """
    method: str | None = Field(default=None, title="Method")
    """
    HTTP method of the request
    """
    queryParams: dict[str, Any] | None = Field(default=None, title="Queryparams")
    """
    Query parameters appended to the URL for this request
    """
    url: str | None = Field(default=None, title="Url")
    """
    URL that the request was sent
    """


class ProviderType(str, Enum):
    IBM = "ibm"
    OPENAI = "openai"
    AZURE = "azure"
    COHERE = "cohere"
    AI21 = "ai21"
    CUSTOM = "custom"
    ANTHROPIC = "anthropic"
    GROQ = "groq"
    OPENAI_COMPATIBLE = "openai-compatible"
    HUGGINGFACE = "huggingface"
    SIEM = "siem"
    GOOGLE = "google"


class Type4(str, Enum):
    PROMPT = "prompt"
    SCAN = "scan"


class PublicPromptResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    files: list[PromptResultFile] = Field(default=[], title="Files")
    outcome: PromptOutcome | str | None = None
    """
    One of 'cleared', 'flagged' or 'blocked'
    """
    providerResult: ProviderPromptResult | None = None
    response: str | None = Field(default=None, title="Response")
    """
    The response to the prompt from the LLM
    """


class RegexScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    pattern: str | None = Field(default=None, title="Pattern")
    """
    Python Flavored Regular Expression (RegEx) to check for in the prompt or response. Case insensitive.
    """
    type: Literal["regex"] = Field(default="regex", title="Type")


class RegexScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    matches: list[list] | None = Field(default=None, title="Matches")
    type: Literal["regex"] = Field(default="regex", title="Type")


class RemediationCancelledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["cancelled"] = Field(default="cancelled", title="Event")


class RemediationCancellingEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["cancelling"] = Field(default="cancelling", title="Event")


class RemediationCompletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["completed"] = Field(default="completed", title="Event")


class RemediationConfusionMatrix(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    falseNegatives: int | None = Field(default=None, title="Falsenegatives")
    falsePositives: int | None = Field(default=None, title="Falsepositives")
    trueNegatives: int | None = Field(default=None, title="Truenegatives")
    truePositives: int | None = Field(default=None, title="Truepositives")


class RemediationError(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    message: str | None = Field(default=None, title="Message")
    type: str | None = Field(default=None, title="Type")


class RemediationEvaluationMetrics(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    accuracy: float | None = Field(default=None, title="Accuracy")
    confusionMatrix: RemediationConfusionMatrix | None = None
    f1Score: float | None = Field(default=None, title="F1Score")


class RemediationFailedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["failed"] = Field(default="failed", title="Event")
    message: str | None = Field(default=None, title="Message")


class RemediationIntentScores(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    after: float | None = Field(default=None, title="After")
    before: float | None = Field(default=None, title="Before")
    intent: str | None = Field(default=None, title="Intent")


class RemediationQueuedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["queued"] = Field(default="queued", title="Event")


class RemediationResultScanner(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    config: GenAIScannerConfig | None = None
    name: str | None = Field(default=None, title="Name")


class RemediationScannerSource(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    sourceId: UUID | None = Field(default=None, title="Sourceid")
    type: Literal["remediation"] = Field(default="remediation", title="Type")


class RemediationScores(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    after: float | None = Field(default=None, title="After")
    before: float | None = Field(default=None, title="Before")


class RemediationStartedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    event: Literal["started"] = Field(default="started", title="Event")


class RemediationStatus(str, Enum):
    REQUESTED = "requested"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    ERROR = "error"
    IMPLEMENTED = "implemented"
    DEPLOYED = "deployed"
    CANCELLING = "cancelling"
    CANCELLED = "cancelled"
    REJECTED = "rejected"


class RequestConcurrencyLimit(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    decayPerSecond: PositiveInt | None = Field(default=None, title="Decaypersecond")
    """
    Number of request slots that are opened per second.

    Set a value to use the concurrency limit as a rate limit.

    For example, to set a rate limit of 5 requests per second set requests=5 and decayPerSecond=5
    """
    requests: PositiveInt | None = Field(default=None, title="Requests")
    """
    Max number of request slots that can be occupied at once.
    """


class Role(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    id: UUID | None = Field(default=None, title="Id")
    memberCount: int | None = Field(default=None, title="Membercount")
    name: str | None = Field(default=None, title="Name")
    permissions: list[str] = Field(default=[], title="Permissions")
    projectId: UUID | None = Field(default=None, title="Projectid")
    system: bool | None = Field(default=None, title="System")


class RunStatus(str, Enum):
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    ERROR = "error"


class ScanDirection(str, Enum):
    REQUEST = "request"
    RESPONSE = "response"


class ScanMode(str, Enum):
    BLOCK = "block"
    AUDIT = "audit"
    REDACT = "redact"


class ScanOutcome(str, Enum):
    """
    The outcome of a single scan on a prompt.
    """

    FAILED = "failed"
    PASSED = "passed"


class ScanType(str, Enum):
    TOXICITY = "toxicity"
    AUDIT_TERM = "audit_term"
    BLACKLIST = "blacklist"
    SENTIMENT_ANALYSIS = "sentiment_analysis"
    DEMOGRAPHIC = "demographic"
    NAMED_ENTITY = "named_entity"
    PROMPT_INJECTION = "prompt_injection"
    SOURCE_CODE = "source_code"
    TOPICS = "topics"
    PII_DETECTION = "pii_detection"
    SECRET = "secret"
    LEGAL = "legal"
    GENAI = "genai"
    CUSTOM = "custom"
    REGEX = "regex"
    KEYWORD = "keyword"


class ScannerAvailability(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    global_: bool = Field(default=False, alias="global", title="Global")
    """
    If True guardrail can be used by all projects
    """
    projectIds: list[UUID] = Field(default=[], title="Projectids")


class ScannerDatasetResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    datasetRunId: UUID | None = Field(default=None, title="Datasetrunid")
    f1Score: float | None = Field(default=None, title="F1Score")


class ScannerDescriptionGenerationInput(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    description: str | None = Field(default=None, title="Description")
    type: Literal["scanner_description"] = Field(default="scanner_description", title="Type")


class ScannerDescriptionGenerationOutput(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    description: str | None = Field(default=None, title="Description")


class ScannerDirection(str, Enum):
    BOTH = "both"
    REQUEST = "request"
    RESPONSE = "response"


class ScannerImportError(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    details: dict[str, Any] | list | None = Field(default=None, title="Details")
    message: str | None = Field(default=None, title="Message")
    path: str | None = Field(default=None, title="Path")


class ScannerSearchSortBy(str, Enum):
    NAME = "name"
    UPDATED_AT = "updated_at"
    CREATED_AT = "created_at"


class ScannerSensitivity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ScannerSourceType(str, Enum):
    INTERNAL = "internal"
    SHARE = "share"
    ZIP = "zip"
    VENDOR = "vendor"
    SYSTEM = "system"
    REMEDIATION = "remediation"


class ScannerStats(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    meanTimePerKb: float = Field(default=0, title="Meantimeperkb")
    totalProcessed: int = Field(default=0, title="Totalprocessed")


class ScannerVersionInputModel(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    description: str | None = Field(default=None, title="Description")
    """
    Description of the changes in the new version.
    """
    name: constr(pattern=r"^[a-zA-Z0-9-_]+$", min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name for the new version.
    """
    published: bool = Field(default=True, title="Published")
    """
    If the version should be published.
    """
    push: bool = Field(default=False, title="Push")
    """
    If the version should be pushed to all projects using the guardrail.
    Only has an effect if the version is published.
    """


class ScannerVersionMeta(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    createdBy: str | None = Field(default=None, title="Createdby")
    description: str | None = Field(default=None, title="Description")
    direction: ScannerDirection | str | None = None
    f1Score: float | None = Field(default=None, title="F1Score")
    id: UUID | None = Field(default=None, title="Id")
    latestDatasetResult: ScannerDatasetResult | None = None
    name: constr(pattern=r"^[a-zA-Z0-9-_]+$", min_length=1, max_length=100) | None = Field(default=None, title="Name")
    published: bool | None = Field(default=None, title="Published")


class Secret(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    deletedAt: datetime | None = Field(default=None, title="Deletedat")
    id: UUID | None = Field(default=None, title="Id")
    name: str | None = Field(default=None, title="Name")
    value: str | None = Field(default=None, title="Value")


class SecretScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    matches: dict[str, dict[str, list[list]]] | None = Field(default=None, title="Matches")
    type: Literal["secret"] = Field(default="secret", title="Type")


class SecretSensitivityLevel(str, Enum):
    STANDARD = "standard"
    HIGH = "high"


class SecretType(str, Enum):
    REGEX = "regex"
    ENTROPY = "entropy"
    USER = "user"


class SentimentAnalysisScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    sensitivity: ScannerSensitivity | str = "medium"
    type: Literal["sentiment_analysis"] = Field(default="sentiment_analysis", title="Type")


class SentimentAnalysisScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    negative: confloat(ge=0.0, le=100.0) | None = Field(default=None, title="Negative")
    neutral: confloat(ge=0.0, le=100.0) | None = Field(default=None, title="Neutral")
    positive: confloat(ge=0.0, le=100.0) | None = Field(default=None, title="Positive")
    type: Literal["sentiment_analysis"] = Field(default="sentiment_analysis", title="Type")


class Setting(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    level: int | None = Field(default=None, title="Level")
    name: str | None = Field(default=None, title="Name")
    setAt: datetime | None = Field(default=None, title="Setat")
    setBy: str | None = Field(default=None, title="Setby")
    value: Any | None = Field(default=None, title="Value")


class ShareScannerSource(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    type: Literal["share"] = Field(default="share", title="Type")


class SourceCodeLanguage(str, Enum):
    PYTHON = "python"
    GO = "go"
    JAVA = "java"
    JAVASCRIPT = "javascript"
    PHP = "php"
    RUBY = "ruby"
    SQL = "sql"
    HTML = "html"
    CSS = "css"
    TYPESCRIPT = "typescript"
    BASH = "bash"
    C = "c"
    C__ = "c++"
    C_ = "c#"
    VBA = "vba"
    UNKNOWN = "unknown"


class SourceCodeScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    flagCode: bool = Field(default=True, title="Flagcode")
    flagImportStatement: bool = Field(default=False, title="Flagimportstatement")
    languages: list[SourceCodeLanguage] = Field(
        [
            "python",
            "go",
            "java",
            "javascript",
            "php",
            "ruby",
            "sql",
            "html",
            "css",
            "typescript",
            "bash",
            "c",
            "c++",
            "c#",
            "vba",
            "unknown",
        ],
        title="Languages",
    )
    sensitivity: ScannerSensitivity | str = "medium"
    type: Literal["source_code"] = Field(default="source_code", title="Type")


class SourceCodeScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    matches: dict[str, list[list]] | None = Field(default=None, title="Matches")
    type: Literal["source_code"] = Field(default="source_code", title="Type")


class StaticContentAttack(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    converters: list[PromptConverter] = Field(
        [
            "base64",
            "leetspeak",
            "unicode_confusable",
            "caesar",
            "repeat_token",
            "single_character",
        ],
        title="Converters",
    )
    pack: str = Field(default="2026-04", title="Pack")
    severity: Literal[1] = Field(default=1, title="Severity")
    technique: Literal["static_content"] = Field(default="static_content", title="Technique")
    vector: Vector1 | str | None = Field(default=None, title="Vector")


class SuccessMessage(BaseModel):
    """
    Confirms a successful operation.
    """

    model_config = ConfigDict(
        extra="allow",
    )
    message: str | None = Field(default=None, title="Message")


class SystemScannerSource(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    type: Literal["system"] = Field(default="system", title="Type")


class Token(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    expiresAt: datetime | None = Field(default=None, title="Expiresat")
    id: UUID | None = Field(default=None, title="Id")
    machine: bool | None = Field(default=None, title="Machine")
    name: str | None = Field(default=None, title="Name")
    projectId: UUID | None = Field(default=None, title="Projectid")
    userId: str | None = Field(default=None, title="Userid")
    value: str | None = Field(default=None, title="Value")


class Topic(str, Enum):
    ARTS___CULTURE = "arts_&_culture"
    BUSINESS___ENTREPRENEURS = "business_&_entrepreneurs"
    CELEBRITY___POP_CULTURE = "celebrity_&_pop_culture"
    DIARIES___DAILY_LIFE = "diaries_&_daily_life"
    FAMILY = "family"
    FASHION___STYLE = "fashion_&_style"
    FILM_TV___VIDEO = "film_tv_&_video"
    FITNESS___HEALTH = "fitness_&_health"
    FOOD___DINING = "food_&_dining"
    GAMING = "gaming"
    LEARNING___EDUCATIONAL = "learning_&_educational"
    MUSIC = "music"
    NEWS___SOCIAL_CONCERN = "news_&_social_concern"
    OTHER_HOBBIES = "other_hobbies"
    RELATIONSHIPS = "relationships"
    SCIENCE___TECHNOLOGY = "science_&_technology"
    SPORTS = "sports"
    TRAVEL___ADVENTURE = "travel_&_adventure"
    YOUTH___STUDENT_LIFE = "youth_&_student_life"


class TopicsScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    flag: list[Topic] = Field(default=[], title="Flag")
    threshold: confloat(ge=0.0, le=100.0) = Field(default=50, title="Threshold")
    type: Literal["topics"] = Field(default="topics", title="Type")


class TopicsScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    detections: dict[str, confloat(ge=0.0, le=100.0)] | None = Field(None, title="Detections")
    type: Literal["topics"] = Field(default="topics", title="Type")


class ToxicityFlagThresholds(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    identityAttack: confloat(ge=0.0, le=100.0) = Field(default=50, title="Identityattack")
    insult: confloat(ge=0.0, le=100.0) = Field(default=85, title="Insult")
    obscene: confloat(ge=0.0, le=100.0) = Field(default=100, title="Obscene")
    severeToxicity: confloat(ge=0.0, le=100.0) = Field(default=10, title="Severetoxicity")
    sexualExplicit: confloat(ge=0.0, le=100.0) = Field(default=100, title="Sexualexplicit")
    threat: confloat(ge=0.0, le=100.0) = Field(default=70, title="Threat")
    toxicity: confloat(ge=0.0, le=100.0) = Field(default=85, title="Toxicity")


class ToxicityScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    flagThresholds: ToxicityFlagThresholds = Field(
        default_factory=lambda: ToxicityFlagThresholds.model_validate(
            {
                "identityAttack": 50.0,
                "insult": 85.0,
                "obscene": 100.0,
                "severeToxicity": 10.0,
                "sexualExplicit": 100.0,
                "threat": 70.0,
                "toxicity": 85.0,
            }
        )
    )
    type: Literal["toxicity"] = Field(default="toxicity", title="Type")


class ToxicityScannerResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    identityAttack: confloat(ge=0.0, le=100.0) | None = Field(None, title="Identityattack")
    insult: confloat(ge=0.0, le=100.0) | None = Field(default=None, title="Insult")
    obscene: confloat(ge=0.0, le=100.0) | None = Field(default=None, title="Obscene")
    severeToxicity: confloat(ge=0.0, le=100.0) | None = Field(None, title="Severetoxicity")
    sexualExplicit: confloat(ge=0.0, le=100.0) | None = Field(None, title="Sexualexplicit")
    threat: confloat(ge=0.0, le=100.0) | None = Field(default=None, title="Threat")
    toxicity: confloat(ge=0.0, le=100.0) | None = Field(default=None, title="Toxicity")
    type: Literal["toxicity"] = Field(default="toxicity", title="Type")


class UpdateScannerFromSourceBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    update: Literal[True] = Field(default=True, title="Update")
    """
    Apply an available update to a package imported from a share link
    """


class UpdateScannerPackageFromSourceBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    update: Literal[True] = Field(default=True, title="Update")
    """
    Apply an available update to a package imported from a share link
    """


class UpdateScheduleParams(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    count: int | None = Field(default=None, title="Count")
    """
    Determines how many occurrences will be generated. Cannot specify both count and end_at.
    """
    endAt: datetime | None = Field(default=None, title="Endat")
    """
    Target time after which no future occurrences will be generated.
    """
    frequency: CampaignScheduleFrequency | str | None = None
    """
    How often the schedule should run.
    """
    interval: int | None = Field(default=None, title="Interval")
    """
    The interval between each frequency iteration. For example, when using DAYS, an interval of 2 means once every two days. The default interval is 1.
    """
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name to give the campaign runs in this schedule.
    """
    remediationSettings: CampaignRunRemediationSettings | None = None
    """
    Determines if the campaign run will automatically create a remediation for vulnerabilities found.
    """
    startAt: datetime | None = Field(default=None, title="Startat")
    """
    Target time to start the first campaign run. If this does not match the previous parameter, it must be in the future.
    """


class User(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    admin: bool | None = Field(default=None, title="Admin")
    blocked: bool = Field(default=False, title="Blocked")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    email: str | None = Field(default=None, title="Email")
    id: str | None = Field(default=None, title="Id")
    lastInvitationSentAt: datetime | None = Field(default=None, title="Lastinvitationsentat")
    machine: bool = Field(default=False, title="Machine")
    name: str | None = Field(default=None, title="Name")
    org: str | None = Field(default=None, title="Org")
    permissions: list[str] = Field(default=[], title="Permissions")
    roleIds: list[UUID] = Field(default=[], title="Roleids")
    roles: list[str] = Field(default=[], title="Roles")
    social: bool = Field(default=False, title="Social")
    teams: list[str] = Field(default=[], title="Teams")
    verified: bool = Field(default=True, title="Verified")


class UserAuthenticationMethodsDeleted(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["user-auth-method-deleted"] = Field("user-auth-method-deleted", title="Type")
    user: User | None = None
    userId: str | None = Field(default=None, title="Userid")


class UserBlockedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["user-blocked"] = Field(default="user-blocked", title="Type")
    user: User | None = None
    userId: str | None = Field(default=None, title="Userid")


class UserCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["user-created"] = Field(default="user-created", title="Type")
    user: User | None = None
    userId: str | None = Field(default=None, title="Userid")


class UserDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["user-deleted"] = Field(default="user-deleted", title="Type")
    user: User | None = None
    userId: str | None = Field(default=None, title="Userid")


class UserRole(str, Enum):
    OWNER = "owner"
    SUPER_ADMIN = "super_admin"
    BASIC = "basic"


class UserRoleAssignedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["user-role-granted"] = Field(default="user-role-granted", title="Type")
    user: User | None = None
    userId: str | None = Field(default=None, title="Userid")


class UserRoleRetractedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["user-role-retracted"] = Field(default="user-role-retracted", title="Type")
    user: User | None = None
    userId: str | None = Field(default=None, title="Userid")


class UserRolesUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["user-roles-updated"] = Field(default="user-roles-updated", title="Type")
    user: User | None = None
    userId: str | None = Field(default=None, title="Userid")


class UserSecret(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    contextWords: list[str] | None = Field(default=None, title="Contextwords")
    pattern: str | None = Field(default=None, title="Pattern")
    sensitivityLevel: SecretSensitivityLevel | str = "standard"


class UserUnblockedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["user-unblocked"] = Field(default="user-unblocked", title="Type")
    user: User | None = None
    userId: str | None = Field(default=None, title="Userid")


class UserUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["user-updated"] = Field(default="user-updated", title="Type")
    user: User | None = None
    userId: str | None = Field(default=None, title="Userid")


class UserVerifiedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["user-verified"] = Field(default="user-verified", title="Type")
    user: User | None = None
    userId: str | None = Field(default=None, title="Userid")


class ValidationError(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    loc: list[str | int] | None = Field(default=None, title="Location")
    msg: str | None = Field(default=None, title="Message")
    type: str | None = Field(default=None, title="Error Type")


class VendorScannerSource(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    type: Literal["vendor"] = Field(default="vendor", title="Type")


class ZipImportResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    errors: list[ScannerImportError] = Field(default=[], title="Errors")
    packageIds: list[UUID] = Field(default=[], title="Packageids")
    scannerIds: list[UUID] = Field(default=[], title="Scannerids")
    scannerTemplateIds: list[UUID] = Field(default=[], title="Scannertemplateids")


class ZipScannerSource(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    type: Literal["zip"] = Field(default="zip", title="Type")


class APIRequestBlock(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    awsAuth: AWSAuth | None = None
    body: str | None = Field(default=None, title="Body")
    headers: dict[str, Any] = Field(default={}, title="Headers")
    json_: str | None = Field(default=None, alias="json", title="Json")
    method: HTTPMethod | str | None = None
    ociAuth: OCIAuth | None = None
    outputs: dict[constr(pattern=r"^[a-zA-Z_][a-zA-Z0-9_]*$"), str] = Field({}, title="APIScopeOutputs")
    queryParams: dict[str, str] = Field(default={}, title="Queryparams")
    timeout: int = Field(default=20, title="Timeout")
    type: Literal["request"] = Field(default="request", title="Type")
    url: str | None = Field(default=None, title="Url")


class AgentFingerprintSummary(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    agentCount: int | None = Field(default=None, title="Agentcount")
    errors: list[FingerprintProviderError | FingerprintInternalError | FingerprintUnsupportedError] = Field(
        default=[], title="Errors"
    )
    status: AgentFingerprintStatus | str | None = None
    toolCount: int | None = Field(default=None, title="Toolcount")
    updatedAt: datetime | None = Field(default=None, title="Updatedat")


class AgentSession(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    fingerprints: AgentFingerprintSummary | None = None
    firstPromptAt: datetime | None = Field(default=None, title="Firstpromptat")
    id: UUID | None = Field(default=None, title="Id")
    lastPromptAt: datetime | None = Field(default=None, title="Lastpromptat")
    peakOutcome: PromptOutcome | str | None = None
    projectId: UUID | None = Field(default=None, title="Projectid")
    sessionId: str | None = Field(default=None, title="Sessionid")


class AgentSessionCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    agentSessionId: UUID | None = Field(default=None, title="Agentsessionid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["agent-session-created"] = Field("agent-session-created", title="Type")
    user: User | None = None


class AgentSessionFingerprintsRequestedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    agentSessionId: UUID | None = Field(default=None, title="Agentsessionid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["agent-session-fingerprints-requested"] = Field("agent-session-fingerprints-requested", title="Type")
    user: User | None = None


class ApiTokenCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    tokenId: UUID | None = Field(default=None, title="Tokenid")
    type: Literal["api-token-created"] = Field(default="api-token-created", title="Type")
    user: User | None = None


class ApiTokenRevokedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    tokenId: UUID | None = Field(default=None, title="Tokenid")
    type: Literal["api-token-revoked"] = Field(default="api-token-revoked", title="Type")
    user: User | None = None


class AppMetrics(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    availableDbConnections: int | None = Field(default=None, title="Availabledbconnections")
    availableThreads: int | None = Field(default=None, title="Availablethreads")
    loadStats: LoadStats | None = None
    requestsLastSecond: int | None = Field(default=None, title="Requestslastsecond")
    workerStats: dict[str, ScannerStats] | None = Field(default=None, title="Workerstats")


class AttackErrorSummary(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    message: str | None = Field(default=None, title="Message")
    type: CampaignRunErrorType | str | None = None


class BrandingCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["branding-created"] = Field(default="branding-created", title="Type")
    user: User | None = None


class BrandingUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["branding-updated"] = Field(default="branding-updated", title="Type")
    user: User | None = None


class CampaignCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignId: UUID | None = Field(default=None, title="Campaignid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["campaign-created"] = Field(default="campaign-created", title="Type")
    user: User | None = None


class CampaignDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignId: UUID | None = Field(default=None, title="Campaignid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["campaign-deleted"] = Field(default="campaign-deleted", title="Type")
    user: User | None = None


class CampaignRunCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignId: UUID | None = Field(default=None, title="Campaignid")
    """
    Deprecated, use campaignRunId
    """
    campaignRunId: UUID | None = Field(default=None, title="Campaignrunid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["campaign-run-created"] = Field(default="campaign-run-created", title="Type")
    user: User | None = None


class CampaignRunDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignRunId: UUID | None = Field(default=None, title="Campaignrunid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["campaign-run-deleted"] = Field(default="campaign-run-deleted", title="Type")
    user: User | None = None


class CampaignRunUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignRunId: UUID | None = Field(default=None, title="Campaignrunid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["campaign-run-updated"] = Field(default="campaign-run-updated", title="Type")
    user: User | None = None


class CampaignSchedule(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignId: UUID | None = Field(default=None, title="Campaignid")
    count: int | None = Field(default=None, title="Count")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    endAt: datetime | None = Field(default=None, title="Endat")
    frequency: CampaignScheduleFrequency | str | None = None
    id: UUID | None = Field(default=None, title="Id")
    interval: int | None = Field(default=None, title="Interval")
    name: str | None = Field(default=None, title="Name")
    providerIds: list[UUID] | None = Field(default=None, title="Providerids")
    remediationSettings: CampaignRunRemediationSettings | None = None
    startAt: datetime | None = Field(default=None, title="Startat")


class CampaignScheduleCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignScheduleId: UUID | None = Field(default=None, title="Campaignscheduleid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["campaign-schedule-created"] = Field("campaign-schedule-created", title="Type")
    user: User | None = None


class CampaignScheduleDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignScheduleId: UUID | None = Field(default=None, title="Campaignscheduleid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["campaign-schedule-deleted"] = Field("campaign-schedule-deleted", title="Type")
    user: User | None = None


class CampaignScheduleUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignScheduleId: UUID | None = Field(default=None, title="Campaignscheduleid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["campaign-schedule-updated"] = Field("campaign-schedule-updated", title="Type")
    user: User | None = None


class CampaignUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignId: UUID | None = Field(default=None, title="Campaignid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["campaign-updated"] = Field(default="campaign-updated", title="Type")
    user: User | None = None


class Chat(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    access: ChatAccess | None = None
    createdAt: datetime | None = Field(default=None, title="Createdat")
    id: UUID | None = Field(default=None, title="Id")
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    projectId: UUID | None = Field(default=None, title="Projectid")
    """
    ID of the project this chat belongs to
    """
    promptId: UUID | None = Field(default=None, title="Promptid")
    """
    ID of the first prompt in the chat, can be used to retrieve all prompts in the chat
    """
    promptTemplateId: UUID | None = Field(default=None, title="Prompttemplateid")
    """
    ID of the prompt template this chat was created from.
    """
    starred: bool | None = Field(default=None, title="Starred")
    """
    Starred means the chat has been bookmarked or 'starred' to find later
    """
    updatedAt: datetime | None = Field(default=None, title="Updatedat")
    userId: str | None = Field(default=None, title="Userid")
    """
    User who created the chat
    """


class ChatbotCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    chatbotId: UUID | None = Field(default=None, title="Chatbotid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["chatbot-created"] = Field(default="chatbot-created", title="Type")
    user: User | None = None


class ChatbotGroupCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    chatbotGroupId: UUID | None = Field(default=None, title="Chatbotgroupid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["chatbot-project-created"] = Field("chatbot-project-created", title="Type")
    user: User | None = None


class ChatbotGroupUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    chatbotGroupId: UUID | None = Field(default=None, title="Chatbotgroupid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["chatbot-project-updated"] = Field("chatbot-project-updated", title="Type")
    user: User | None = None


class ChatbotUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    chatbotId: UUID | None = Field(default=None, title="Chatbotid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["chatbot-updated"] = Field(default="chatbot-updated", title="Type")
    user: User | None = None


class DSAttackResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    conversation: list[dict[str, Any]] | None = Field(default=None, title="Conversation")
    conversationSteps: int = Field(default=0, title="Conversationsteps")
    converter: PromptConverter | str | None = None
    error: str | None = Field(default=None, title="Error")
    errorSummary: AttackErrorSummary | None = None
    fingerprint: Any = None
    intent: str | None = Field(default=None, title="Intent")
    intentCategory: str | None = Field(default=None, title="Intentcategory")
    severity: int | None = Field(default=None, title="Severity")
    vulnerable: bool | None = Field(default=None, title="Vulnerable")


class DatasetRun(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    datasetId: UUID | None = Field(default=None, title="Datasetid")
    fileId: UUID | None = Field(default=None, title="Fileid")
    id: UUID | None = Field(default=None, title="Id")
    result: DatasetScores | None = None
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")
    scannerVersionId: UUID | None = Field(default=None, title="Scannerversionid")
    status: RunStatus | str | None = None


class DynamicMultiTurnContentAttack(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    converters: list[PromptConverter] = Field(
        [
            "base64",
            "leetspeak",
            "unicode_confusable",
            "caesar",
            "repeat_token",
            "single_character",
        ],
        title="Converters",
    )
    intents: list[str] = Field(default=[], title="Intents")
    multiTurn: Literal[True] = Field(default=True, title="Multiturn")
    severity: conint(ge=1, le=3) = Field(default=1, title="Severity")
    technique: Literal["dynamic_content"] = Field(default="dynamic_content", title="Technique")
    vector: Vector | str | None = Field(default=None, title="Vector")


class DynamicSingleTurnContentAttack(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    converters: list[PromptConverter] = Field(
        [
            "base64",
            "leetspeak",
            "unicode_confusable",
            "caesar",
            "repeat_token",
            "single_character",
        ],
        title="Converters",
    )
    intents: list[str] = Field(default=[], title="Intents")
    severity: conint(ge=1, le=3) = Field(default=1, title="Severity")
    technique: Literal["dynamic_content"] = Field(default="dynamic_content", title="Technique")
    vector: Vector1 | str | None = Field(default=None, title="Vector")


class EntitlementGroupCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    entitlementGroupId: UUID | None = Field(default=None, title="Entitlementgroupid")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["entitlement-group-created"] = Field("entitlement-group-created", title="Type")
    user: User | None = None


class EntitlementGroupDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    entitlementGroupId: UUID | None = Field(default=None, title="Entitlementgroupid")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["entitlement-group-deleted"] = Field("entitlement-group-deleted", title="Type")
    user: User | None = None


class EntitlementGroupUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    entitlementGroupId: UUID | None = Field(default=None, title="Entitlementgroupid")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["entitlement-group-updated"] = Field("entitlement-group-updated", title="Type")
    user: User | None = None


class EntitlementOverrideCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    entitlementId: UUID | None = Field(default=None, title="Entitlementid")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["entitlement-override-created"] = Field("entitlement-override-created", title="Type")
    user: User | None = None


class EntitlementOverrideDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    entitlementId: UUID | None = Field(default=None, title="Entitlementid")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["entitlement-override-deleted"] = Field("entitlement-override-deleted", title="Type")
    user: User | None = None


class EntitlementUsageCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    entitlementId: UUID | None = Field(default=None, title="Entitlementid")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["entitlement-usage-created"] = Field("entitlement-usage-created", title="Type")
    user: User | None = None


class EntitlementUsageDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    entitlementId: UUID | None = Field(default=None, title="Entitlementid")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["entitlement-usage-deleted"] = Field("entitlement-usage-deleted", title="Type")
    user: User | None = None


class FileCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    fileId: UUID | None = Field(default=None, title="Fileid")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["file-created"] = Field(default="file-created", title="Type")
    user: User | None = None


class FileMetadata(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    purposes: list[FilePurpose] | None = Field(default=None, title="Purposes")
    rowCount: int | None = Field(default=None, title="Rowcount")
    size: int | None = Field(default=None, title="Size")


class GetAgentSessionsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    agentSessions: list[AgentSession] | None = Field(default=None, title="Agentsessions")
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """


class GetAuthRoleResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    role: Role | None = None
    """
    The requested role.
    """


class GetAuthRolesResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    roles: list[Role] | None = Field(default=None, title="Roles")
    """
    Roles matching the given filter criteria.
    """


class GetCampaignSchedulesResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    schedules: list[CampaignSchedule] | None = Field(default=None, title="Schedules")
    """
    Campaign schedules matching the given criteria
    """


class GetChatsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    chats: list[Chat] | None = Field(default=None, title="Chats")
    """
    Chats matching the given filter criteria.
    """


class GetGroupResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    group: Group | None = None
    """
    Requested group object.
    """


class GetGroupsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    groups: list[Group] | None = Field(default=None, title="Groups")
    """
    Groups matching the given filter criteria.
    """
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """


class GetOrganizationPreferencesResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    preferences: list[Setting] | None = Field(default=None, title="Preferences")
    """
    List of organization preferences.
    """


class GetPromptTemplatesResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    promptTemplates: list[PromptTemplate] | None = Field(default=None, title="Prompttemplates")
    """
    Prompt templates matching the given filter criteria.
    """


class GetScannerVersionsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    versions: list[ScannerVersionMeta] | None = Field(default=None, title="Versions")
    """
    Metadata for all versions of the chosen guardrail.
    """


class GetSecretResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    secret: Secret | None = None
    """
    Requested secret object with the value obfuscated.
    """


class GetSecretsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    secrets: list[Secret] | None = Field(default=None, title="Secrets")
    """
    All secrets available, with their values obfuscated.
    """


class GetTokensResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    tokens: list[Token] | None = Field(default=None, title="Tokens")


class GetUserResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    roles: dict[str, Role] = Field(default={}, title="Roles")
    """
    The user's roles if requested
    """
    user: User | None = None
    """
    Requested user object.
    """


class GetUsersMeResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    user: User | None = None
    """
    The currently authenticated user.
    """


class GetUsersResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    roles: dict[str, Role] = Field(default={}, title="Roles")
    """
    All roles that are held by user's in the response, if requested.
    """
    users: list[User] | None = Field(default=None, title="Users")
    """
    Users matching the given filter criteria.
    """


class HTTPValidationError(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    detail: list[ValidationError] | None = Field(default=None, title="Detail")


class LegacyAuditEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: str | Any | None = Field(default=None, title="Type")
    user: User | LegacyUser | None = Field(default=None, title="User")


class LegalScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    flaggingClasses: list[LegalDocumentClasses] = Field(
        ["contracts", "law", "nda", "tos_eula"], title="Flaggingclasses"
    )
    minPromptWords: int = Field(default=10, title="Minpromptwords")
    sensitivity: ScannerSensitivity | str = "medium"
    type: Literal["legal"] = Field(default="legal", title="Type")


class LicenseCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["license-created"] = Field(default="license-created", title="Type")
    user: User | None = None


class OAuthClientCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    oauthClientId: str | None = Field(default=None, title="Oauthclientid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["oauth_client_created"] = Field(default="oauth_client_created", title="Type")
    user: User | None = None


class OAuthClientDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    oauthClientId: str | None = Field(default=None, title="Oauthclientid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["oauth_client_deleted"] = Field(default="oauth_client_deleted", title="Type")
    user: User | None = None


class OAuthClientUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    oauthClientId: str | None = Field(default=None, title="Oauthclientid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["oauth_client_updated"] = Field(default="oauth_client_updated", title="Type")
    user: User | None = None


class OperationalAttack(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    severity: Literal[1] = Field(default=1, title="Severity")
    technique: Literal["operational"] = Field(default="operational", title="Technique")
    vector: OperationalAttackVector | str | None = None


class Organization(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    adminRoleId: UUID | None = Field(default=None, title="Adminroleid")
    applicationUrl: str | None = Field(default=None, title="Applicationurl")
    disabled: bool = Field(default=False, title="Disabled")
    entitlements: dict[str, Any] | Any | None = Field(default=None, title="Entitlements")
    hasOwner: bool = Field(default=False, title="Hasowner")
    id: str | None = Field(default=None, title="Id")
    name: str | None = Field(default=None, title="Name")
    ownerRoleId: UUID | None = Field(default=None, title="Ownerroleid")
    requireMfa: bool = Field(default=False, title="Requiremfa")


class OrganizationCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    orgId: str | None = Field(default=None, title="Orgid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["organization-created"] = Field(default="organization-created", title="Type")
    user: User | None = None


class OrganizationDataDeleted(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    orgId: str | None = Field(default=None, title="Orgid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["organization-data-deleted"] = Field("organization-data-deleted", title="Type")
    user: User | None = None


class OrganizationDisabledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    orgId: str | None = Field(default=None, title="Orgid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["organization-disabled"] = Field("organization-disabled", title="Type")
    user: User | None = None


class OrganizationEnabledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    orgId: str | None = Field(default=None, title="Orgid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["organization-enabled"] = Field(default="organization-enabled", title="Type")
    user: User | None = None


class OrganizationEntitlementsUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    orgId: str | None = Field(default=None, title="Orgid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["organization-entitlements-updated"] = Field("organization-entitlements-updated", title="Type")
    user: User | None = None


class OrganizationPromptRecordingDisabled(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    orgId: str | None = Field(default=None, title="Orgid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["organization-prompt-recording-disabled"] = Field(
        "organization-prompt-recording-disabled", title="Type"
    )
    user: User | None = None


class OrganizationPromptRecordingEnabled(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    orgId: str | None = Field(default=None, title="Orgid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["organization-prompt-recording-enabled"] = Field(
        "organization-prompt-recording-enabled", title="Type"
    )
    user: User | None = None


class OrganizationUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    orgId: str | None = Field(default=None, title="Orgid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["organization-updated"] = Field(default="organization-updated", title="Type")
    user: User | None = None


class PatchCampaignBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    attacks: (
        list[
            StaticContentAttack
            | DynamicSingleTurnContentAttack
            | DynamicMultiTurnContentAttack
            | OperationalAttack
            | CustomAttack
            | Attacks
        ]
        | None
    ) = Field(default=None, title="Attacks")
    """
    New list of attacks to run as part of this campaign
    """
    description: str | None = Field(default=None, title="Description")
    """
    New description for the campaign
    """
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    New name for the campaign.
    """


class PatchScannerResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    message: str | None = Field(default=None, title="Message")
    versionMeta: ScannerVersionMeta | None = None
    """
    New version information for guardrail if an update was applied
    """


class PostCampaignsBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    attacks: (
        list[
            StaticContentAttack
            | DynamicSingleTurnContentAttack
            | DynamicMultiTurnContentAttack
            | OperationalAttack
            | CustomAttack
            | Attacks
        ]
        | None
    ) = Field(default=None, title="Attacks")
    """
    List of attacks to run as part of this campaign
    """
    description: str | None = Field(default=None, title="Description")
    """
    Description for the campaign
    """
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name for the new campaign
    """


class PostGenerationResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    output: ScannerDescriptionGenerationOutput | CustomIntentGenerationOutput | None = Field(
        default=None, title="Output"
    )


class PostGenerationsBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    input: ScannerDescriptionGenerationInput | CustomIntentGenerationInput | None = Field(
        default=None, discriminator="type", title="Input"
    )


class PostOrgBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    email: constr(min_length=1, max_length=255) | None = Field(default=None, title="Email")
    """
    Email for the new user.
    """
    entitlements: Any = None
    """
    Entitlements for the new organization
    """
    name: str | None = Field(default=None, title="Name")
    """
    Name for the new organization
    """
    roleIds: list[UUID | str] | None = Field(default=None, title="Roleids")
    """
    Roles to assign to the user.
    """
    roles: list[UserRole] | None = Field(default=None, title="Roles")
    """
    Deprecated
    """
    sendInvite: bool = Field(default=True, title="Sendinvite")
    """
    Whether or not to send an invite email, if possible.
    """
    userName: constr(min_length=3, max_length=255) | None = Field(None, title="Username")
    """
    Name for the new user.
    """


class PostProviderTestSystemBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    capability: ProviderCapability | str | None = None
    """
    Provider capability to test for
    """
    inputs: dict[str, Any] | None = Field(default=None, title="Inputs")
    """
    Input values that can be accessed in the template.
    """
    secrets: dict[str, UUID] | None = Field(default=None, title="Secrets")
    """
    Secrets that can be accessed in the template.
    """
    systemProvider: UUID | str | None = Field(default=None, title="Systemprovider")
    """
    ID or name of system provider to test.
    """


class PostProvidersFromSystemBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    capabilities: list[ProviderCapability] | None = Field(default=None, title="Capabilities")
    """
    Set of capabilities that the provider will have. Cannot be changed after creation.
    """
    default: bool = Field(default=False, title="Default")
    """
    Whether the new provider should the default provider. Has no effect if enable is false.
    """
    enable: bool = Field(default=False, title="Enable")
    """
    Enable the new provider for the default project for the group/global settings.
    """
    groupId: UUID | None = Field(default=None, title="Groupid")
    """
    Limit access to the provider to a given group.
    """
    inputs: dict[str, Any] | None = Field(default=None, title="Inputs")
    """
    Input values that can be accessed in the template.
    """
    maxRequestsPerSecond: PositiveInt | None = Field(default=None, title="Maxrequestspersecond")
    """
    Deprecated, use requestConcurrencyLimit instead.
    """
    name: constr(pattern=r"^[a-zA-Z0-9-]+$") | None = Field(default=None, title="Name")
    """
    The name can be used to identify the provider instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """
    projectId: UUID | None = Field(default=None, title="Projectid")
    """
    Limit access to the provider to a given project.
    """
    redTeam: bool = Field(default=False, title="Redteam")
    """
    Mark provider for use in attack campaigns.
    """
    requestConcurrencyLimit: RequestConcurrencyLimit | None = None
    """
    Specifies concurrency limits for requests from campaign run attacks.
    """
    secrets: dict[str, UUID | NewSecret] | None = Field(default=None, title="Secrets")
    """
    Secrets that can be accessed in the template.
    """
    systemProvider: UUID | str | None = Field(default=None, title="Systemprovider")
    """
    ID or name of the system provider to use the template from.
    """
    tag: str | None = Field(default=None, title="Tag")
    """
    Optional tag to attach to the provider.
    """
    test: bool = Field(default=False, title="Test")
    """
    Whether to test the provider connection before creation.
    """


class PostScannersBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    config: GenAIScannerConfig | RegexScannerConfig | KeywordScannerConfig | None = Field(
        default=None, discriminator="type", title="Config"
    )
    """
    Config for the new guardrail.
    """
    direction: ScannerDirection | str = "request"
    """
    Direction the guardrail should scan in.
    """
    global_: bool = Field(default=True, alias="global", title="Global")
    """
    Whether this guardrail is globally accessible.
    """
    groupId: UUID | None = Field(default=None, title="Groupid")
    """
    Limit access to the guardrail to the given group.
    """
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name for the new guardrail.
    """
    published: bool = Field(default=False, title="Published")
    """
    Whether the guardrail should be published.
    """
    tags: list[constr(pattern=r"^[a-zA-Z0-9-_]+$", min_length=1, max_length=50)] = Field(default=[], title="Tags")
    """
    Tags for the guardrail.
    """
    vendored: bool = Field(default=False, title="Vendored")
    version: ScannerVersionInputModel | constr(pattern=r"^[a-zA-Z0-9-_]+$", min_length=1, max_length=100) | None = (
        Field(default=None, title="Version")
    )
    """
    Name or object containing the name and description for the initial version of the guardrail.
    """


class PostTokensResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    token: Token | None = None
    """
    Newly created token, with its value visible.
    """


class PostUserBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    email: constr(min_length=1, max_length=255) | None = Field(default=None, title="Email")
    """
    Email for the new user.
    """
    name: constr(min_length=3, max_length=255) | None = Field(default=None, title="Name")
    """
    Name for the new user.
    """
    roleIds: list[UUID] = Field(default=[], title="Roleids")
    """
    Roles to assign to the user.
    """
    roles: list[UserRole] = Field(default=["basic"], title="Roles")
    """
    Deprecated
    """
    sendInvite: bool = Field(default=True, title="Sendinvite")
    """
    Whether or not to send an invite email, if possible.
    """


class ProjectConfigProvider(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    capabilities: list[ProviderCapability | str] | None = Field(None, title="Capabilities")
    default: bool | None = Field(default=None, title="Default")
    enabled: bool | None = Field(default=None, title="Enabled")
    id: UUID | None = Field(default=None, title="Id")
    name: str | None = Field(default=None, title="Name")
    type: str | None = Field(default=None, title="Type")


class ProjectConfigScanner(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    blocking: bool | None = Field(default=None, title="Blocking")
    enabled: bool | None = Field(default=None, title="Enabled")
    flagMessage: str | None = Field(default=None, title="Flagmessage")
    force: bool | None = Field(default=None, title="Force")
    id: UUID | None = Field(default=None, title="Id")
    mode: ScanMode | str | None = None
    version: UUID | datetime | constr(pattern=r"^[a-zA-Z0-9-_]+$", min_length=1, max_length=100) | None = Field(
        default=None, title="Version"
    )


class ProjectCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-created"] = Field(default="project-created", title="Type")
    user: User | None = None


class ProjectDefaultProviderUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-default-provider-updated"] = Field("project-default-provider-updated", title="Type")
    user: User | None = None


class ProjectDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-deleted"] = Field(default="project-deleted", title="Type")
    user: User | None = None


class ProjectMemberAddedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-member-added"] = Field(default="project-member-added", title="Type")
    user: User | None = None


class ProjectMemberRemovedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-member-removed"] = Field("project-member-removed", title="Type")
    user: User | None = None


class ProjectProviderAddedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    providerId: UUID | None = Field(default=None, title="Providerid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-provider-added"] = Field("project-provider-added", title="Type")
    user: User | None = None


class ProjectProviderRemovedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    providerId: UUID | None = Field(default=None, title="Providerid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-provider-removed"] = Field("project-provider-removed", title="Type")
    user: User | None = None


class ProjectProviderRoutingCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-provider-routing-created"] = Field("project-provider-routing-created", title="Type")
    user: User | None = None


class ProjectProviderRoutingUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-provider-routing-updated"] = Field("project-provider-routing-updated", title="Type")
    user: User | None = None


class ProjectScannerAddedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["project-scanner-added"] = Field("project-scanner-added", title="Type")
    user: User | None = None


class ProjectScannerPackageAddedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")
    type: Literal["project-scanner-package-added"] = Field("project-scanner-package-added", title="Type")
    user: User | None = None


class ProjectScannerPackageRemovedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")
    type: Literal["project-scanner-package-removed"] = Field("project-scanner-package-removed", title="Type")
    user: User | None = None


class ProjectScannerRemovedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["project-scanner-removed"] = Field("project-scanner-removed", title="Type")
    user: User | None = None


class ProjectUndeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-undeleted"] = Field(default="project-undeleted", title="Type")
    user: User | None = None


class ProjectUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["project-updated"] = Field(default="project-updated", title="Type")
    user: User | None = None


class PromptInjectionScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    sensitivity: ScannerSensitivity | str = "medium"
    type: Literal["prompt_injection"] = Field(default="prompt_injection", title="Type")


class ProviderAvailabilityUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    providerId: UUID | None = Field(default=None, title="Providerid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["provider-availability-updated"] = Field("provider-availability-updated", title="Type")
    user: User | None = None


class ProviderCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    providerId: UUID | None = Field(default=None, title="Providerid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["provider-created"] = Field(default="provider-created", title="Type")
    user: User | None = None


class ProviderDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    providerId: UUID | None = Field(default=None, title="Providerid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["provider-deleted"] = Field(default="provider-deleted", title="Type")
    user: User | None = None


class ProviderDisabledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    providerId: UUID | None = Field(default=None, title="Providerid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["provider-disabled"] = Field(default="provider-disabled", title="Type")
    user: User | None = None


class ProviderEnabledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    providerId: UUID | None = Field(default=None, title="Providerid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["provider-enabled"] = Field(default="provider-enabled", title="Type")
    user: User | None = None


class ProviderRunBlockData(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    request: ProviderRunRequestData | None = None
    """
    Data of the request sent
    """
    response: ProvideRunResponseData | None = None
    """
    Data of the response received for the request, if one was received
    """


class ProviderTestEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    testId: UUID | None = Field(default=None, title="Testid")
    type: Literal["provider-test"] = Field(default="provider-test", title="Type")
    user: User | None = None


class ProviderUndeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    providerId: UUID | None = Field(default=None, title="Providerid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["provider-undeleted"] = Field(default="provider-undeleted", title="Type")
    user: User | None = None


class ProviderUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    providerId: UUID | None = Field(default=None, title="Providerid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["provider-updated"] = Field(default="provider-updated", title="Type")
    user: User | None = None


class RemediationCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    remediationId: UUID | None = Field(default=None, title="Remediationid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["remediation-created"] = Field(default="remediation-created", title="Type")
    user: User | None = None


class RemediationDeployedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    remediationId: UUID | None = Field(default=None, title="Remediationid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["remediation-deployed"] = Field(default="remediation-deployed", title="Type")
    user: User | None = None


class RemediationRejectedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    remediationId: UUID | None = Field(default=None, title="Remediationid")
    requestId: str | None = Field(default=None, title="Requestid")
    type: Literal["remediation-rejected"] = Field(default="remediation-rejected", title="Type")
    user: User | None = None


class RemediationResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    intentScores: list[RemediationIntentScores] | None = Field(None, title="Intentscores")
    metrics: RemediationEvaluationMetrics | None = None
    resultFileId: UUID | None = Field(default=None, title="Resultfileid")
    scanners: list[RemediationResultScanner] | None = Field(default=None, title="Scanners")
    scores: RemediationScores | None = None


class RemediationScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    blocking: bool | None = Field(default=None, title="Blocking")
    enabled: bool | None = Field(default=None, title="Enabled")
    flagMessage: str | None = Field(default=None, title="Flagmessage")
    force: bool | None = Field(default=None, title="Force")
    mode: ScanMode | str | None = None


class RoleCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    roleId: UUID | None = Field(default=None, title="Roleid")
    type: Literal["role-created"] = Field(default="role-created", title="Type")
    user: User | None = None


class RoleDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    roleId: UUID | None = Field(default=None, title="Roleid")
    type: Literal["role-deleted"] = Field(default="role-deleted", title="Type")
    user: User | None = None


class RolePermissionsAddedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    roleId: UUID | None = Field(default=None, title="Roleid")
    type: Literal["role-permissions-added"] = Field("role-permissions-added", title="Type")
    user: User | None = None


class RolePermissionsRemovedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    roleId: UUID | None = Field(default=None, title="Roleid")
    type: Literal["role-permissions-removed"] = Field("role-permissions-removed", title="Type")
    user: User | None = None


class RoleUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    roleId: UUID | None = Field(default=None, title="Roleid")
    type: Literal["role-updated"] = Field(default="role-updated", title="Type")
    user: User | None = None


class Scan(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    completedDate: datetime | None = Field(default=None, title="Completeddate")
    customConfig: bool = Field(default=False, title="Customconfig")
    data: (
        RegexScannerResult
        | KeywordScannerResult
        | BlacklistScannerResult
        | AuditTermScannerResult
        | DemographicScannerResult
        | PIIScannerResult
        | PromptInjectionScannerResult
        | SentimentAnalysisScannerResult
        | SourceCodeScannerResult
        | ToxicityScannerResult
        | NamedEntityScannerResult
        | TopicsScannerResult
        | LegalScannerResult
        | SecretScannerResult
        | NotRunScanResult
        | ErrorScanResult
        | GenAIScannerResult
        | None
    ) = Field(default=None, discriminator="type", title="Data")
    message: str | None = Field(default=None, title="Message")
    outcome: ScanOutcome | str | None = None
    scanDirection: ScanDirection | str | None = None
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    scannerVersionMeta: ScannerVersionMeta | None = None
    startedDate: datetime | None = Field(default=None, title="Starteddate")


class ScanRequestResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    outcome: PromptOutcome | str | None = None
    """
    One of 'cleared' or 'flagged'
    """
    scannerResults: list[Scan] | None = Field(default=None, title="Scannerresults")
    """
    Result for each guardrail that ran on the prompt
    """


class ScannerAvailabilityUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["scanner-availability-updated"] = Field("scanner-availability-updated", title="Type")
    user: User | None = None


class ScannerCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["scanner-created"] = Field(default="scanner-created", title="Type")
    user: User | None = None


class ScannerDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["scanner-deleted"] = Field(default="scanner-deleted", title="Type")
    user: User | None = None


class ScannerDisabledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["scanner-disabled"] = Field(default="scanner-disabled", title="Type")
    user: User | None = None


class ScannerEnabledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["scanner-enabled"] = Field(default="scanner-enabled", title="Type")
    user: User | None = None


class ScannerPackage(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    availability: ScannerAvailability = Field(
        default_factory=lambda: ScannerAvailability.model_validate({"global": False, "projectIds": []})
    )
    availableUpdate: datetime | None = Field(default=None, title="Availableupdate")
    direction: ScannerDirection | str | None = None
    id: UUID | None = Field(default=None, title="Id")
    name: str | None = Field(default=None, title="Name")
    projectId: UUID | None = Field(default=None, title="Projectid")
    scannerCounts: dict[str, int] = Field(default={}, title="Scannercounts")
    scannerIds: list[UUID] | None = Field(default=None, title="Scannerids")
    shared: bool = Field(default=False, title="Shared")
    source: (
        InternalScannerSource
        | ShareScannerSource
        | ZipScannerSource
        | VendorScannerSource
        | SystemScannerSource
        | RemediationScannerSource
        | None
    ) = Field(default=None, discriminator="type", title="Source")
    vendored: bool = Field(default=False, title="Vendored")


class ScannerPackageAvailabilityUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")
    type: Literal["scanner-package-availability-updated"] = Field("scanner-package-availability-updated", title="Type")
    user: User | None = None


class ScannerPackageCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")
    type: Literal["scanner-package-created"] = Field("scanner-package-created", title="Type")
    user: User | None = None


class ScannerPackageDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")
    type: Literal["scanner-package-deleted"] = Field("scanner-package-deleted", title="Type")
    user: User | None = None


class ScannerPackageDisabledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")
    type: Literal["scanner-package-disabled"] = Field("scanner-package-disabled", title="Type")
    user: User | None = None


class ScannerPackageEnabledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    projectId: UUID | None = Field(default=None, title="Projectid")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")
    type: Literal["scanner-package-enabled"] = Field("scanner-package-enabled", title="Type")
    user: User | None = None


class ScannerPackageUndeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")
    type: Literal["scanner-package-undeleted"] = Field("scanner-package-undeleted", title="Type")
    user: User | None = None


class ScannerPackageUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")
    type: Literal["scanner-package-updated"] = Field("scanner-package-updated", title="Type")
    user: User | None = None


class ScannerPublishedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["scanner-published"] = Field(default="scanner-published", title="Type")
    user: User | None = None


class ScannerSharedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    shareId: UUID | None = Field(default=None, title="Shareid")
    type: Literal["scanner-shared"] = Field(default="scanner-shared", title="Type")
    user: User | None = None


class ScannerTemplateCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerTemplateId: UUID | None = Field(default=None, title="Scannertemplateid")
    type: Literal["scanner-template-created"] = Field("scanner-template-created", title="Type")
    user: User | None = None


class ScannerTemplateUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerTemplateId: UUID | None = Field(default=None, title="Scannertemplateid")
    type: Literal["scanner-template-updated"] = Field("scanner-template-updated", title="Type")
    user: User | None = None


class ScannerUndeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["scanner-undeleted"] = Field(default="scanner-undeleted", title="Type")
    user: User | None = None


class ScannerUnpublishedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["scanner-unpublished"] = Field(default="scanner-unpublished", title="Type")
    user: User | None = None


class ScannerUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["scanner-updated"] = Field(default="scanner-updated", title="Type")
    user: User | None = None


class ScannerVersionPublishedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    scannerId: UUID | None = Field(default=None, title="Scannerid")
    type: Literal["scanner-version-published"] = Field("scanner-version-published", title="Type")
    user: User | None = None
    versionId: UUID | None = Field(default=None, title="Versionid")


class SecretCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    secretId: UUID | None = Field(default=None, title="Secretid")
    type: Literal["secret-created"] = Field(default="secret-created", title="Type")
    user: User | None = None


class SecretDeletedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    secretId: UUID | None = Field(default=None, title="Secretid")
    type: Literal["secret-deleted"] = Field(default="secret-deleted", title="Type")
    user: User | None = None


class SecretScannerConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    flagOn: list[SecretType] = Field(default=["regex", "entropy", "user"], title="Flagon")
    type: Literal["secret"] = Field(default="secret", title="Type")
    userSecrets: dict[str, UserSecret] = Field(default={}, title="Usersecrets")


class SecretUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    secretId: UUID | None = Field(default=None, title="Secretid")
    type: Literal["secret-updated"] = Field(default="secret-updated", title="Type")
    user: User | None = None


class ShareScannerEmailSent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    shareId: UUID | None = Field(default=None, title="Shareid")
    type: Literal["share-scanner-email-sent"] = Field("share-scanner-email-sent", title="Type")
    user: User | None = None


class SystemPermission(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    name: Any | None = None
    resourceId: Literal["system"] = Field(default="system", title="Resourceid")
    type: Literal["system"] = Field(default="system", title="Type")


class TaskCanceledEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    taskId: UUID | None = Field(default=None, title="Taskid")
    type: Literal["task-canceled"] = Field(default="task-canceled", title="Type")
    user: User | None = None


class TaskCreatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    taskId: UUID | None = Field(default=None, title="Taskid")
    type: Literal["task-created"] = Field(default="task-created", title="Type")
    user: User | None = None


class TaskUpdatedEvent(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    createdAt: datetime | None = Field(default=None, title="Createdat")
    data: Any = Field(default=None, title="Data")
    id: UUID | None = Field(default=None, title="Id")
    requestId: str | None = Field(default=None, title="Requestid")
    taskId: UUID | None = Field(default=None, title="Taskid")
    type: Literal["task-updated"] = Field(default="task-updated", title="Type")
    user: User | None = None


class AttackRun(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    attack: (
        StaticContentAttack
        | DynamicSingleTurnContentAttack
        | DynamicMultiTurnContentAttack
        | OperationalAttack
        | CustomAttack
        | None
    ) = Field(default=None, title="Attack")
    errorCount: int | None = Field(default=0, title="Errorcount")
    events: (
        list[
            AttackRunQueuedEvent
            | AttackRunStartedEvent
            | AttackRunScheduledEvent
            | AttackRunCompletedEvent
            | AttackRunFailedEvent
            | AttackRunCancellingEvent
            | AttackRunCancelledEvent
            | AttackRunScheduleErrorEvent
        ]
        | None
    ) = Field(default=None, title="Events")
    id: UUID | None = Field(default=None, title="Id")
    progress: int | None = Field(default=0, title="Progress")
    providerId: UUID | None = Field(default=None, title="Providerid")
    providerName: str | None = Field(default=None, title="Providername")
    results: list[DSAttackResult] = Field(default=[], title="Results")
    total: int | None = Field(default=None, title="Total")


class Campaign(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    attacks: (
        list[
            StaticContentAttack
            | DynamicSingleTurnContentAttack
            | DynamicMultiTurnContentAttack
            | OperationalAttack
            | CustomAttack
            | InvalidAttack
        ]
        | None
    ) = Field(default=None, title="Attacks")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    createdBy: str | None = Field(default=None, title="Createdby")
    description: str | None = Field(default=None, title="Description")
    id: UUID | None = Field(default=None, title="Id")
    lastRun: UUID | None = Field(default=None, title="Lastrun")
    lastRunAt: datetime | None = Field(default=None, title="Lastrunat")
    name: str | None = Field(default=None, title="Name")
    runCount: int | None = Field(default=0, title="Runcount")
    vendored: bool = Field(default=False, title="Vendored")


class CampaignAttack(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    attack: (
        StaticContentAttack
        | DynamicSingleTurnContentAttack
        | DynamicMultiTurnContentAttack
        | OperationalAttack
        | CustomAttack
        | InvalidAttack
        | None
    ) = Field(default=None, title="Attack")
    id: UUID | None = Field(default=None, title="Id")


class CampaignRun(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    CASIScore: float | int | None = Field(default=None, title="Casiscore")
    actionsCount: int | None = Field(default=None, title="Actionscount")
    attackRuns: list[AttackRun] | None = Field(default=None, title="Attackruns")
    averagePerformance: float | None = Field(default=None, title="Averageperformance")
    campaignId: UUID | None = Field(default=None, title="Campaignid")
    casiScorePositionDelta: int | None = Field(default=None, title="Casiscorepositiondelta")
    costOfSecurity: float | None = Field(default=None, title="Costofsecurity")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    createdBy: str | None = Field(default=None, title="Createdby")
    id: UUID | None = Field(default=None, title="Id")
    name: str | None = Field(default=None, title="Name")
    preserve: bool = Field(default=False, title="Preserve")
    progress: int = Field(default=0, title="Progress")
    providerErrors: dict[str, CampaignRunProviderErrors] | None = Field(None, title="Providererrors")
    purged: bool = Field(default=False, title="Purged")
    remediation: CampaignRunRemediation | None = None
    remediationSettings: CampaignRunRemediationSettings | None = None
    rtpRatio: float | None = Field(default=None, title="Rtpratio")
    scheduleId: UUID | None = Field(default=None, title="Scheduleid")
    startAt: datetime | None = Field(default=None, title="Startat")
    status: CampaignRunStatus | str | None = None
    total: int | None = Field(default=None, title="Total")
    vendored: bool = Field(default=False, title="Vendored")


class File(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    content: UploadFile | None = Field(default=None, title="Content")
    contentType: str | None = Field(default=None, title="Contenttype")
    expiresAt: datetime | None = Field(default=None, title="Expiresat")
    id: UUID | None = Field(default=None, title="Id")
    metadata: FileMetadata | None = None
    name: str | None = Field(default=None, title="Name")
    orgId: str | None = Field(default=None, title="Orgid")
    resourceId: str | None = Field(default=None, title="Resourceid")


class GetAuditResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    events: (
        list[
            AgentSessionCreatedEvent
            | AgentSessionFingerprintsRequestedEvent
            | ApiTokenCreatedEvent
            | ApiTokenRevokedEvent
            | BrandingCreatedEvent
            | BrandingUpdatedEvent
            | CampaignCreatedEvent
            | CampaignDeletedEvent
            | CampaignRunCreatedEvent
            | CampaignRunDeletedEvent
            | CampaignRunUpdatedEvent
            | CampaignScheduleCreatedEvent
            | CampaignScheduleDeletedEvent
            | CampaignScheduleUpdatedEvent
            | CampaignUpdatedEvent
            | ChatbotCreatedEvent
            | ChatbotGroupCreatedEvent
            | ChatbotGroupUpdatedEvent
            | ChatbotUpdatedEvent
            | EntitlementGroupCreatedEvent
            | EntitlementGroupDeletedEvent
            | EntitlementGroupUpdatedEvent
            | EntitlementOverrideCreatedEvent
            | EntitlementOverrideDeletedEvent
            | EntitlementUsageCreatedEvent
            | EntitlementUsageDeletedEvent
            | FileCreatedEvent
            | LicenseCreatedEvent
            | OAuthClientCreatedEvent
            | OAuthClientDeletedEvent
            | OAuthClientUpdatedEvent
            | OrganizationCreatedEvent
            | OrganizationDataDeleted
            | OrganizationDisabledEvent
            | OrganizationEnabledEvent
            | OrganizationEntitlementsUpdatedEvent
            | OrganizationPromptRecordingDisabled
            | OrganizationPromptRecordingEnabled
            | OrganizationUpdatedEvent
            | ProjectCreatedEvent
            | ProjectDefaultProviderUpdatedEvent
            | ProjectDeletedEvent
            | ProjectMemberAddedEvent
            | ProjectMemberRemovedEvent
            | ProjectProviderAddedEvent
            | ProjectProviderRemovedEvent
            | ProjectProviderRoutingCreatedEvent
            | ProjectProviderRoutingUpdatedEvent
            | ProjectScannerAddedEvent
            | ProjectScannerPackageAddedEvent
            | ProjectScannerPackageRemovedEvent
            | ProjectScannerRemovedEvent
            | ProjectUndeletedEvent
            | ProjectUpdatedEvent
            | ProviderAvailabilityUpdatedEvent
            | ProviderCreatedEvent
            | ProviderDeletedEvent
            | ProviderDisabledEvent
            | ProviderEnabledEvent
            | ProviderTestEvent
            | ProviderUndeletedEvent
            | ProviderUpdatedEvent
            | RemediationCreatedEvent
            | RemediationDeployedEvent
            | RemediationRejectedEvent
            | RoleCreatedEvent
            | RoleDeletedEvent
            | RolePermissionsAddedEvent
            | RolePermissionsRemovedEvent
            | RoleUpdatedEvent
            | ScannerAvailabilityUpdatedEvent
            | ScannerCreatedEvent
            | ScannerDeletedEvent
            | ScannerDisabledEvent
            | ScannerEnabledEvent
            | ScannerPackageAvailabilityUpdatedEvent
            | ScannerPackageCreatedEvent
            | ScannerPackageDeletedEvent
            | ScannerPackageDisabledEvent
            | ScannerPackageEnabledEvent
            | ScannerPackageUndeletedEvent
            | ScannerPackageUpdatedEvent
            | ScannerPublishedEvent
            | ScannerSharedEvent
            | ScannerTemplateCreatedEvent
            | ScannerTemplateUpdatedEvent
            | ScannerUndeletedEvent
            | ScannerUnpublishedEvent
            | ScannerUpdatedEvent
            | ScannerVersionPublishedEvent
            | SecretCreatedEvent
            | SecretDeletedEvent
            | SecretUpdatedEvent
            | ShareScannerEmailSent
            | TaskCanceledEvent
            | TaskCreatedEvent
            | TaskUpdatedEvent
            | UserAuthenticationMethodsDeleted
            | UserBlockedEvent
            | UserCreatedEvent
            | UserDeletedEvent
            | UserRoleAssignedEvent
            | UserRoleRetractedEvent
            | UserRolesUpdatedEvent
            | UserUnblockedEvent
            | UserUpdatedEvent
            | UserVerifiedEvent
            | LegacyAuditEvent
        ]
        | None
    ) = Field(default=None, title="Events")
    """
    Events matching the given filter criteria.
    """
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """


class GetCampaignResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaign: Campaign | None = None
    """
    Requested campaign object
    """


class GetCampaignsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaigns: list[Campaign] | None = Field(default=None, title="Campaigns")
    """
    Campaigns matching the given criteria
    """
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    users: dict[str, User] = Field(default={}, title="Users")


class GetFileResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    file: File | None = None
    """
    The requested file metadata.
    """


class GetOrgResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    org: Organization | None = None


class GetScannerPackagesResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    packages: list[ScannerPackage] | None = Field(default=None, title="Packages")
    """
    Packages matching the given filter criteria.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """


class PatchScannerBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    config: (
        RegexScannerConfig
        | KeywordScannerConfig
        | BlacklistScannerConfig
        | DemographicScannerConfig
        | PIIScannerConfig
        | PromptInjectionScannerConfig
        | SentimentAnalysisScannerConfig
        | SourceCodeScannerConfig
        | NamedEntityScannerConfig
        | ToxicityScannerConfig
        | TopicsScannerConfig
        | LegalScannerConfig
        | SecretScannerConfig
        | GenAIScannerConfig
        | AuditTermScannerConfig
        | None
    ) = Field(default=None, title="Config")
    """
    New config for the guardrail.
    """
    direction: ScannerDirection | str | None = None
    """
    New direction the guardrail should scan in.
    """
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    New name for the guardrail.
    """
    published: bool | None = Field(default=None, title="Published")
    """
    Whether the guardrail should be published or not.
    """
    tags: list[constr(pattern=r"^[a-zA-Z0-9-_]+$", min_length=1, max_length=50)] | None = Field(
        default=None, title="Tags"
    )
    """
    New tags for the guardrail. Replaces all existing tags.
    """
    version: ScannerVersionInputModel | constr(pattern=r"^[a-zA-Z0-9-_]+$", min_length=1, max_length=100) | None = (
        Field(default=None, title="Version")
    )
    """
    Name or object containing the name and description for the new version of the guardrail.
    """


class PostProviderTestResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    content: str | None = Field(default=None, title="Content")
    """
    Content of the provider template response.
    """
    error: str | None = Field(default=None, title="Error")
    files: list[ProviderOutputFile] | None = Field(default=None, title="Files")
    """
    Files returned by the provider response.
    """
    requests: dict[str, ProviderRunBlockData] | None = Field(default=None, title="Requests")
    """
    "All request/response data collected during the test

    Keys are JSON path strings to each request block within the template.
    """
    statusCode: int | None = Field(default=None, title="Statuscode")
    """
    Status code returned by the provider template.
    """


class PostScansBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    configOverrides: dict[
        str,
        RegexScannerConfig
        | KeywordScannerConfig
        | BlacklistScannerConfig
        | DemographicScannerConfig
        | PIIScannerConfig
        | PromptInjectionScannerConfig
        | SentimentAnalysisScannerConfig
        | SourceCodeScannerConfig
        | NamedEntityScannerConfig
        | ToxicityScannerConfig
        | TopicsScannerConfig
        | LegalScannerConfig
        | SecretScannerConfig
        | GenAIScannerConfig
        | AuditTermScannerConfig
        | dict[str, Any],
    ] = Field(default={}, title="Configoverrides")
    """
    Config overrider for guardrails, specified by type for system guardrails or ID for custom guardrails.
    """
    disabled: list[ScanType | UUID] = Field(default=[], title="Disabled")
    """
    Disable guardrails, specified by type for system guardrails or ID for custom guardrails.
    """
    endpoint: UUID | str | None = Field(default=None, title="Endpoint")
    """
    Deprecated
    """
    externalMetadata: dict[str, constr(max_length=255)] | None = Field(None, title="Externalmetadata")
    """
    A json string for users to attach any data to the prompt for their own use,
    For example to tag certain prompts for tracking
    (Limited to 10 items, keys of up to 50 characters and values of up to 255 characters).
    """
    flagOnly: bool = Field(default=True, title="Flagonly")
    """
    If true, the final outcome is 'flagged' if any scanner is triggered.
    Otherwise, the outcome depends on the scanner's mode.
    """
    forceEnabled: list[ScanType | UUID] = Field(default=[], title="Forceenabled")
    """
    Force guardrails to be enabled, specified by type for system guardrails or ID for custom guardrails.
    """
    input: str | None = Field(default=None, title="Input")
    """
    Data to scan.
    """
    project: UUID | str | None = Field(default=None, title="Project")
    """
    Project to use configuration for. If not provided, the global default will be used.
    """
    verbose: bool = Field(default=False, title="Verbose")
    """
    If true, return details on each guardrail that ran against the input data
    """


class ProjectConfig(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    packages: list[ProjectConfigScanner] = Field(default=[], title="Packages")
    """
    Packages configured for the project
    """
    providerRouting: list[list] | None = Field(default=None, title="Providerrouting")
    """
    Array of tuples of provider routing rules.

    Prompts are sent to the matching provider based on the first rule that passes.
    Array items are in the shape of [provider id, rule]
    """
    providers: list[ProjectConfigProvider] = Field(default=[], title="Providers")
    """
    Providers available to the project
    """
    scanners: list[ProjectConfigScanner] = Field(default=[], title="Scanners")
    """
    Guardrails configured for the project
    """


class PromptResult(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    files: list[PromptResultFile] = Field(default=[], title="Files")
    outcome: PromptOutcome | str | None = None
    """
    One of 'cleared', 'flagged' or 'blocked'
    """
    providerResult: ProviderPromptResult | None = None
    response: str | None = Field(default=None, title="Response")
    """
    The response to the prompt from the LLM
    """
    scannerResults: list[Scan] | None = Field(default=None, title="Scannerresults")
    """
    Result for each guardrail that ran on the prompt
    """


class PublicPrompt(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    externalMetadata: dict[str, constr(max_length=255)] | None = Field(None, title="Externalmetadata")
    extraInputs: dict[str, Any] | None = Field(default=None, title="Extrainputs")
    id: UUID | None = Field(default=None, title="Id")
    input: str | dict[str, Any] | list | int | float | bool | None = Field(None, title="Input")
    memory: list[UUID] | None = Field(default=None, title="Memory")
    """
    IDs of prev prompts in the conversation
    """
    parentId: UUID | None = Field(default=None, title="Parentid")
    """
    ID of the last prompt in the conversation
    """
    preserve: bool = Field(default=False, title="Preserve")
    projectId: UUID | None = Field(default=None, title="Projectid")
    provider: UUID | None = Field(default=None, title="Provider")
    """
    ID of LLM provider use for the prompt
    """
    receivedAt: datetime | None = Field(default=None, title="Receivedat")
    result: ScanRequestResult | PublicPromptResult | None = Field(default=None, title="Result")
    type: Type4 | str | None = Field(default=None, title="Type")
    userId: str | None = Field(default=None, title="Userid")


class RemediationDeployment(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    comment: str | None = Field(default=None, title="Comment")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    createdBy: str | None = Field(default=None, title="Createdby")
    projectIds: list[UUID] | None = Field(default=None, title="Projectids")
    rejected: bool | None = Field(default=None, title="Rejected")
    scannerConfigs: dict[str, RemediationScannerConfig] | None = Field(None, title="Scannerconfigs")
    scannerPackageId: UUID | None = Field(default=None, title="Scannerpackageid")


class ScanRequest(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    externalMetadata: dict[str, constr(max_length=255)] | None = Field(None, title="Externalmetadata")
    extraInputs: dict[str, Any] | None = Field(default=None, title="Extrainputs")
    id: UUID | None = Field(default=None, title="Id")
    input: str | dict[str, Any] | list | int | float | bool | None = Field(None, title="Input")
    preserve: bool = Field(default=False, title="Preserve")
    projectId: UUID | None = Field(default=None, title="Projectid")
    receivedAt: datetime | None = Field(default=None, title="Receivedat")
    result: ScanRequestResult | None = None
    type: Literal["scan"] = Field(default="scan", title="Type")
    userId: str | None = Field(default=None, title="Userid")


class Scanner(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    availability: ScannerAvailability = Field(
        default_factory=lambda: ScannerAvailability.model_validate({"global": False, "projectIds": []})
    )
    availableUpdate: datetime | None = Field(default=None, title="Availableupdate")
    config: (
        RegexScannerConfig
        | KeywordScannerConfig
        | BlacklistScannerConfig
        | DemographicScannerConfig
        | PIIScannerConfig
        | PromptInjectionScannerConfig
        | SentimentAnalysisScannerConfig
        | SourceCodeScannerConfig
        | NamedEntityScannerConfig
        | ToxicityScannerConfig
        | TopicsScannerConfig
        | LegalScannerConfig
        | SecretScannerConfig
        | GenAIScannerConfig
        | AuditTermScannerConfig
        | None
    ) = Field(default=None, title="Config")
    direction: ScannerDirection | str = "request"
    id: UUID | None = Field(default=None, title="Id")
    name: str | None = Field(default=None, title="Name")
    packageId: UUID | None = Field(default=None, title="Packageid")
    projectId: UUID | None = Field(default=None, title="Projectid")
    scannerTemplateId: UUID | None = Field(default=None, title="Scannertemplateid")
    shared: bool = Field(default=False, title="Shared")
    source: (
        InternalScannerSource
        | ShareScannerSource
        | ZipScannerSource
        | VendorScannerSource
        | SystemScannerSource
        | RemediationScannerSource
    ) = Field(default={"type": "internal"}, discriminator="type", title="Source")
    tags: list[constr(pattern=r"^[a-zA-Z0-9-_]+$", min_length=1, max_length=50)] = Field(default=[], title="Tags")
    vendored: bool = Field(default=False, title="Vendored")
    versionMeta: ScannerVersionMeta | None = None


class ScannerExport(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    availability: ScannerAvailability = Field(
        default_factory=lambda: ScannerAvailability.model_validate({"global": False, "projectIds": []})
    )
    availableUpdate: datetime | None = Field(default=None, title="Availableupdate")
    config: (
        RegexScannerConfig
        | KeywordScannerConfig
        | BlacklistScannerConfig
        | DemographicScannerConfig
        | PIIScannerConfig
        | PromptInjectionScannerConfig
        | SentimentAnalysisScannerConfig
        | SourceCodeScannerConfig
        | NamedEntityScannerConfig
        | ToxicityScannerConfig
        | TopicsScannerConfig
        | LegalScannerConfig
        | SecretScannerConfig
        | GenAIScannerConfig
        | AuditTermScannerConfig
        | None
    ) = Field(default=None, title="Config")
    direction: ScannerDirection | str = "request"
    id: UUID | None = Field(default=None, title="Id")
    name: str | None = Field(default=None, title="Name")
    packageId: UUID | None = Field(default=None, title="Packageid")
    projectId: UUID | None = Field(default=None, title="Projectid")
    scannerTemplateId: UUID | None = Field(default=None, title="Scannertemplateid")
    shared: bool = Field(default=False, title="Shared")
    source: (
        InternalScannerSource
        | ShareScannerSource
        | ZipScannerSource
        | VendorScannerSource
        | SystemScannerSource
        | RemediationScannerSource
    ) = Field(default={"type": "internal"}, discriminator="type", title="Source")
    tags: list[constr(pattern=r"^[a-zA-Z0-9-_]+$", min_length=1, max_length=50)] = Field(default=[], title="Tags")
    vendored: bool = Field(default=False, title="Vendored")
    versionMeta: ScannerVersionInputModel | None = None


class Endpoint(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    chatbotId: UUID | None = Field(default=None, title="Chatbotid")
    config: ProjectConfig | None = None
    createdAt: datetime | None = Field(default=None, title="Createdat")
    groupId: UUID | None = Field(default=None, title="Groupid")
    id: UUID | None = Field(default=None, title="Id")
    name: constr(pattern=r"^[a-zA-Z0-9-]+$", min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    The name can be used to identify the project instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """


class GetDatasetRunResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    dataset: Dataset | None = None
    run: DatasetRun | None = None
    scanner: Scanner | None = None
    scannerPackage: ScannerPackage | None = None
    user: User | None = None


class GetDatasetRunsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    datasetRuns: list[DatasetRun] | None = Field(default=None, title="Datasetruns")
    """
    Array of dataset runs.
    """
    datasets: dict[str, Dataset] = Field(default={}, title="Datasets")
    """
    Map of dataset IDs to datasets.
    """
    scannerPackages: dict[str, ScannerPackage] = Field(default={}, title="Scannerpackages")
    """
    Map of guardrail version IDs to guardrails.
    """
    scanners: dict[str, Scanner] = Field(default={}, title="Scanners")
    """
    Map of guardrail version IDs to guardrails.
    """
    users: dict[str, User] = Field(default={}, title="Users")


class GetDatasetsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    datasetRuns: dict[str, DatasetRun] = Field(default={}, title="Datasetruns")
    """
    Map of dataset run IDs to runs.
    """
    datasets: list[Dataset] | None = Field(default=None, title="Datasets")
    """
    Array of datasets.
    """
    scannerPackages: dict[str, ScannerPackage] = Field(default={}, title="Scannerpackages")
    """
    Map of guardrail version IDs to guardrails.
    """
    scanners: dict[str, Scanner] = Field(default={}, title="Scanners")
    """
    Map of guardrail version IDs to guardrails.
    """
    users: dict[str, User] = Field(default={}, title="Users")
    """
    Map of user IDs to users.
    """


class GetEndpointResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    endpoint: Endpoint | None = None
    """
    Requested endpoint object.
    """


class GetEndpointsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    endpoints: list[Endpoint] | None = Field(default=None, title="Endpoints")
    """
    Endpoints matching the given filter criteria.
    """


class GetGlobalEndpointResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    endpoint: Endpoint | None = None
    """
    The default endpoint for the group/chatbot specified or global settings if neither is given.
    """


class GetScanResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    scan: ScanRequest | None = None
    """
    Requested scan request object.
    """


class GetScannerPackageResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    package: ScannerPackage | None = None
    """
    Requested guardrail package object.
    """
    scanners: list[Scanner] | None = Field(default=None, title="Scanners")
    """
    Guardrails contained in the package.
    """


class GetScannerResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    scanner: Scanner | None = None
    """
    Requested guardrail object.
    """


class GetScannersResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    scannerPackages: dict[str, ScannerPackage] | None = Field(None, title="Scannerpackages")
    scanners: list[Scanner] | None = Field(default=None, title="Scanners")
    """
    Guardrails matching the given filter criteria.
    """


class GetScansResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    scans: list[ScanRequest] | None = Field(default=None, title="Scans")
    """
    Scan requests objects matching the given filter criteria.
    """


class PatchEndpointBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    config: ProjectConfig | None = None
    """
    New config for the endpoint. Partial configurations are accepted.
    """
    name: constr(pattern=r"^[a-zA-Z0-9-]+$", min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    The name can be used to identify the project instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """


class PatchProjectBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    config: ProjectConfig | None = None
    """
    New config for the project. Partial configurations are accepted.
    """
    deploymentStatus: ProjectDeploymentStatus | str | None = None
    """
    New deployment status for the project.
    """
    friendlyId: constr(pattern=r"^[a-zA-Z0-9-]+$", min_length=1, max_length=100) | None = Field(
        default=None, title="Friendlyid"
    )
    """
    The name can be used to identify the project instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")


class PostEndpointsBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    config: ProjectConfig | None = None
    """
    Config for the endpoint.
    If not provided, the current config for the specified group or global settings will be used.
    """
    groupId: UUID | None = Field(default=None, title="Groupid")
    """
    Group to create the endpoint for. If not provided, the endpoint will be globally accessible.
    """
    name: constr(pattern=r"^[a-zA-Z0-9-]+$", min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    The name can be used to identify the project instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """


class PostProjectsBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    adminIds: list[str] | None = Field(default=None, title="Adminids")
    """
    User IDs to be set as project admins, if not specified will be set to current user.
    At least one ID is required for API calls using global or project tokens.
    """
    config: ProjectConfig | None = None
    """
    Config for the project.
    If not provided, the current config for the specified group or global settings will be used.
    """
    deploymentStatus: ProjectDeploymentStatus | str = "draft"
    """
    Deployment status for the project.
    """
    friendlyId: constr(pattern=r"^[a-zA-Z0-9-]+$", min_length=1, max_length=100) | None = Field(
        default=None, title="Friendlyid"
    )
    """
    The name can be used to identify the project instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """
    memberIds: list[str] | None = Field(default=None, title="Memberids")
    """
    User IDs to be set as project members.
    """
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    """
    Name for the project.
    """
    type: Type2 | str | None = Field(default=None, title="Type")
    """
    Type of the project to create.
    """


class Project(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    adminCount: int = Field(default=0, title="Admincount")
    adminRoleId: UUID | None = Field(default=None, title="Adminroleid")
    agentSessionCount: int | None = Field(default=None, title="Agentsessioncount")
    botType: ChatbotType | str | None = None
    chatbotId: UUID | None = Field(default=None, title="Chatbotid")
    config: ProjectConfig | None = None
    createdAt: datetime | None = Field(default=None, title="Createdat")
    createdBy: str | None = Field(default=None, title="Createdby")
    deploymentStatus: ProjectDeploymentStatus | str = "draft"
    friendlyId: constr(pattern=r"^[a-zA-Z0-9-]+$", min_length=1, max_length=100) | None = Field(
        default=None, title="Friendlyid"
    )
    """
    The name can be used to identify the project instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """
    id: UUID | None = Field(default=None, title="Id")
    memberCount: int = Field(default=0, title="Membercount")
    memberRoleId: UUID | None = Field(default=None, title="Memberroleid")
    name: constr(min_length=1, max_length=100) | None = Field(default=None, title="Name")
    providerCount: int | None = Field(default=None, title="Providercount")
    scannerCount: int | None = Field(default=None, title="Scannercount")
    tokenCount: int | None = Field(default=None, title="Tokencount")
    type: ProjectType | str | None = None
    updatedAt: datetime | None = Field(default=None, title="Updatedat")


class ProjectScanners(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    configs: dict[str, ProjectConfigScanner] = Field(default={}, title="Configs")
    """
    Behaviour of each guardrails specific to the project, such as whether to block flagged prompts
    """
    forcedScanners: dict[str, Scanner | list[Scanner]] = Field({}, title="Forcedscanners")
    """
    Guardrails enabled for the project which were enabled by the global setting's admin.
    A list value indicates multiple versions of a guardrail that were enabled (Playground prompts only).
    """
    scanners: dict[str, Scanner] = Field(default={}, title="Scanners")
    """
    Guardrails enabled for the project which were enabled by the project's admin.
    """


class Prompt(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    externalMetadata: dict[str, constr(max_length=255)] | None = Field(None, title="Externalmetadata")
    extraInputs: dict[str, Any] | None = Field(default=None, title="Extrainputs")
    fromTemplate: bool = Field(default=False, title="Fromtemplate")
    """
    If the prompt is from a template
    """
    id: UUID | None = Field(default=None, title="Id")
    input: str | dict[str, Any] | list | int | float | bool | None = Field(None, title="Input")
    memory: list[UUID] | None = Field(default=None, title="Memory")
    """
    IDs of prev prompts in the conversation
    """
    parentId: UUID | None = Field(default=None, title="Parentid")
    """
    ID of the last prompt in the conversation
    """
    preserve: bool = Field(default=False, title="Preserve")
    """
    If the prompt should not be purge on data clean
    """
    projectId: UUID | None = Field(default=None, title="Projectid")
    """
    ID of group prompt was used with
    """
    provider: UUID | None = Field(default=None, title="Provider")
    """
    ID of LLM provider use for the prompt
    """
    receivedAt: datetime | None = Field(default=None, title="Receivedat")
    result: PromptResult | None = None
    type: Type3 | str = Field(default="prompt", title="Type")
    userId: str | None = Field(default=None, title="Userid")


class Remediation(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignRunId: UUID | None = Field(default=None, title="Campaignrunid")
    createdAt: datetime | None = Field(default=None, title="Createdat")
    createdBy: str | None = Field(default=None, title="Createdby")
    deployment: RemediationDeployment | None = None
    error: RemediationError | None = None
    events: (
        list[
            RemediationQueuedEvent
            | RemediationStartedEvent
            | RemediationCompletedEvent
            | RemediationFailedEvent
            | RemediationCancellingEvent
            | RemediationCancelledEvent
        ]
        | None
    ) = Field(default=None, title="Events")
    id: UUID | None = Field(default=None, title="Id")
    result: RemediationResult | None = None
    status: RemediationStatus | str | None = None
    updatedAt: datetime | None = Field(default=None, title="Updatedat")


class ExportProjectSettings(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    addedPackagesIds: list[UUID] | None = Field(default=None, title="Addedpackagesids")
    addedProviderIds: list[UUID] | None = Field(default=None, title="Addedproviderids")
    addedScannerIds: list[UUID] | None = Field(default=None, title="Addedscannerids")
    project: Project | None = None
    roles: list[Role] | None = Field(default=None, title="Roles")


class GetChatResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    chat: Chat | None = None
    """
    Requested chat object.
    """
    prompts: list[Prompt] | None = Field(default=None, title="Prompts")
    """
    Prompts contained in the chat.
    """


class GetEndpointScannersResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    endpointScanners: ProjectScanners | None = None


class GetGlobalProjectResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    project: Project | None = None
    """
    The default project for the group/chatbot specified or global settings if neither is given.
    """


class GetProjectResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    project: Project | None = None
    """
    Requested project object.
    """


class GetProjectScannersResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    projectScanners: ProjectScanners | None = None


class GetProjectsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    projects: list[Project] | None = Field(default=None, title="Projects")
    """
    Projects matching the given filter criteria.
    """


class GetPromptResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    memory: list[Prompt] | None = Field(default=None, title="Memory")
    """
    Parent prompts of the request prompt
    """
    prompt: Prompt | ScanRequest | None = Field(default=None, title="Prompt")
    """
    Data for requested prompt
    """
    promptScanners: ProjectScanners | None = None
    """
    Data for guardrails that run on the prompt
    """


class GetPromptTemplateResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    promptTemplate: PromptTemplate | None = None
    """
    Requested prompt template object.
    """
    prompts: list[Prompt] | None = Field(default=None, title="Prompts")
    """
    Prompts contained in the prompt template.
    """


class GetPromptsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    prompts: list[Prompt | ScanRequest] | None = Field(default=None, title="Prompts")
    """
    Prompts matching the given filter criteria.
    """


class PostPromptsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    id: UUID | None = Field(default=None, title="Id")
    """
    ID of prompt that was created, if prompt recording is enabled
    """
    result: PromptResult | None = None
    """
    Result of prompt that was created
    """
    scanners: ProjectScanners | None = None
    """
    Details on the guardrails that ran on the input
    """


class PostScansResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    id: UUID | None = Field(default=None, title="Id")
    """
    ID of the newly created scan request, if recording is enabled
    """
    redactedInput: str | None = Field(default=None, title="Redactedinput")
    """
    The given input after any redaction
    """
    result: ScanRequestResult | None = None
    """
    Results for the scan request.
    """
    scanners: ProjectScanners | None = None


class APIRetryBlock(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    attempts: int | None = Field(default=None, title="Attempts")
    backoff: int | str = Field(default=1, title="Backoff")
    block: APIRequestBlock | APIWorkflowBlock | APIRetryBlock | None = Field(None, discriminator="type", title="Block")
    type: Literal["retry"] = Field(default="retry", title="Type")
    when: str | None = Field(default=None, title="When")


class APIWorkflowBlock(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    outputs: dict[constr(pattern=r"^[a-zA-Z_][a-zA-Z0-9_]*$"), str] = Field({}, title="APIScopeOutputs")
    stages: list[APIRequestBlock | APIRetryBlock | APIWorkflowBlock] | None = Field(None, title="Stages")
    type: Literal["workflow"] = Field(default="workflow", title="Type")


class ExportSettings(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    packages: list[ScannerPackage] | None = Field(default=None, title="Packages")
    projects: list[ExportProjectSettings] | None = Field(default=None, title="Projects")
    providers: list[Provider] | None = Field(default=None, title="Providers")
    roles: list[Role] | None = Field(default=None, title="Roles")
    scanners: list[ScannerExport | Scanner] | None = Field(default=None, title="Scanners")
    secrets: list[Secret] | None = Field(default=None, title="Secrets")


class GetCampaignRunResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaign: Campaign | None = None
    campaignRun: CampaignRun | None = None
    providers: dict[str, Provider] | None = Field(default=None, title="Providers")
    schedule: CampaignSchedule | None = None


class GetCampaignRunsResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    campaignRuns: list[CampaignRun] | None = Field(default=None, title="Campaignruns")
    """
    Campaign runs matching the given criteria
    """
    campaigns: dict[str, Campaign] = Field(default={}, title="Campaigns")
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    providers: dict[str, Provider] = Field(default={}, title="Providers")
    remediations: dict[str, Remediation] = Field(default={}, title="Remediations")
    schedules: dict[str, CampaignSchedule] = Field(default={}, title="Schedules")
    users: dict[str, User] = Field(default={}, title="Users")


class GetProviderResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    provider: Provider | None = None
    """
    Requested provider object.
    """


class GetProvidersResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    next: str | None = Field(default=None, title="Next")
    """
    Cursor to the next page, if any.
    """
    prev: str | None = Field(default=None, title="Prev")
    """
    Cursor to the previous page, if any.
    """
    providers: list[Provider] | None = Field(default=None, title="Providers")
    """
    Providers matching the given filter criteria.
    """


class GetPublicChatResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    chat: Chat | None = None
    """
    Requested chat object.
    """
    prompts: list[PublicPrompt] | None = Field(default=None, title="Prompts")
    """
    Prompts contained in the chat.
    """
    provider: PublicProvider | None = None
    """
    Provider the chat was sent to, if any.
    """
    user: User | None = None
    """
    Details of the user who owns the chat.
    """


class GetSystemProviderResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    provider: Provider | None = None
    """
    Requested system provider object.
    """


class GetSystemProvidersResponse(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    providers: list[Provider] | None = Field(default=None, title="Providers")
    """
    Available system providers.
    """


class OrgExport(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    settings: ExportSettings | None = None
    version: PositiveInt | None = Field(default=None, title="Version")


class PatchProviderBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    authTemplate: APIRequestBlock | APIRetryBlock | APIWorkflowBlock | None = Field(None, title="Authtemplate")
    """
    New provider auth template to use when sending prompts.
    """
    inputs: dict[str, Any] | None = Field(default=None, title="Inputs")
    """
    New input values that can be accessed in the template.
    """
    maxRequestsPerSecond: PositiveInt | None = Field(default=None, title="Maxrequestspersecond")
    """
    Deprecated, use requestConcurrencyLimit instead.
    """
    name: constr(pattern=r"^[a-zA-Z0-9-]+$") | None = Field(default=None, title="Name")
    """
    The name can be used to identify the provider instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """
    requestConcurrencyLimit: RequestConcurrencyLimit | bool | None = Field(None, title="Requestconcurrencylimit")
    """
    Specifies concurrency limits for requests from campaign run attacks. Set to false to remove existing limit.
    """
    secrets: dict[str, UUID | NewSecret] | None = Field(default=None, title="Secrets")
    """
    New secrets that can be accessed in the template.
    """
    template: APIRequestBlock | APIRetryBlock | APIWorkflowBlock | None = Field(None, title="Template")
    """
    New provider template to use when sending prompts.
    """
    test: bool = Field(default=False, title="Test")
    """
    Whether to test the provider connection before updating.
    """


class PostAdminSettingsExportBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    export: OrgExport | None = None


class PostAdmingSettingsImportBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    clearExisting: bool = Field(default=False, title="Clearexisting")
    """
    If true, all existing data belonging to your organization will be deleted. This is not reversible.
    """
    export: OrgExport | None = None
    """
    Previously exported data to restore to the organization.
    """
    preserveRoles: bool = Field(default=False, title="Preserveroles")
    """
    If true and clearExisting is true, users will preserve the roles they have at time of import.
    """
    preserveTokens: bool = Field(default=False, title="Preservetokens")
    """
    If true and clearExisting is true, personal API tokens will be preserved."
    Machine tokens will not be preserved.
    """


class PostProviderTestTemplateBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    authTemplate: APIRequestBlock | APIRetryBlock | APIWorkflowBlock | None = Field(None, title="Authtemplate")
    """
    Optional template to use to fetch authentication credentials.
    """
    capability: ProviderCapability | str | None = None
    """
    Provider capability to test for
    """
    inputs: dict[str, Any] | None = Field(default=None, title="Inputs")
    """
    Input values that can be accessed in the template.
    """
    secrets: dict[str, UUID] | None = Field(default=None, title="Secrets")
    """
    Secrets that can be accessed in the template.
    """
    template: APIRequestBlock | APIRetryBlock | APIWorkflowBlock | None = Field(
        None, discriminator="type", title="Template"
    )
    """
    Provider template to use when sending the test.
    """


class PostProvidersWithTemplateBody(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    authTemplate: APIRequestBlock | APIRetryBlock | APIWorkflowBlock | None = Field(None, title="Authtemplate")
    """
    Optional template to use to fetch authentication credentials.
    """
    capabilities: list[ProviderCapability] | None = Field(default=None, title="Capabilities")
    """
    Set of capabilities that the provider will have. Cannot be changed after creation.
    """
    default: bool = Field(default=False, title="Default")
    """
    Whether the new provider should the default provider. Has no effect if enable is false.
    """
    enable: bool = Field(default=False, title="Enable")
    """
    Enable the new provider for the default project for the group/global settings.
    """
    groupId: UUID | None = Field(default=None, title="Groupid")
    """
    Limit access to the provider to a given group.
    """
    inputs: dict[str, Any] | None = Field(default=None, title="Inputs")
    """
    Input values that can be accessed in the template.
    """
    maxRequestsPerSecond: PositiveInt | None = Field(default=None, title="Maxrequestspersecond")
    """
    Deprecated, use requestConcurrencyLimit instead.
    """
    name: constr(pattern=r"^[a-zA-Z0-9-]+$") | None = Field(default=None, title="Name")
    """
    The name can be used to identify the provider instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """
    projectId: UUID | None = Field(default=None, title="Projectid")
    """
    Limit access to the provider to a given project.
    """
    redTeam: bool = Field(default=False, title="Redteam")
    """
    Mark provider for use in attack campaigns.
    """
    requestConcurrencyLimit: RequestConcurrencyLimit | None = None
    """
    Specifies concurrency limits for requests from campaign run attacks.
    """
    secrets: dict[str, UUID | NewSecret] | None = Field(default=None, title="Secrets")
    """
    Secrets that can be accessed in the template.
    """
    tag: str | None = Field(default=None, title="Tag")
    """
    Optional tag to attach to the provider.
    """
    template: APIRequestBlock | APIRetryBlock | APIWorkflowBlock | None = Field(
        None, discriminator="type", title="Template"
    )
    """
    Provider template to use when sending prompts.
    """
    test: bool = Field(default=False, title="Test")
    """
    Whether to test the provider connection before creation.
    """


class Provider(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    authTemplate: APIRequestBlock | APIRetryBlock | APIWorkflowBlock | None = Field(None, title="Authtemplate")
    """
    Optional API template to retrieve temporary auth credentials
    """
    availability: ProviderAvailability = Field(
        default_factory=lambda: ProviderAvailability.model_validate({"global": False, "projectIds": []})
    )
    capabilities: list[ProviderCapability | str] | None = Field(None, title="Capabilities")
    hasLogo: bool = Field(default=False, title="Haslogo")
    id: UUID | None = Field(default=None, title="Id")
    inputs: dict[str, Any] | None = Field(default=None, title="Inputs")
    maxRequestsPerSecond: int | None = Field(default=None, title="Maxrequestspersecond")
    """
    Deprecated, use requestConcurrencyLimit instead
    """
    name: constr(pattern=r"^[a-zA-Z0-9-]+$") | None = Field(default=None, title="Name")
    """
    The name can be used to identify the provider instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """
    projectId: UUID | None = Field(default=None, title="Projectid")
    redTeam: bool = Field(default=False, title="Redteam")
    requestConcurrencyLimit: RequestConcurrencyLimit | None = None
    """
    Specifies concurrency limits for requests from campaign run attacks
    """
    secrets: dict[str, UUID] | None = Field(default=None, title="Secrets")
    siem: bool = Field(default=False, title="Siem")
    systemProviderId: UUID | None = Field(default=None, title="Systemproviderid")
    tag: str | None = Field(default=None, title="Tag")
    template: APIRequestBlock | APIRetryBlock | APIWorkflowBlock | None = Field(
        None, discriminator="type", title="Template"
    )
    type: ProviderType | str | None = None


class PublicProvider(BaseModel):
    model_config = ConfigDict(
        extra="allow",
    )
    id: UUID | None = Field(default=None, title="Id")
    name: constr(pattern=r"^[a-zA-Z0-9-]+$") | None = Field(default=None, title="Name")
    """
    The name can be used to identify the provider instead of the id. It is case-sensitive, unique and can only contain letters, numbers and dashes.
    """
    systemProviderId: UUID | None = Field(default=None, title="Systemproviderid")
    template: APIRequestBlock | APIRetryBlock | APIWorkflowBlock | None = Field(
        None, discriminator="type", title="Template"
    )
    type: ProviderType | str | None = None


APIRetryBlock.model_rebuild()
ExportSettings.model_rebuild()
GetCampaignRunResponse.model_rebuild()
GetCampaignRunsResponse.model_rebuild()
GetProviderResponse.model_rebuild()
GetProvidersResponse.model_rebuild()
GetPublicChatResponse.model_rebuild()
GetSystemProviderResponse.model_rebuild()
GetSystemProvidersResponse.model_rebuild()
